
self.addEventListener("push", e => {
    const data = e.data.json();
    self.registration.showNotification(data.title, {
        body: "Notified by Uptown Books!",
        icon: "https://firebasestorage.googleapis.com/v0/b/mybooks-6a624.appspot.com/o/Book_Cover%2FmyBooksIcon144.png?alt=media&token=f575e17d-799d-432d-9172-d1740f64b939"
    });
});


// self.addEventListener('fetch', function (event) {
//     event.respondWith(
//         caches.open('mysite-dynamic').then(function (cache) {
//             return cache.match(event.request).then(function (response) {
//                 return response || fetch(event.request).then(function (response) {
//                     cache.put(event.request, response.clone());
//                     return response;
//                 });
//             });
//         })
//     );
// });

// self.addEventListener('fetch', (event) => { });

