//React Imports
import React, { Component } from 'react';

//Component Imports
import NavBar from './containers/Buyer/Header/NavBar.jsx';

class App extends Component {

  render() {
    return (<div style={{ overflowX: 'hidden', backgroundColor: '#fbfbfb' }}>
      <NavBar />
    </div>
    )
  }
}


export default App;
