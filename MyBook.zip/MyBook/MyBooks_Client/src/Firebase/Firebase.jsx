import firebase from 'firebase'
const config = {
  apiKey: "AIzaSyC_j2hqUYhCD3-vm6f1UPuA3brs1bNmMEk",
  authDomain: "mybooksseller.firebaseapp.com",
  databaseURL: "https://mybooksseller.firebaseio.com",
  projectId: "mybooksseller",
  storageBucket: "mybooksseller.appspot.com",
  messagingSenderId: "836622185084"

};
const fire = firebase.initializeApp(config);

export default fire;
