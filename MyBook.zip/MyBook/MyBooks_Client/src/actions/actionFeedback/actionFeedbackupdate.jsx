//Axios Import
import axios from 'axios';

//Config Import
import config from '../../config.js';

//Variable Declaration
var bookName = '';
var author = '';

export const setBookData = (bookName1, author1) => {
  bookName = bookName1;
  author = author1;
}

export const feedbackFromCollection = (feedback, bookRating) => {  
  const userName = localStorage.getItem('Token');
  axios.post(`${config.urlConnection.urlFeedbackCollection}/feedbackSubmit`, { userName, bookName, author,
     feedback, bookRating })
    .catch(error => {
      throw (error);
    });
};

export const feedbackFromCollectionSuccess = (feedbackData) => {
    return {
    type: config.ACTIONS.FEEDBACK_DATA_UPDATE,
    feedback: feedbackData
  }
};



