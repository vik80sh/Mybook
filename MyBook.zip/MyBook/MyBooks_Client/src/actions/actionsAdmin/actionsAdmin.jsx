//Axios Import
import axios from 'axios';

//Config Import
import swal from 'sweetalert2';
import config from '../../config.js';

//Action Import
import { fetchAllBooks } from '../fetchDataFromStore/actionsFetchAllBooks';

export const Addbook = ({ ISBN, bookName, fiction, action, romance, adventure, 
  textbook, biography, health, horror, others, imageURL, author, description, bookCost, 
  bookQuantity, bookRating, seller_ID, addedBookDate }) => {    
  return (dispatch) => {
    return axios.post(`${config.urlConnection.urlBookCollection}/add`, {
      ISBN, bookName, fiction, action, romance, adventure, textbook,
      biography, health, horror, others, imageURL, author, description,
      bookCost, bookQuantity, bookRating, seller_ID, addedBookDate
    })
      .then(response => {
        if(response.status===204){
          swal({
                type:'error',
                title :'Book Is Already Presnt in Your Store',
                text:'Please Enter New Book if u want to change please update it'
             })
        }
        else{
          swal({
                position: 'top-end',
                type: 'success',
                title: 'Book has been added succesfully',
                showConfirmButton: false,
                timer: 1500
              })

              dispatch(fetchAllBooks());
            }
      })
      .catch(error => {
        throw (error);
      });
  };
};

export default Addbook;
