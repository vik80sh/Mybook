//Axios Import
import axios from 'axios';

//Config Import
import config from '../../config.js';

//Action Import
import { fetchAllBooks } from '../fetchDataFromStore/actionsFetchAllBooks';

export const Updatebook = (_id, { bookName, fiction, action, romance, adventure, textbook, comics, 
    biography, health, horror, others, imageURL, author, description, bookCost, 
    bookQuantity, bookRating }) => {
    return (dispatch) => {
        return axios.put(`${config.urlConnection.urlBookCollection}/UpdateBook/${_id}`, {
            bookName, fiction, action, romance, adventure, textbook, comics,
            biography, health, horror, others, imageURL, author, description,
            bookCost, bookQuantity, bookRating
        })
            .then(response => {
                dispatch(fetchAllBooks());
            })
            .catch(error => {
                throw (error);
            });
    };
};


export default Updatebook;
