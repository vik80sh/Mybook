//Axios Import
import axios from 'axios';

//Config Import
import config from '../../config.js';


export function buyerRegistration(stateVaribale){
    const name      = stateVaribale.name,
    userName        = stateVaribale.userName,
    phoneNo         = stateVaribale.phoneNo,
    email_ID        = stateVaribale.email_ID,
    password        = stateVaribale.password ;
    axios.post(`${config.urlConnection.urlUserCollection}/buyerRegistration`, {name,userName,email_ID,
        password,phoneNo})
    .catch(error => {
        console.log(error)
    });
}