//Axios Import
import axios from 'axios';

//Config Import
import config from '../../config.js';
import swal from 'sweetalert2';
const deleteBookFromCollection = (_id) => {

  return (dispatch) => {
    swal({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then(result=>{
      if(result.value){
     
    return axios.get(`${config.urlConnection.urlBookCollection}/deleteBookFromCollection/${_id}`)
      .then(response => {
        dispatch(deleteBookFromCollectionSuccess(response.data));
        swal(
          'Deleted!',
          'Your Book has been deleted.',
          'success'
        )
      })
      .catch(error => {
        throw (error);
      });
    }
  })
}
  }
    
  
  
  



  



export default deleteBookFromCollection;

export const deleteBookFromCollectionSuccess = (bookData) => {
  return {
    type: config.ACTIONS.DELETE_BOOK_FROM_COLLECTION,
    bookData: bookData
  }
};