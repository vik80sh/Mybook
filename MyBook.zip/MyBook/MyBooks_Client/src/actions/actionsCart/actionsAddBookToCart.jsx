//Axios Import
import axios from 'axios';

//Config Import
import config from '../../config.js';

export const addBookToCart = (uidToken, _id, bookName, imageURL, ISBN, description,
  author, bookRating, bookCost, releaseDate) => {
  return (dispatch) => {
    return axios.post(`${config.urlConnection.urlCartCollection}/addBookToCart`, { uidToken, _id, bookName, imageURL, ISBN, description, author, bookRating, bookCost, releaseDate })
      .then(response => {
        dispatch(addBookToCartSuccess(response.data))
      })
      .catch(error => {
        throw (error);
      });
  };
};

export const addBookToCartSuccess = (data) => {
  return {
    type: config.ACTIONS.ADD_BOOK_TO_CART,
    data: data
  }
};
