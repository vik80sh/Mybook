//Axios Import
import axios from 'axios';

//Config Import
import config from '../../config.js';

const deleteBookFromCart = (_id) => {
  const userName = localStorage.getItem('Token');
  return (dispatch) => {
    return axios.post(`${config.urlConnection.urlCartCollection}/deleteBookFromCart`, { _id, userName })
      .then(response => {
        dispatch(deleteBookFromCartSuccess(response.data))
      })
      .catch(error => {
        throw (error);
      });
  };
};

export default deleteBookFromCart;

export const deleteBookFromCartSuccess = (data) => {
  return {
    type: config.ACTIONS.DELETE_BOOK_FROM_CART,
    data: data
  }
};