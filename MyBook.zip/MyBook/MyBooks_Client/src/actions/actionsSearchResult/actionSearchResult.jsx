//Config Import
import config from '../../config.js';

const searchRes = (result) => {
    return {
        type: config.ACTIONS.SEARCH_RESULT,
        payload: result
    }
}
export default searchRes;