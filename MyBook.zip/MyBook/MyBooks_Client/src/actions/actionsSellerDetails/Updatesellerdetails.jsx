//Axios Import
import axios from 'axios';

//Config Import
import config from '../../config.js';

//Action Import
import {fetchsellerdetails} from './actionsSellerDetails';

export const Updatesellerdetails = ({name,PAN,area,flatNo,state,pin,phoneNo}) => {
  const userName=localStorage.getItem('sellerID');    
   return (dispatch) => {
     return axios.put(`${config.urlConnection.urlSellerCollection }/updatesellerdetails`,
      {userName, name, PAN, area, flatNo,state, pin, phoneNo }
    )
      .then(response => {
        dispatch(fetchsellerdetails(userName));        
      })
      .catch(error => {
        throw (error);
      });
  };
 };

export default Updatesellerdetails;
