//Axios Import
import axios from 'axios';

//Config Import
import config from '../../config.js';

// const userName=localStorage.getItem('sellerID');

export const fetchsellerdetails = (userName) => {
  return (dispatch) => {
    return axios.get(`${config.urlConnection.urlSellerCollection}/sellerprofile/${userName}`)
      .then(response => {
           dispatch(fetchdetails(response.data))
      })
      .catch(error => {
        throw (error);
      });
  };
};

export const fetchdetails = (data) => {
  return {
    type: config.ACTIONS.GET_SELLER_DETAILS,
    data: data
  }
};
