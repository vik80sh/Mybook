//Axios Import
import axios from 'axios';

//Config Import
import config from '../../config.js';
  export const fetchSellerID = (data) => {
  localStorage.setItem('sellerID', data[0].userName)
  return {
    type: "config.ACTIONS",
    payload: data[0].userName
  }
};
export const SellerID = (email) => {
  return (dispatch) => {
    return axios.post(`${config.urlConnection.urlSellerCollection}/SellerID`, { email })
      .then(response => {
        dispatch(fetchSellerID(response.data));
        window.location.href = '/ManageBooksSeller';
      })
      .catch(error => {
        throw (error);
      });
  }
};