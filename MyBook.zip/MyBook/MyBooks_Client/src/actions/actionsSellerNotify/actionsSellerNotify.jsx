//Axios Import
import axios from 'axios';

//Config Import
import config from '../../config.js';

export const SellerNotify = Name => {
  return dispatch => {
    return axios
      .put(`${config.urlConnection.urlSellerCollection}/Notify`, Name)
      .then(response => {
        dispatch(createSellerNotify(response.data));
      })
      .catch(error => {
        throw error;
      });
  };
};

export const createSellerNotify = data => {
  return {
    type: config.ACTIONS.SELLER_DATA,
    data: data
  };
};

export default SellerNotify;
