//Axios Import
import axios from 'axios';
import swal from 'sweetalert2';
//Config Import
import config from '../../config.js';

export const Seller = (Name, userName, email_ID, Phone, password,
  GST_NO, PAN, isVerified, area, flatNo, landmark, state, pin) => {
  return (dispatch) => {
    return axios.post(`${config.urlConnection.urlSellerCollection}/seller`,
      Name, userName, email_ID, Phone, password, GST_NO, PAN, isVerified, area, flatNo, landmark, state, pin)
      .then(response => {
        if(response.status===204){
          swal({
                type:'error',
                title :'Email id or UserName already Present in Database!!',
                text:'Please Try again'
             })
        }
        else{
          swal({
                position: 'top-end',
                type: 'success',
                title: 'Registration as seller successfull and Verification is pending',
                showConfirmButton: false,
                timer: 1500
              })
          dispatch(createSellerSuccess(response.data))
       }
      })
      .catch(error => {
        throw (error);
      });
  };
};

export const createSellerSuccess = (data) => {
  return {
    type: config.ACTIONS.SELLER_DATA,
    payload: {
      Name: data.Name,
      userName: data.userName,
      email_ID: data.email_ID,
      Phone: data.Phone,
      password: data.password,
      GST_NO: data.GST_NO,
      PAN: data.PAN,
      isVerified: data.isVerified,
      area: data.area,
      flatNo: data.flatNo,
      landmark: data.landmark,
      state: data.state,
      pin: data.pin

    }
  }
};

export default Seller;