//Axios Import
import axios from 'axios';

//Config Import
import config from '../../config.js';

export const fetchSellers = () => {
  return (dispatch) => {
    return axios.get(`${config.urlConnection.urlSellerCollection}/Sellers`)
      .then(response => {
        dispatch(fetchsellerdetails(response.data))
      })
      .catch(error => {
        throw (error);
      });
  };
}

export const fetchsellerdetails = (data) => {
  return {
    type: config.ACTIONS.GET_SELLERS,
    data: data
  }
}