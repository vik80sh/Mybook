//Axios Import
import axios from 'axios';

//Config Import
import config from '../../config.js';
import swal from 'sweetalert2';
//const userName = localStorage.getItem('Token');

export const fetchUserOrder = (userName) => {
  return (dispatch) => {
    return axios.get(`${config.urlConnection.urlOrderCollection}/userOrder/${userName}`)
      .then(response => {
        dispatch(fetchOrderdetails(response.data))
      })
      .catch(error => {
        throw (error);
      });
  };
};

export const fetchOrderdetails = (orderData) => {
  return {
    type: config.ACTIONS.USERORDER_DATA,
    orderData: orderData
  }
};

export const actionOderPlace = (stateVariable) => {
  const userName1 = localStorage.getItem('Token');
  const userName = userName1,
    name = stateVariable.name,
    area = stateVariable.area,
    flatNo = stateVariable.flatNo,
    state = stateVariable.state,
    pin = stateVariable.pin,
    email_ID=stateVariable.email_ID,
    phoneNo = stateVariable.phoneNo,
    totalCost = stateVariable.totalCost,
    paymentMethod = stateVariable.paymentMethod
  
    console.log("state ",stateVariable)
  axios.post(`${config.urlConnection.urlOrderCollection}/orderPlaced`, {
    userName,name, area, flatNo, state, pin,email_ID,phoneNo, totalCost, paymentMethod 
  })
    .then(response => {
      if(response.status===203){
        swal({
                type: 'error',
                title: 'Oops... Sorry !!',
                text:  "Book Stock is not available "
            })
          }
          else{
            swal({
                type: 'success',
                title: 'Thank You',
                text:  "Happy shopping"
            })
          }
    })
    .catch(error => {
    });

}
