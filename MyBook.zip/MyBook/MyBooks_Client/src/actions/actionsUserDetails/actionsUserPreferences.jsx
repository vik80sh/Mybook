//Axios Import
import axios from 'axios';

//Config Import
import config from '../../config.js';

export const Addpreference = ({ fiction, action, romance, adventure, textbook, 
  biography, health, horror, comics, others }) => {
  const userName = localStorage.getItem('Token');
  return (dispatch) => {

    return axios.post(`${config.urlConnection.urlUserCollection}/addpreference`,
      {
        userName,
        fiction, action, romance, adventure, textbook, biography, health, horror, comics, others
      }
    )
      .then(response => {
        dispatch(createPreferencesSuccess(response.data))
      })
      .catch(error => {
        throw (error);
      });
  };
};

export const createPreferencesSuccess = (data) => {
  return {
    type: config.ACTIONS.ADD_PREFERENCE,
    payload: {
      preference: data.preference
    }
  }
};

export default Addpreference;
