//Axios Import
import axios from 'axios';

//Config Import
import config from '../../config.js';

//Action Import
import { fetchuserdetails } from './fetchUserDetails'

export const Updatedetails = ({ name, phoneNo }) => {
  const userName = localStorage.getItem('Token');
  return (dispatch) => {
    return axios.put(`${config.urlConnection.urlUserCollection}/updatedetails`,
      {
        userName,
        name, phoneNo
      }
    )
      .then(response => {
        dispatch(fetchuserdetails(userName));
      })
      .catch(error => {
        throw (error);
      });
  };
};

export default Updatedetails;
