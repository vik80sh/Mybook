//Axios Import
import axios from 'axios';

//Config Import
import config from '../../config.js';

export const fetchuserdetails = (userName) => {
  return (dispatch) => {
    return axios.get(`${config.urlConnection.urlUserCollection}/userprofile/${userName}`)
      .then(response => {
        dispatch(fetchdetails(response.data))
      })
      .catch(error => {
        throw (error);
      });
  };
};

export const fetchdetails = (data) => {
  return {
    type: config.ACTIONS.GET_USER_DETAILS,
    data: data
  }
};
