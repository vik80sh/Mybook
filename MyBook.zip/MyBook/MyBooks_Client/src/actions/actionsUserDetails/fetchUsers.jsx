//Axios Import
import axios from 'axios';

//Config Import
import config from '../../config.js';

export const fetchusers = () => {
  return (dispatch) => {
    return axios.get(`${config.urlConnection.urlUserCollection}/fetchusers`)
      .then(response => {
        dispatch(fetchuserdetails(response.data))
      })
      .catch(error => {
        throw (error);
      });
  };
};

export const fetchuserdetails = (data) => {
  return {
    type: config.ACTIONS.GET_USERS,
    data: data
  }
};
