//Axios Import
import axios from 'axios';

//Config Import
import config from '../../config.js';

const fetchFeedbackFromCollection = (_id) => {
  return (dispatch) => {
    return axios.get(`${config.urlConnection.urlFeedbackCollection}/fetchfeedback/${_id}`)
      .then(response => {
        dispatch(fetchFeedbackFromCollectionSuccess(response.data))
      })
      .catch(error => {
        throw ("Error in fetching feedback",error);
      });
  };
};

export const fetchFeedbackFromCollectionSuccess = (feedbackData) => {
  return {
    type: config.ACTIONS.FEEDBACK_DATA,
    feedback: feedbackData
  }
};

export default fetchFeedbackFromCollection;