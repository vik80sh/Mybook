//Axios Import
import axios from 'axios';

//Config Import
import config from '../../config.js';

export const fetchBooks = (bookData) => {
  return {
    type: config.ACTIONS.BOOK_DATA,
    bookData: bookData
  }
}

export const fetchAllBooks = () => {
  return (dispatch) => {
    return axios.get(config.urlConnection.urlBookCollection)
      .then(response => {
        dispatch(fetchBooks(response.data))
      })
      .catch(error => {
        throw ("Error in fetching all books from Server",error);
      });
  };
};