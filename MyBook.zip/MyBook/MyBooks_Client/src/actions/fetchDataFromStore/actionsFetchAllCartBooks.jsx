//Axios Import
import axios from 'axios';

//Config Import
import config from '../../config.js';

export const fetchCartBooks = (data) => {
  return {
    type: config.ACTIONS.ADD_BOOK_TO_CART,
    data: data
  }
}

export const fetchAllCartBooks = (uidtoken) => {
  return (dispatch) => {
    return axios.get(`${config.urlConnection.urlCartCollection}/${uidtoken}`)
      .then(response => {
        dispatch(fetchCartBooks(response.data))
      })
      .catch(error => {
        throw ("ERROR IN CART", error);
      });
  };
};