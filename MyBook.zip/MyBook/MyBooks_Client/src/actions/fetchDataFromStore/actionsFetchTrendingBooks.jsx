//Axios Import
import axios from 'axios';

//Config Import
import config from '../../config.js';

export const fetchTrendingBooks = (bookData) => {
    return {
        type: config.ACTIONS.TRENDING_BOOKS,
        bookData: bookData
    }
}

export const fetchAllTrendingBook = () => {
    return (dispatch) => {
        return axios.get(`${config.urlConnection.urlBookCollection}/trendingBook`)
            .then(response => {
                dispatch(fetchTrendingBooks(response.data))
            })
            .catch(error => {
                throw ("Error in Trending Books Section", error);
            });

    };

}; 