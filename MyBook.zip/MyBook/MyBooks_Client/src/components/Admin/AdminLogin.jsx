//React Imports
import React from 'react';
import { Link } from 'react-router-dom';

//Material UI Imports
import TextField from '@material-ui/core/TextField';
import AccountCircle from '@material-ui/icons/AccountCircle';
import Card from '@material-ui/core/Card';
import Button from '@material-ui/core/Button';
import CardContent from '@material-ui/core/CardContent';
import Lock from '@material-ui/icons/Lock';

class AdminLogin extends React.Component {
    state = {
        UserName: '',
        Password: ''
    }

    handleInputChange = e => {
        this.setState({
            [e.target.name]: e.target.value
        });
    };

    render() {
        return (
            <div>
                <center>
                    <div className="container">
                        <div className="row">
                            <div className="col-lg-3">
                            </div>
                            <div className="col-lg-6">
                                <br></br>
                                <h1>Login As Admin</h1>
                                <Card >
                                    <CardContent>
                                        <form onSubmit={this.handleSubmit}>
                                            <AccountCircle />&nbsp;
                                        <TextField
                                                id="UserName"
                                                label="Admin"
                                                placeholder="Admin"
                                                margin="normal"
                                                onChange={this.handleInputChange}
                                                value={this.state.UserName}
                                                required
                                            />
                                            <br></br>
                                            <Lock />&nbsp;

                                        <TextField
                                                id="Password"
                                                label="Password"
                                                placeholder="Enter Your Password"
                                                margin="normal"
                                                onChange={this.handleInputChange}
                                                value={this.state.Password}
                                                required
                                            />
                                            <br>
                                            </br>
                                            <br>
                                            </br>
                                            <Link to="/adminNavbar">
                                                <Button variant="contained" color="primary"> Login</Button><br></br><br></br>
                                            </Link>
                                        </form>
                                    </CardContent>
                                </Card>
                            </div>
                        </div>
                    </div>
                </center>
            </div>
        );
    }
}

export default AdminLogin; 