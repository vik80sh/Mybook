import AdminLogin from './AdminLogin.jsx'

it('BarChart rendering without crashing',()=>{
    shallow(<AdminLogin />)
})