//React Imports
import React, { Component } from 'react'
import { connect } from 'react-redux';

//Material UI Imports
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';

//Action Imports
import { fetchusers } from "./../../actions/actionsUserDetails/fetchUsers";

//Components Import
import CenteredTabs from '../Admin/CenteredTabs'
class BuyersList extends Component {
    constructor(props) {
        super(props);
        this.props.onFetchUsers();
    }

    render() {
        return (
            <div>
                <CenteredTabs />
                <br />
                <center>
                    <br />
                    <Card style={{ width: "50%", backgroundColor: "#0099cc", color: "white" }}>
                        <h1>Buyers List</h1>
                    </Card>
                    <Card style={{ width: "70%" }}>
                        <CardContent>
                            {this.props.users.map((data, key) => {
                                return (
                                    <div key={data._id}>
                                        <br />
                                        <center>
                                            <ExpansionPanel style={{ width: "60%" }}>
                                                <ExpansionPanelSummary expandIcon={<ExpandMoreIcon />}>

                                                    {data.name}
                                                </ExpansionPanelSummary>
                                                <ExpansionPanelDetails>
                                                    Email ID: &nbsp;{data.email_ID}

                                                </ExpansionPanelDetails>
                                            </ExpansionPanel>
                                        </center>
                                    </div>
                                )
                            })}
                        </CardContent>
                    </Card>
                </center>
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        users: state.storeUserData
    };
};

const mapDispatchToProps = dispatch => {
    return {
        onFetchUsers: () => {
            dispatch(fetchusers());
        }
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(BuyersList);