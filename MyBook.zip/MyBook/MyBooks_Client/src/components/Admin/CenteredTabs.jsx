//React Imports
import React from "react";
import PropTypes from "prop-types";
import { Link } from "react-router-dom";

//Material UI Imports
import { withStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";

const styles = {
  root: {
    flexGrow: 1
  }
};

class CenteredTabs extends React.Component {
  // state = {
  //   value: 0
  // };

  handleChange = (event, value) => {
    // this.setState({ value });
  };

  render() {
    const { classes } = this.props;
    // const { value } = this.state;
    return (
      <div>
        <Paper className={classes.root}>
          <Tabs
            onChange={this.handleChange}
            indicatorColor="primary"
            indicator="false"
            textColor="primary"
            variant="contained"
            centered
          >
            <div className="row">
              <div className="col-sm-2">
                <Tab label="Statistics" component={Link} to="/adminNavbar" />
              </div>
              <div className="col-sm-2">
                <Tab label="ManageBooks" component={Link} to="/DeleteBook" />
              </div>
              <div className="col-sm-2">
                <Tab label="Add Books" component={Link} to="/Addbookform" />
              </div>
              <div className="col-sm-2">
                <Tab label="Users List" component={Link} to="/BuyersList" />
              </div>
              <div className="col-sm-2">
                <Tab label="Sellers List" component={Link} to="/SellerList" />
              </div>
            </div>
          </Tabs>
        </Paper>
      </div>
    );
  }
}

CenteredTabs.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withStyles(styles)(CenteredTabs);
