//React Imports
import { connect } from 'react-redux';

var React = require('react');
var Component = React.Component;
var CanvasJSReact = require('./canvasjs.react');
var CanvasJS = CanvasJSReact.CanvasJS;
var CanvasJSChart = CanvasJSReact.CanvasJSChart;

class BarChart extends Component {
	constructor() {
		super();
		this.addSymbols = this.addSymbols.bind(this);
	}
	addSymbols(e) {
		var suffixes = ["", "K", "M", "B"];
		var order = Math.max(Math.floor(Math.log(e.value) / Math.log(100000)), 0);

		if (order > suffixes.length - 1)
			order = suffixes.length - 1;

		var suffix = suffixes[order];
		return CanvasJS.formatNumber(e.value / Math.pow(10, order)) + suffix;
	}

	render() {

		let fiction = 0;
		let action = 0;
		let horror = 0;
		let comics = 0;
		let romance = 0;
		let adventure = 0;
		let biography = 0;
		let health = 0;
		let textbook = 0;
		let others = 0;
		this.props.books.map(post => {

			if (post.bookcategory.fiction === true)
				fiction = fiction + post.bookQuantity;

			else if (post.bookcategory.action === true)
				action += post.bookQuantity;

			else if (post.bookcategory.horror === true)
				horror += post.bookQuantity;

			else if (post.bookcategory.comics === true)
				comics += post.bookQuantity;

			else if (post.bookcategory.romance === true)
				romance += post.bookQuantity;

			else if (post.bookcategory.adventure === true)
				adventure += post.bookQuantity;

			else if (post.bookcategory.biography === true)
				biography += post.bookQuantity;

			else if (post.bookcategory.health === true)
				health += post.bookQuantity;

			else if (post.bookcategory.textbook === true)
				textbook += post.bookQuantity;

			else if (post.bookcategory.others === true)
				others += post.bookQuantity;
			return true;

		}

		);


		const options = {
			animationEnabled: true,
			theme: "light2", // "light1", "light2", "dark1", "dark2"
			title: {
				text: "Books Stocks"
			},
			axisY: {
				title: "Number of Books",
				labelFormatter: this.addSymbols,
				scaleBreaks: {
					autoCalculate: true
				}
			},
			axisX: {
				title: "Categories",
				labelAngle: 0
			},
			data: [{
				type: "column",
				dataPoints: [
					{ label: "Fiction", y: fiction },
					{ label: "Action", y: action },
					{ label: "Horror", y: horror },
					{ label: "Health", y: health },
					{ label: "Textbooks", y: textbook },
					{ label: "Comics", y: comics },
					{ label: "Romance", y: romance },
					{ label: "Adventure", y: adventure },
					{ label: "Biographies", y: biography },
					{ label: "Others", y: others }
				]
			}]
		}

		return (
			<div>
				<CanvasJSChart options={options}
					onRef={ref => this.chart = ref}
				/>

			</div>
		);
	}
}


const mapStateToProps = state => {
	return {
		books: state.storeBookData
	};
};

export default connect(mapStateToProps, null)(BarChart);