import LineChart from './LineChart.jsx'

it('Line rendering without crashing',()=>{
    shallow(<LineChart />);
})