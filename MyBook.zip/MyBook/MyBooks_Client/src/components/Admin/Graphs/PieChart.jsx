
import { connect } from 'react-redux';

var React = require('react');
var Component = React.Component;
var CanvasJSReact = require('./canvasjs.react');
var CanvasJSChart = CanvasJSReact.CanvasJSChart;
class PieChart extends Component {
	
	render() {
		
		let allBooks=0;
		let others=0;
		let SellerName1 ="",
			bookQuantity1 = 0,

			SellerName2 ="",
			bookQuantity2 = 0,

			SellerName3 ="",
			bookQuantity3 = 0,

			SellerName4 ="",
			bookQuantity4 = 0,

			SellerName5 ="",
			bookQuantity5 = 0;

		var mySet = new Set();
		
		if(this.props.books.length>0){
			this.props.books.map(post => {
				mySet.add(post.seller_ID);
				allBooks=allBooks + post.bookQuantity;
			});

			let size=mySet.size;
			
			
			var array=new Array(size);
			
			let count = 0;
			let max =0;
			this.props.books.map(post => {
				let flag = false
				
				for(let i=0;i<max;i++)
					if(array[i][0]=== post.seller_ID){
						flag = true;
						count=i
				}
				if(flag)
					array[count][1] = array[count][1] + post.bookQuantity;
				else{
					array[max]=new Array(2)
					array[max][0]=post.seller_ID;
					array[max++][1]=post.bookQuantity;
				}
			});
			array.sort(function(a,b){
				return a[1] - b[1];
			});
			for(let i=max-6;i>=0;i--)
				others=others+array[i][1];
			
			SellerName1 =array[max-1][0];
			bookQuantity1 = array[max-1][1];

			SellerName2 = array[max-2][0];
			bookQuantity2 = array[max-2][1];

			SellerName3 = array[max-3][0];
			bookQuantity3 = array[max-3][1];

			SellerName4 = array[max-4][0];
			bookQuantity4 = array[max-4][1];

			SellerName5 = array[max-5][0];
			bookQuantity5 = array[max-5][1];
	
		}

		const options = {
			animationEnabled: true,
			title: {
				text: "Top Sellers"
			},
			subtitles: [{
				// text: "71% Positive",
				verticalAlign: "center",
				fontSize: 24,
				dockInsidePlotArea: true
			}],
			data: [{
				type: "doughnut",
				showInLegend: true,
				indexLabel: "{name}: {y}",
				yValueFormatString: "",
				dataPoints: [
					{ name: SellerName5, y: bookQuantity5 },
					{ name: SellerName4, y: bookQuantity4},
					{ name: SellerName3, y: bookQuantity3 },
					{ name: SellerName2, y: bookQuantity2 },
					{ name: SellerName1, y: bookQuantity1 },
					{ name: "Others", y: others }
				]
			}]
		}
		return (
		<div>
			<CanvasJSChart options = {options}
			
			/>
		
		</div>
		);
	}
}

const mapStateToProps = state => {
    return {
        books: state.storeBookData
    };
};

export default connect(
    mapStateToProps,
    null
)(PieChart);


// this.props.cartbooks.map(post => {
// 	cost = cost + post.bookCost;
// });