//React Imports
import React from 'react';
import { connect } from 'react-redux';

//Components Imports
import BookPreviewCard from '../../components/Buyer/BookCard/BookPreviewCard';

const styles = {
  columnTitle: {
    fontWeight: 'bold',
    fontFamily: 'Helvetica',
    left: 0,
    marginTop: '10px',
    fontSize: 35,
    color: "#1a1a1a",
    width: "100%",
    textTransform: 'uppercase',
    marginBottom: 0
  }
}

function AdminBookPreview({ match, books, onAddToCart }) {
  const matchParams = match.params.id;
  if (!books.length) {
    return (
      <div>
        No Books is Here Till Now
        </div>
    )
  }

  return (
    <div style={{ marginLeft: '12%' }}>
      <div className='row' >
        {books.map(post => {
          if (matchParams == post._id)
            return (
              <div key={post._id}>
                <div style={{ marginBottom: 0 }} style={styles.columnTitle}>
                  BOOK PREVIEW
                </div>
                <BookPreviewCard post={post} key={post._id} />
              </div>
            );
        })}
      </div>
    </div>
  );
}


const mapStateToProps = state => {

  return {
    books: state.storeBookData
  };
};



export default connect(
  mapStateToProps,
  null

)(AdminBookPreview);