//React Imports
import React from 'react';
import { connect } from 'react-redux';
import { Link} from 'react-router-dom';

//Material UI Imports
import Typography from '@material-ui/core/Typography';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Card from '@material-ui/core/Card';



//Components Import
import BookCard from '../Buyer/BookCard/BookCard';


const styles = {
  card: {
    maxWidth: 280,
    padding: '8px',
    boxShadow: '12px 0 15px -4px rgba(31, 73, 125, 0.3), -12px 0 8px -4px rgba(31, 73, 125, 0.3)',
    margin: '0px auto',
    width: '100%',
    height: '100%',
  }
}

function BooksList({ books }) {
  return (<div>
    <AppBar position="absolute" >
      <br />
      <Toolbar>
        <Typography variant="title" color="inherit" noWrap>
          Admin DashBoard
          </Typography>
      </Toolbar>
    </AppBar>
    <center> <h1 style={{ marginTop: 7 }}>ENTIRE BOOK LIST</h1> </center>
    <div className='row'>
      {books.map(post => {
        return (
          <div className='col-md-3' style={{ marginBottom: 20 }}>
            <Link color="inherit" variant="title" to={`/AdminBookPreview/${post._id}`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
              <Card style={styles.card}>
                <BookCard post={post} key={post._id} />
              </Card>
            </Link>
          </div>
        );
      })}
    </div>
  </div>)
}

const mapStateToProps = state => {
  return {
    books: state.storeBookData
  };
};


export default connect(
  mapStateToProps,
)(BooksList);