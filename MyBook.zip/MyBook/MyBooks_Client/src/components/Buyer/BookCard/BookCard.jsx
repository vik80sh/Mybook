//React Imports
import React from 'react';

//Material UI Imports
import Star from '@material-ui/icons/Star';


const styles = {
    card: {
        maxWidth: 280,
        margin: '5px',
        padding: '10px',
        boxShadow: '12px 0 15px -4px rgba(31, 73, 125, 0.3), -12px 0 8px -4px rgba(31, 73, 125, 0.3)',
        width: '100%',
        height: '100%',
    },
    
    buttonStyle: {
        fontSize: '12px',
        textAlign: 'center',
        fontWeight: 'bold',
        margin: '23px'

    },

    bookName: {
        fontSize: '20px',
        textAlign: 'center',
        fontWeight: 'bold',
        width: '100%',
        whiteSpace: 'nowrap',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        fontFamily: 'Quando, , serif',
        margin: '5px',
        
    },
    bookAuthor: {
        fontSize: '13px',
        textAlign: 'center',
        fontWeight: 'bold',
        fontFamily: 'Arima Madurai, cursive',
        margin: '5px'
    },
    cost: {
        fontSize: '17px',
        backgroundColor: '#ffff33',
        border: '2px solid #ffff4d',
        borderRadius: '10px',
        padding: 1,
        textAlign: 'center',
        fontWeight: 'bold',
        fontFamily: 'Merienda One, cursive',
        margin: '5px'
    },
    rating: {
        fontSize: '15px',
        textAlign: 'center',
        padding: 1,
        fontWeight: 'bold',
        fontFamily: 'Trocchi, serif',
        marginTop: '3px',
        marginBottom: 0
    }

};
export default ({ post: { _id, bookName, imageURL, ISBN, description, author, bookRating, bookCost } }) => {
    return (
        <div>            
            <div style={{ marginTop: '20px' }}>              
                <div>
                    <div>
                        <img className="img-fluid" src={imageURL} alt="url" height='200px' width='140px' style={{ margin: '0px auto', display: 'block' }} />
                        <p variant="headline" style={styles.bookName}>
                            {bookName}
                        </p>
                        <p style={styles.bookAuthor}>
                            Written By: {author}
                        </p>
                        <div className='row'>
                            <div className='col-md-6'>
                                <p style={styles.cost}>
                                    Rs. {bookCost}
                                </p>
                            </div>
                            <div className='col-md-6'>
                                <p style={styles.rating}>
                                    Rating: {bookRating}<Star style={{ color: '#FFDF00' }} />
                                </p>
                            </div>
                        </div>
                    </div>
                </div>             
            </div>
        </div>
       
    );
};
