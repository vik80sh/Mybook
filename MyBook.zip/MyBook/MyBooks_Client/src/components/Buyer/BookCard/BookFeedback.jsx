//React Imports
import React, { Component } from 'react';
import { connect } from 'react-redux';

//Material UI Imports
import Card from '@material-ui/core/Card';
import Star from '@material-ui/icons/Star';

//Action Imports
import fetchFeedbackFromCollection from '../../../actions/fetchDataFromStore/actionFetchFeedback';

class BookFeedback extends Component {
  render() {
    this.props.onAddFeedback(this.props.bookID);
    if (!this.props.bookFeedback.length) {
      return (
        <div>
          No Feedback is Here Till Now
        </div>
      )
    }
    else {
      return (<div>
        {this.props.bookFeedback.map((data) =>
          <div className='container' style={{ padding: 1 }}>
            <Card style={{ marginLeft: 10, padding: '3px', marginRight: 20 }}>
              <div className="row" style={{ padding: '20px' }}>
                <div className='col-md-6'>
                  <h3> <span style={{ padding: '15px', fontFamily: 'Artifika, serif' }}> {data.name}</span> </h3>
                </div>
                <div className='col-md-6'>
                  <h4><span style={{ padding: '15px', fontFamily: 'Trocchi, serif' }}>Rating: {data.bookRating}<Star style={{ color: '#FFDF00' }} /></span></h4>
                </div>
              </div>
              <div className='row'>
                <br />
                <div style={{ paddingLeft: '50px', fontFamily: 'Satisfy, cursive' }}><h5> <u style={{ fontFamily: 'Brawler, serif' }}>Given Feedback:</u> &nbsp; &nbsp;{data.feedback}</h5> </div>
              </div>
            </Card>
          </div>
        )}
      </div>
      )
    }
  }
}

const mapStateToProps = state => {
  return {
    bookFeedback: state.storeFeedbackData
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onAddFeedback: (_id) => {
      dispatch(fetchFeedbackFromCollection(_id));
    }
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(BookFeedback);