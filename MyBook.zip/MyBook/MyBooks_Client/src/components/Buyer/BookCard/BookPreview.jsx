//React Imports
import React from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';

//Material UI Imports
import Button from '@material-ui/core/Button';
import AddShoppingCart from '@material-ui/icons/AddShoppingCart';

//Action Imports
import { addBookToCart } from '../../../actions/actionsCart/actionsAddBookToCart';
import fetchFeedbackFromCollection from '../../../actions/fetchDataFromStore/actionFetchFeedback';

//Components Import
import BookFeedback from './BookFeedback';
import BookPreviewCard from './BookPreviewCard';
import { AdminloginLogout, login } from '../../SessionManagement/SessionManagement';

const styles = {
  columnTitle: {
    fontWeight: 'bold',
    fontFamily: 'Helvetica',
    left: 0,
    marginTop: '10px',
    fontSize: 35,
    color: "#1a1a1a",
    width: "100%",
    textTransform: 'uppercase',
    marginBottom: 0
  }
}

function BookPreview({ match, books, onAddToCart, bookFeedback, onAddFeedback }) {
  const matchParams = match.params.id;
  let uidToken = localStorage.getItem('Token');
  if (!books.length) {
    return (
      <div>
        No Books is Here Till Now
      </div>
    )
  }

  return (
    <div  >
      <div className='row' style={{ marginLeft: '12%' }} >
        {books.map((post,key) => {
          if (matchParams === post._id)
            return (
              <div key={post._id}>
                <div style={{ marginBottom: 0 }} style={styles.columnTitle}>
                  {login() && <Link to={`/Login`} style={{ textDecoration: 'none' }}>
                    <Button
                      variant="contained"
                      color="primary"
                      style={{ marginLeft: 30 }}
                      onClick={() => {
                        const uidToken = localStorage.getItem('Token')
                        localStorage.setItem('Redirect', matchParams)
                      }
                      }>
                      <AddShoppingCart />
                      Login to Add to cart
                                    </Button>
                  </Link>}&emsp;
                      {!login() && !AdminloginLogout() && <Link to="/Cart" style={{ textDecoration: 'none' }}>
                    <Button
                      variant="contained"
                      color="primary"
                      style={{ marginLeft: 30 }}
                      onClick={() => onAddToCart(uidToken, post._id,
                        post.bookName, post.imageURL,
                        post.ISBN, post.description,
                        post.author, post.bookRating,
                        post.bookCost, post.releaseDate)
                      }
                    >
                      <AddShoppingCart />
                      Add to cart
                    </Button>
                  </Link>}&emsp;
                </div>
                <BookPreviewCard post={post} onAddToCart={onAddToCart} key={post._id} />
                <h2 style={{fontFamily:'Trocchi, serif'}}>Feedbacks from other Readers </h2>
                <BookFeedback bookID={post._id} bookName={post.bookName} bookFeedback={bookFeedback} />
              </div>
            );
        })}
      </div>
    </div>
  );
}

const mapStateToProps = state => {
  return {
    books: state.storeBookData,
    bookFeedback: state.storeFeedbackData
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onAddToCart: (uidToken, _id, bookName, imageURL, ISBN, description, author, bookRating, bookCost, releaseDate) => {
      dispatch(addBookToCart(uidToken, _id, bookName, imageURL, ISBN, description, author, bookRating, bookCost, releaseDate));
    },
    onAddFeedback: (_id) => {
      dispatch(fetchFeedbackFromCollection(_id));
    }
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(BookPreview);