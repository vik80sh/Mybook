//React Imports
import React from 'react';

//Material UI Imports
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Star from '@material-ui/icons/Star';
import Description from '@material-ui/icons/Description';


export default ({ post: { _id, bookName, imageURL, ISBN, description, author, bookRating, bookCost, releaseDate } }) => {
    return (
        <div>
            <br />
            <div className="container" style={{ padding: '10px' }}>
                <Card>
                    <br>
                    </br>
                    <div className="row">
                        <div className="col-lg-5">
                            <Card style={{ marginBottom: 0, marginLeft:20, height: 520, width: 350, margin: '0px auto' }}>
                                <CardContent style={{ marginBottom: 0, padding: 10 }}>
                                    <img src={imageURL} alt="book" height='495' width='90%' />
                                    <br>
                                    </br>
                                    <br>
                                    </br>
                                </CardContent>
                            </Card>
                        </div>                        
                        <div className="col-lg-6" style={{marginRight:20}}>
                            <h1 style={{fontFamily:'Merienda One, cursive'}}><b>{bookName}</b></h1>
                            <h6>English</h6><br></br>
                            <h5 style={{fontFamily: 'Arima Madurai, cursive'}}>Written By: {author}</h5>
                            <h3 style={{fontFamily:'Trocchi, serif'}}><b>Price: Rs. {bookCost}</b></h3>
                            <h3 style={{fontFamily:'Trocchi, serif'}}><b>Rating: {bookRating}</b><Star style={{ color: '#FFDF00' }} /></h3>
                            <br />
                            <br />
                            <h5 style={{fontFamily: 'Artifika, serif'}}><b>Released On: {releaseDate.substring(0,10)}</b></h5>
                            <br>
                            </br>
                            <h4 style={{padding:10, fontFamily:'Brawler, serif'}}><b><Description />&nbsp;Description:</b></h4>
                            <p style={{padding:10}}><b>{description}</b></p>
                        </div>
                    </div>
                    <br>
                    </br>
                </Card>
            </div>
        </div>
    );
};
