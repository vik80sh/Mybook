//React Imports
import React, { Component } from 'react';

//Material UI Imports
import { withStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';

//Image Import
import JKRowling from '../../../../Assests/AuthorSection/JKRowling.jpg';
import ArundhatiRoy from '../../../../Assests/AuthorSection/ArundhatiRoy.jpeg';
import DanBrown from '../../../../Assests/AuthorSection/DanBrown.jpg';
import RavindarSingh from '../../../../Assests/AuthorSection/RavindarSingh.jpg';
import VikramSeth from '../../../../Assests/AuthorSection/VikramSeth.jpg';
import JKRowling2 from '../../../../Assests/AuthorSection/JKRowling2.jpg';
import ArundhatiRoy2 from '../../../../Assests/AuthorSection/ArundhatiRoy2.jpg';
import DanBrown2 from '../../../../Assests/AuthorSection/DanBrown2.jpg';
import RavindarSingh2 from '../../../../Assests/AuthorSection/RavindarSingh2.jpg';
import VikramSeth2 from '../../../../Assests/AuthorSection/VikramSeth2.jpg';

const styles = {
    card: {
        maxWidth: 270,
        margin: 25,
    },
    media: {
        height: '20%',
        paddingTop: '56.25%',
    },
    buttonStyle: {
        fontSize: '20px',
        textAlign: 'center',
        fontWeigth: 'bolder'
    }
};

class AuthorFlipCard extends Component {
    constructor() {
        super();
        this.state = {
            bookAuthors: [{ name: "Dan Brown", imageSrc: DanBrown, description: " “That is the definition of faith - acceptance of that which we imagine to be true, that which we cannot prove. ”", imageBack: DanBrown2, details: "Daniel Gerhard Brown is an American author of thriller novels, most notably the Robert Langdon stories: Angels & Demons, The Da Vinci Code, The Lost Symbol." },
            { name: "Arundhati Roy", imageSrc: ArundhatiRoy, description: " “That's what careless words do. They make people love you a little less. ” ", imageBack: ArundhatiRoy2, details: "Suzanna Arundhati Roy is an Indian author best known for her novel The God of Small Things, which won the Man Booker Prize for Fiction in 1997 and became the best - selling book by a non-expatriate author. She is also a political activist involved in human rights & environmental causes." },
            { name: "Ravinder Singh", imageSrc: RavindarSingh, description: " “Became an author by chance, now one by choice! ”", imageBack: RavindarSingh2, details: "Ravinder Singh is the bestselling author of I Too Had a Love Story, This Love That Feels Right, and Will You Still Love Me? He has edited and compiled two crowd sourced anthologies named Love stories That Touched My Heart and Tell Me A Story. After having spent most of his life in Burla, a small town in western Odisha, Ravinder is currently in New Delhi." },
            { name: "J. K. Rowling", imageSrc: JKRowling, description: " “We do not need magic to transform our world. We carry all of the power we need inside ourselves already. ”", imageBack: JKRowling2, details: "J. K. Rowling, is a British novelist, philanthropist, film and television producer and screenwriter best known for writing the Harry Potter fantasy series." },
            { name: "Vikram Seth", imageSrc: VikramSeth, description: " “What is the difference between my life and my love? One gets me low, the other lets me go.” ", imageBack: VikramSeth2, details: "Vikram Seth, (born June 20, 1952, Calcutta, India), Indian poet, novelist, and travel writer known for his verse novel The Golden Gate (1986) and his epic novel A Suitable Boy (1993)." },
            ]
        }
    };

    render() {
        const { classes } = this.props;
        return (
            <div>
                <div className='row'>
                    {this.state.bookAuthors.map((dynamicComponent,key) =>
                        <div key={dynamicComponent.name}>
                            <center>
                                <Card className={classes.card} componentdata={dynamicComponent}  >
                                    <CardMedia
                                        className={classes.media}
                                        image={dynamicComponent.imageSrc} />
                                    <CardContent>
                                        <center>
                                            <p variant="headline" className='cardTitle' style={{ fontWeight: 'bold', fontSize: 30, fontFamily: 'Comic Sans MS' }}>
                                                {dynamicComponent.name}
                                            </p>
                                        </center>
                                        <p className='cardText' style={{fontFamily:'Satisfy', fontSize: 20}}>
                                            {dynamicComponent.description}
                                        </p>
                                        <p className='cardText' style={{ fontSize: 12, fontFamily: ' Merienda' }}>
                                            {dynamicComponent.details}
                                        </p>
                                    </CardContent>

                                </Card>
                            </center>
                        </div>
                    )}
                </div>
            </div>
        );
    }
}

export default withStyles(styles)(AuthorFlipCard);
