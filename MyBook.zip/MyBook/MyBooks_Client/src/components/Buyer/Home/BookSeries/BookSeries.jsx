//React Imports
import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';

//Material UI Imports
import { withStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Grid from '@material-ui/core/Grid';

//Image Import
import HarryPotter from '../../../../Assests/BookSeries/HarryPotter.jpg';
import Twilight from '../../../../Assests/BookSeries/Twilight.jpg';
import TheChroniclesofNarnia from '../../../../Assests/BookSeries/TheChroniclesofNarnia.jpg';

const styles = theme => ({
  root: {
    flexGrow: 1,
  },
  paper: {
    padding: 10,
    margin: 30,
    textAlign: 'center',
    color: theme.palette.text.secondary,
  },
});

function BookSeries(props) {
  const { classes } = props;
  // var background = {
  //   backgroundSize: 'cover',
  //   height: '500px',
  //   width: '1500px'
  // };
  // var textStyle = {
  //   position: 'absolute',
  //   top: '50%',
  //   left: '50%'
  // };
  var HarryPotterAuthor = "J.K.Rowling";
  var TwilightAuthor = "Stephenie Meyer";
  var TheChroniclesofNarniaAuthor = "C.S.Lewis";
  return (
    <div className={classes.root}>
      <Grid container>
        <Grid item xs={12} sm={6} style={{ marginTop: 50 }}>
          <Link color="inherit" exact="true" strict="true" variant="title" to={`/BookSeries/${HarryPotterAuthor}`} style={{ color: '#000000', textDecoration: 'none' }}>
            <Paper className={classes.paper}>
              <img className="img-fluid" src={HarryPotter} alt="Harry Potter Series" height='350px' width='700px' />
            </Paper>
          </Link>
        </Grid>
        <Grid item xs={6} sm={3}>
          <Link color="inherit" exact="true" strict="true" variant="title" to={`/BookSeries/${TwilightAuthor}`} style={{ color: '#000000', textDecoration: 'none' }}>
            <Paper className={classes.paper}>
              <img className="img-fluid" src={Twilight} alt="Twilight Series" height='350px' width='700px' />
            </Paper>
          </Link>
        </Grid>
        <Grid item xs={6} sm={3} style={{ marginTop: 10 }}>
          <Link color="inherit" exact="true" strict="true" variant="title" to={`/BookSeries/${TheChroniclesofNarniaAuthor}`} style={{ color: '#000000', textDecoration: 'none' }}>
            <Paper className={classes.paper}>
              <img className="img-fluid" src={TheChroniclesofNarnia} alt="Twilight Series" height='350px' width='700px' />
            </Paper>
          </Link>
        </Grid>
      </Grid>
    </div>
  );
}

BookSeries.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(BookSeries)