//React Imports
import React from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';

//Material UI Imports
import Divider from '@material-ui/core/Divider';
import Card from '@material-ui/core/Card';

//Components Import
import BookCard from '../../BookCard/BookCard';
import Categories from '../Categories';

const styles = {
  columnTitle: {
    fontWeight: 'bold',
    fontFamily: 'Helvetica',
    left: 0,
    marginLeft: '3.5%',
    marginTop: '15px',
    fontSize: 35,
    color: "#1a1a1a",
    width: "100%",
    textTransform: 'uppercase'
  },
  card: {
    maxWidth: 280,
    padding: '8px',
    boxShadow: '12px 0 15px -4px rgba(31, 73, 125, 0.3), -12px 0 8px -4px rgba(31, 73, 125, 0.3)',
    margin: '0px auto',
    width: '100%',
    height: '100%',
  }
}

function BookSeriesBookList({ match, books }) {
  const matchParams = match.params.id;
  if (!books.length) {
    return (
      <div>
        No Books is Here Till Now
        </div>
    )
  }
  return (
    <div>
      <Categories />
      <Divider />
      <center><p style={styles.columnTitle}>{matchParams}'s BOOK SERIES</p></center>
      <div className='row'>
        {books.map((post, key) => {
          if (post.author == match.params.id)
            return (
              <div className='col-md-3' style={{ marginBottom: 20 }} key={post._id}>
                <Link color="inherit" variant="title" to={`/Category/BookPreview/${post._id}`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                  <Card style={styles.card}>
                    <BookCard post={post} key={post._id} />
                    <button className="btn btn-primary" style={{ fontFamily: 'Berlin Sans fb', fontWeight: 'bold', fontSize: 15, margin: '4px', width: '70%', marginLeft: '15%', marginBottom: '1%' }}>PREVIEW</button>
                  </Card>
                </Link>
              </div>
            );
          return true;
        })}
      </div>
    </div>
  );
}

const mapStateToProps = state => {
  return {
    books: state.storeBookData
  };
};

export default connect(
  mapStateToProps,
)(BookSeriesBookList);