import BookSeriesBookList from './BookSeriesBookList.jsx'

describe('BookSeries',()=>{
    let wrapper

    beforeEach(()=>{
        wrapper = shallow(<BookSeriesBookList/>);
        
    })

    it('+++ render the DUMB component', () => {
       expect(wrapper.length).toEqual(1)
    });
         
});
