//React Imports
import React, { Component } from 'react';
import Coverflow from 'react-coverflow';
import { connect } from 'react-redux';
import {  Link } from 'react-router-dom';

//Material UI Imports
import Card from '@material-ui/core/Card';
import Button from '@material-ui/core/Button';

//Action Imports
import { fetchAllBooks } from '../../../../actions/fetchDataFromStore/actionsFetchAllBooks';

//Components Import
import BookCard from '../../BookCard/BookCard';

// const firstBook = {
//   "_id": "5b89197bc5e937c6ac5c1365",
//   "ISBN": 1234567842,
//   "bookcategory": {
//     "romance": 1,
//     "others": 0
//   },
//   "bookName": "A Thing Beyond Forever",
//   "author": "Novoneel Chakraborty",
//   "description": "Dr. Radhika Sharma is what girls of today aspire to become – educated, financially independent and a woman of substance. But within, she is a broken person who is yet to come to terms with her past, her first love Raen’s sudden death.",
//   "bookCost": 110,
//   "bookQuantity": 2,
//   "bookRating": 2.5,
//   "releaseDate": "2015-04-02",
//   "seller_ID": "johns1",
//   "addedBookDate": "2016-04-27",
//   "imageURL": "https://firebasestorage.googleapis.com/v0/b/mybooks-6a624.appspot.com/o/Book_Cover%2Fthingbeyondforever.jpg?alt=media&token=f047aa15-ea90-4b49-8fc0-efc0d06621dc"
// }

const styles = {
  card: {
    maxWidth: 280,
    padding: '8px',
    boxShadow: '12px 0 15px -4px rgba(31, 73, 125, 0.3), -12px 0 8px -4px rgba(31, 73, 125, 0.3)',
    margin: '0px auto',
    width: '100%',
    height: '100%',
  },
  text: {
    fontSize: 20,
    textAlign: 'center',
    fontWeight: 'bold',
    fontFamily: 'Tahoma, Geneva, sans-serif',
    margin: '5px'
  }
}

class Container extends Component {
  constructor(props) {
    super(props);

    this.state = {
      active: 0
    };
  }

  render() {
    return (
      <div>
        <Coverflow
          width='100%'
          height={650}
          displayQuantityOfSide={2}
          navigation={true}
          enableHeading={false}
          active={this.state.active}
        >
          {this.props.books.map((post,key) => {
            return (
              <div key={post._id}>
                <Link color="inherit" variant="title" to={`/Category/BookPreview/${post._id}`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                  <Card style={{ padding: 5 }}>
                    <BookCard post={post} key={post._id} />
                  </Card>
                </Link>
              </div>

            );
          })}
        </Coverflow>
        <center>
          <div style={styles.text}>Above is the pile of Entire Books</div>
          <Button variant="contained" color="secondary" style={{ fontFamily: 'Berlin Sans fb', fontSize: 15, margin: 10 }} onClick={this._handleClick.bind(this)}>
            Click for a Random Pick
      </Button>
        </center>
      </div>
    );
  }

  _handleClick() {
    var num = Math.floor((Math.random() * this.props.books.length) + 1);
    this.setState({
      active: num
    });
  }
};

const mapStateToProps = state => {
  return {
    books: state.storeBookData
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onFetchAllBooks: () => {
      dispatch(fetchAllBooks());
    }
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Container);

