import Carousel from './Carousel.jsx'

it('Carousel renders without crashing',()=>
{
    shallow(<Carousel/>);
})