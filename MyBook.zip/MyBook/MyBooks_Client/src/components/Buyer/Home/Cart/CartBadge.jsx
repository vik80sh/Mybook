import React, { Component } from 'react';
import { connect } from 'react-redux';
import cartIcon from '../../../../Assests/Cart/cartIcon.png';
class CartBadge extends Component {
  render() {
    return (
      <div className="col-md-2">
        <img src={cartIcon} alt="Your Cart" height="40px" width="40px" style={{ margin:10 }}></img>
      </div>

    );
  }
}
const mapStateToProps = state => {
  return {
    cartbooks: state.storeCartdata
  };
};
export default connect(
  mapStateToProps,
  null
)(CartBadge);
