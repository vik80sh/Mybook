//React Imports 

import React, { Component } from 'react';
import { Link } from 'react-router-dom';

//3rd party NPM package Imports
import Media from "react-media";

//Image Imports 

import categoriesFiction from '../../../Assests/CategoriesIcons/categoriesFiction.png';
import categoriesAction from '../../../Assests/CategoriesIcons/categoriesAction.png';
import categoriesHorror from '../../../Assests/CategoriesIcons/categoriesHorror.png';
import categoriesHealth from '../../../Assests/CategoriesIcons/categoriesHealth.png';
import categoriesTextbooks from '../../../Assests/CategoriesIcons/categoriesTextbooks.png';
import categoriesComics from '../../../Assests/CategoriesIcons/categoriesComics.png';
import categoriesRomance from '../../../Assests/CategoriesIcons/categoriesRomance.png';
import categoriesAdventure from '../../../Assests/CategoriesIcons/categoriesAdventure.png';
import categoriesBiographies from '../../../Assests/CategoriesIcons/categoriesBiographies.png';
import categoriesOthers from '../../../Assests/CategoriesIcons/categoriesOthers.png';


var styles = {

    bg: {
        backgroundColor: '#ffffff',
    },

    media: {
        height: 0,
        paddingTop: '56.25%', // 16:9 
    },

    buttonStyle: {
        fontSize: '20px',
        textAlign: 'center',
        fontWeight: 'bold',
        fontFamily: 'Goudy Bookletter 1911',
        marginBottom: 0
    }
}

const categories = [{ name: "Fiction", imageSrc: `${categoriesFiction}`, categoryname: "fiction" },

{ name: "Action", imageSrc: `${categoriesAction}`, categoryname: "action" },
{ name: "Horror", imageSrc: `${categoriesHorror}`, categoryname: "horror" },
{ name: "Health", imageSrc: `${categoriesHealth}`, categoryname: "health" },
{ name: "Text Books", imageSrc: `${categoriesTextbooks}`, categoryname: "textbook" },
{ name: "Comics", imageSrc: `${categoriesComics}`, categoryname: "comics" },
{ name: "Romance", imageSrc: `${categoriesRomance}`, categoryname: "romance" },
{ name: "Adventure", imageSrc: `${categoriesAdventure}`, categoryname: "adventure" },
{ name: "Biographies", imageSrc: `${categoriesBiographies}`, categoryname: "biography" },
{ name: "Others", imageSrc: `${categoriesOthers}`, categoryname: "others" }
];
class Categories extends Component {
    state = {
        user: null
    }
    render() {
        return (
            <div>
                <Media query="(max-width: 440px)">
          {matches =>
            matches ? (
                <div style={styles.bg}>
                    <div className='row' style={{ margin: '0px auto', width: '100%', height: '100%' }}>
                        {categories.map(dynamicComponent =>
                            <div className='col-*-6' style={{ margin: '9%' }} key={dynamicComponent.name}>
                                <Link color="inherit" exact='true' strict='true' variant="title" to={`/Category/${dynamicComponent.categoryname}`} style={{ color: '#000000', textDecoration: 'none' }}>
                                    <img className="img-fluid" src={dynamicComponent.imageSrc} alt="Category" height='100px' width='100px' style={{ margin: '0px auto', display: 'block' }} />
                                    <p style={styles.buttonStyle}>{dynamicComponent.name}</p>
                                </Link>
                                </div>
                        )}
                    </div>
                </div>
            ) : (
                <div style={styles.bg}>
                 {/* <MediaQuery query='(max-width:1224px)'> */}
                    <div className='row' style={{ margin: '0px auto', width: '100%', height: '100%' }}>
                        {categories.map(dynamicComponent =>
                            <div className='col-sm-6 col-xs-6 col-md-1' style={{margin: '13px', width:'100%' }} key={dynamicComponent.name}>
                                <div style={{margin:'0px auto' }}>
                                <Link color="inherit" exact='true' strict='true' variant="title" to={`/Category/${dynamicComponent.categoryname}`} style={{ color: '#000000', textDecoration: 'none' }}>
                                    <img className="img-fluid" src={dynamicComponent.imageSrc} alt="Category" height='100px' width='100px' style={{ margin: '0px auto', display: 'block' }} />
                                    <p style={styles.buttonStyle}>{dynamicComponent.name}</p>
                                </Link>
                                </div>
                            </div>
                          
                        )}
                    </div>
                       
                </div>
            )
          }
        </Media>
            </div>
        );
    }
}

export default Categories;


