//React Imports
import React from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';

//Material UI Imports
import Card from '@material-ui/core/Card';

//Action Imports
import { fetchAllTrendingBook } from '../../../actions/fetchDataFromStore/actionsFetchTrendingBooks';

//Components Import
import BookCard from '../BookCard/BookCard';

const styles = {
  card: {
    maxWidth: 280,
    padding: '8px',
    boxShadow: '12px 0 15px -4px rgba(31, 73, 125, 0.3), -12px 0 8px -4px rgba(31, 73, 125, 0.3)',
    margin: '0px auto',
    width: '100%',
    height: '100%',
  }
}

function TrendingBooks({ trendingBooks, onFetchTrendingBooks }) {
  if (!trendingBooks.length) {
    return (
      <div>
        No Books is Here Till Now
        </div>
    )
  }
  return (
    <div className='row'>
      {trendingBooks.map((post,key) => {
        return (
          <div className='col-md-3' style={{ marginBottom: 20 }} key={post._id}>
            <Link color="inherit" variant="title" to={`/Category/BookPreview/${post._id}`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
              <Card style={styles.card}>
                <BookCard post={post} key={post._id} />
                <button className="btn btn-primary" style={{ fontFamily: 'Berlin Sans fb', fontWeight: 'bold', fontSize: 15, margin: '4px', width: '70%', marginLeft: '15%', marginBottom: '1%' }}>PREVIEW</button>
              </Card>
            </Link>
          </div>
        );
      })}
    </div>
  );
}

const mapStateToProps = state => {
  return {
    trendingBooks: state.storeTrendingBookData
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onFetchTrendingBooks: () => {
      dispatch(fetchAllTrendingBook());
    }
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(TrendingBooks);