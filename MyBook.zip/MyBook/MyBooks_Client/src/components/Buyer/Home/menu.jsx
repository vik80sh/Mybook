//React Imports
import React from 'react';

//Material UI Imports
import Button from '@material-ui/core/Button';
import Menu from '@material-ui/core/Menu';
import MenuItem from '@material-ui/core/MenuItem';

class AppMenu extends React.Component {
    state = {
        anchorEl: null,
    };

    handleClick = event => {
        this.setState({ anchorEl: event.currentTarget });
    };

    handleClose = () => {
        this.setState({ anchorEl: null });
    };

    sellerLogin = () => {
        this.handleClose();
        alert("Redirecting to Seller Login Page");
    }

    adminLogin = () => {
        this.handleClose();
        alert("Redirecting to Admin Login Page");
    }

    render() {
        const { anchorEl } = this.state;

        return (
            <div>
                <Button
                    aria-owns={anchorEl ? 'simple-menu' : null}
                    style={{
                        color: "inherit",
                        fontSize: '24.4px',
                        fontWeight: 'bold',
                        marginTop: '4.5px',
                        textDecoration: 'none'
                    }}
                    aria-haspopup="true"
                    onClick={this.handleClick}
                >
                    More
        </Button>
                <Menu
                    id="simple-menu"
                    anchorEl={anchorEl}
                    open={Boolean(anchorEl)}
                    onClose={this.handleClose}
                >
                    <MenuItem onClick={this.sellerLogin}>Seller Login</MenuItem>
                    <MenuItem onClick={this.handleClose}>Other</MenuItem>
                </Menu>
            </div>
        );
    }
}

export default AppMenu;
