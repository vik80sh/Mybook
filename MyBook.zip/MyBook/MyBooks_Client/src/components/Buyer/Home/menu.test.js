import AppMenu from './menu.jsx'

it('Premium rendering without crashing',()=>{
    shallow(<AppMenu/>);
})