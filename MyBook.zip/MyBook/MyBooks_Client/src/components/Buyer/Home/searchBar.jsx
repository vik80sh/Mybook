//React Imports
import React, { Component } from 'react';
import { NavLink } from 'react-router-dom';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';

//Material UI & Font Awesome Imports
import { library } from '@fortawesome/fontawesome-svg-core'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faSearch } from '@fortawesome/free-solid-svg-icons'
import Snackbar from '@material-ui/core/Snackbar';
import Slide from '@material-ui/core/Slide';

//Action Imports
import searchRes from '../../../actions/actionsSearchResult/actionSearchResult';


library.add(faSearch);
let _ = require('underscore');
let newlyDisplayed;

function TransitionDown(props) {
    return <Slide {...props} direction="down" />;
}

class Search extends Component {
    constructor(props) {
        super(props);
        this.state = {
            displayedBooks: this.props.books,
            searchValue: "",
            open: false,
            Transition: null
        };
    }

    onInpChange = (event) => {
        this.setState({
            searchValue: event.target.value
        })
    }

    handleClose = () => {
        this.setState({
            open: false
        });
    };

    handleClick = Transition => () => {
        if (this.state.searchValue.trim() === "") {
            this.setState({
                open: true, Transition
            })
        }
        else {
            newlyDisplayed = _.filter(this.props.books, book => (book.bookName.toLowerCase().replace(/\s+/g, '').includes(this.state.searchValue.toLowerCase().replace(/\s+/g, '')) || book.author.toLowerCase().replace(/\s+/g, '').includes(this.state.searchValue.toLowerCase().replace(/\s+/g, ''))));
            this.setState({
                displayedBooks: newlyDisplayed
            })
            this.props.searchRes(newlyDisplayed);
        }
    }

    render() {
        return (
            <div className="input-group" style={{margin : 10}}>
                <Snackbar
                    open={this.state.open}
                    onClose={this.handleClose}
                    TransitionComponent={this.state.Transition}
                    ContentProps={{
                        'aria-describedby': 'message-id',
                    }}
                    message={<span id="message-id" style={{ color: "white", fontSize:20 }}> Please Enter Anything To Search</span>}
                />
                <input className="form-control" type="text" placeholder="Search with name or author" name="search" style={{
                    maxWidth: 400,
                    height: "41px",
                    width: "21%"
                }} onChange={this.onInpChange} />
                <div className="input-group-append">
                    <div className="input-group-btn">
                    {(this.state.searchValue.trim() !== "") ? <NavLink to={{ pathname: "/SearchResult", search: `?search=${this.state.searchValue}` }}>
                        <button className="btn-primary" onClick={this.handleClick(TransitionDown)} type="submit" style={{ height: "41px", width: "41px", border:'2px solid Transparent' }}><FontAwesomeIcon icon="search" /></button>
                    </NavLink> :
                        <button className="btn-primary" onClick={this.handleClick(TransitionDown)} type="submit" style={{ height: "41px", width: "41px", border:'2px solid Transparent' }}><FontAwesomeIcon icon="search" /></button>
                    }
                    </div>
                </div>
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        books: state.storeBookData
    };
};

function mapdispatchtoProps(dispatch) {
    return bindActionCreators({ searchRes }, dispatch);
}

export default connect(
    mapStateToProps, mapdispatchtoProps
)(Search);

