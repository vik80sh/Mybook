//React Imports
import React, { Component } from "react";
import { Link, withRouter } from "react-router-dom";

//Material UI Imports
import Button from "@material-ui/core/Button";
import Snackbar from '@material-ui/core/Snackbar';



//Components Import
import { buyerRegistration } from '../../../actions/actionsBuyerRegistration/actionsBuyerRegistration';

//Firebase Imports
import fire from "./../../../Firebase/Firebase.jsx"
import firebase from 'firebase';

//Config Imports
import config from "../../../config.js";

//Image Import
import bookIcon from "../../../Assests/MyBooksIcon/myBooksIcon.png";

//React 3rd Party npm package Imports
import swal from 'sweetalert2';

const styles = {
  card: {
    maxWidth: "80%",
    display: "block",
    margin: "0px auto",
    marginTop: "10px",
    height: "auto",
    position: "relative"
  },
  bullet: {
    display: "inline-block",
    margin: "0 2px",
    transform: "scale(0.8)"
  },
  title: {
    marginBottom: 16,
    fontSize: 17,
    color: "#1a1a1a",
    fontFamily: "Tahoma, Geneva, sans-serif"
  },
  maintitle: {
    marginTop: 10,
    marginBottom: 13,
    fontSize: 33,
    color: "#1a1a1a",
    fontFamily: 'Arial Black", Gadget, sans-serif',
    fontWeight: "bold",
    textAlign: "center"
  },
  titleAuthor: {
    alignText: "center",
    fontSize: 17,
    fontWeight: "bold"
  },
  pos: {
    marginBottom: 12
  },
  formText: {
    fontSize: 18,
    color: "#1a1a1a",
    fontFamily: "Tahoma, Geneva, sans-serif"
  },
  buttonText: {
    fontSize: 15,
    color: "#000000",
    fontFamily: 'Trebuchet MS", Helvetica, sans-serif',
    fontWeight: "bold"
  },
  forgotPassword: {
    marginTop: "20px"
  },
  line: {
    width: "112px",
    height: "47px",
    border: "3px solid white",
    position: "absolute"
  },
  createButton: {
    fontSize: 15,
    borderColor: "#1a1a1a",
    color: "#1a1a1a",
    fontFamily: 'Trebuchet MS", Helvetica, sans-serif',
    fontWeight: "bold"
  },
  Copyright: {
    fontSize: 12,
    fontFamily: 'Trebuchet MS", Helvetica, sans-serif'
  }
};

const INITIAL_STATE = {
  msg: '',
  name: "",
  userName: "",
  phoneNo: "",
  email_ID: "",
  password: "",
  preferenece: {
    Fiction: false,
    Action: false,
    horror: false,
    healthFitenss: false,
    textBook: false,
    comic: false,
    biographies: false,
    others: true
  },
  isPremium: false,
  isAdmin: false,
  isGoogle: false,
  open: false,
  vertical: "top",
  horizontal: "center"
};
let matchparams
const byPropKey = (propertyName, value) => ({ [propertyName]: value });
class LoginForm extends Component {

  constructor(props) {
    super(props);
    matchparams = localStorage.getItem('Redirect')
    this.state = { ...INITIAL_STATE };
  }

  handleClose = () => {
    this.setState({
      open: false
    });
  };
  GoogleLogin = event => {
    
        let provider = new firebase.auth.GoogleAuthProvider();
        let fName, lName, email, uid = null, isNewUser;
        fire.auth().signInWithPopup(provider).then((result)=>{
    
          //var token = result.credential.accessToken;
          fName = result.additionalUserInfo.profile.given_name;
          lName = result.additionalUserInfo.profile.family_name;
          email = result.additionalUserInfo.profile.email;
          uid = result.user.uid;
    
          this.setState(byPropKey("name", (fName+" "+lName)))
          this.setState(byPropKey("userName", uid))
          this.setState(byPropKey("email_ID", email))
    
          localStorage.setItem("Token",uid);
          isNewUser = result.additionalUserInfo.isNewUser;
            this.props.history.push("/");

            
            buyerRegistration(this.state);
              
        })
        
        .catch(error => {
          swal({
            type: 'error',
            title: 'Oops...Something went wrong!',
            text: `${error}`
            
          })

          })
      
      }
    
    

  validation = () => {
   // const {msg, open } = this.state;
    if (this.state.email_ID === "") {
      this.setState({
        msg: "Enter  Email-ID",
        open: true
      });
      return false;
    } else if (config.REGEX_VALIDATE_FORM.mailregex.test(this.state.email_ID) === false) {
      this.setState({
        msg: "Enter  correct Email-ID",
        open: true
      });
      return false;
    } else if (this.state.password === "") {

      this.setState({
        msg: "Enter Password",
        open: true
      });
      return false;
    } else {
      return true;
    }
  };

  handleSubmit = event => {
    // const { open, msg } = this.state;
    event.preventDefault();
    if (this.validation()) {
      fire
        .auth()
        .signInWithEmailAndPassword(this.state.email_ID,this.state.password)
        .then(data => {
          localStorage.setItem("Token", data.user.uid);
          if (data.user.uid === "RQxWYnA2uFYWR6hyWU2zgGBS5q53") {
            swal({
              position: 'top-end',
              type: 'success',
              title: 'Login as a Admin succesful',
              showConfirmButton: false,
              timer: 1500
            })
            this.props.history.push("/adminNavbar");
          }
          else {
            if (localStorage.getItem("Redirect")) {
              
              this.props.history.push(`Category/BookPreview/${matchparams}`)
            }
            else 
            {
              swal({
                position: 'top-end',
                type: 'success',
                title: 'Login succesful',
                showConfirmButton: false,
                timer: 1500
              })

              this.props.history.push("/");

            }
          }
        })
        .catch(error => {
          if (error.message === "The email address is badly formatted.") {
            error.message = "Please enter a correct email address";
          }
          if (
            error.message ===
            "The password is invalid or the user does not have a password."
          ) {
            error.message = "Password you entered is wrong";
          }

          if (
            error.message ===
            "There is no user record corresponding to this identifier. The user may have been deleted."
          ) {
            error.message = "Not a valid user ";
          }
          swal({
            type: 'error',
            title: 'Oops...Something went wrong!',
            text: `${error}`
            
          })
        });
    }
  };

  render() {
    const {vertical, horizontal } = this.state;
    return (
      <div style={styles.card}>
        <p style={styles.maintitle}>
          <img
            src={bookIcon}
            alt="Up Town Books"
            height="55px"
            width="55px"
            style={{ margin: 10 }}
          />UPTOWN BOOKS
        </p>
        <form style={styles.formText} onSubmit={this.handleSubmit}>
          <div className="form-group">
            <p className="formText">Email ID</p>
            <input
              type="text"
              className="form-control"
              id="exampleInputUserName"
              aria-describedby="usernameHelp"
              placeholder="Enter User Name"
              value={this.state.email_ID}
              onChange={event =>
                this.setState(byPropKey("email_ID", event.target.value.trim()))}
            />
          </div>
          <div className="form-group">
            <p> Password </p>
            <input
              type="password"
              className="form-control"
              id="exampleInputPassword"
              placeholder="Enter Password"
              value={this.state.password}
              onChange={event => {
                this.setState(byPropKey("password", event.target.value));
              }}
            />
          </div>
          <Snackbar
            anchorOrigin={{ vertical, horizontal }}
            open={this.state.open}
            onClose={this.handleClose}
            ContentProps={{
              'aria-describedby': 'message-id',
            }}
            message={<span id="message-id" style={{ color: "white" }}>{this.state.msg}</span>}
          />
          <center>
            <button
              type="submit"
              className="btn btn-primary"
              style={{
                fontFamily: 'Trebuchet MS", Helvetica, sans-serif',
                fontWeight: "bold",
                fontSize: 20
              }}
            >
              LOGIN
            </button>
            <p style={styles.forgotPassword}></p>
            <p style={styles.forgotPassword}>--- Want to be a member? ---</p>
            <Link
              color="inherit"
              variant="title"
              to="/Register"
              style={{ color: "#1a1a1a", textDecoration: "none" }}
            >
              <Button variant="outlined" style={styles.createButton}>
                Create an Account
              </Button>
            </Link>
            <br />
            <br />
            
            </center>
            </form>
            <center>
            <Button onClick={this.GoogleLogin} variant="extendedFab" aria-label="Delete" style={{ fontFamily: 'Trebuchet MS", Helvetica, sans-serif', fontWeight: 'bold', fontSize: 15 }}>
                  <img src="googleIcon.png" alt="Google Icon" height="30px" width="30px"></img> <span style={{ margin: 5 }}>Sign In with GOOGLE</span>
                </Button>
                <br />
                <br />
            <p style={styles.Copyright}>
              Copyright © 2018 - 2019 Uptown Books LLC. All rights reserved.
            </p>
          </center>
          <br />
          <br />
        
      </div>
    );
  }
}

export default withRouter(LoginForm);
