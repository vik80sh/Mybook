import LoginForm from './LoginForm.jsx'

it('LoginForm  rendering without crashing',()=>{
    shallow(<LoginForm/>);
})