//React Imports
import React from 'react';
import { connect } from 'react-redux';

//Material UI Imports
import Card from '@material-ui/core/Card';
import Button from '@material-ui/core/Button';
import Lock from '@material-ui/icons/Lock';
import Mail from '@material-ui/icons/Mail';
import AccountCircle from '@material-ui/icons/AccountCircle';

//React 3rd Party npm package Imports
import swal from 'sweetalert2';

//Action Imports
import { actionOderPlace } from '../../../actions/actionsUserDetails/actionUserOrder'

//Config Import
import config from '../../../config.js';

class CreditCard extends React.Component {
    constructor() {
        super();
        this.state = {
            name: "",
            area: "",
            flatNo: "",
            landmark: "",
            state: "",
            pin: "",
            phoneNo: "",
            cardsOwner: "",
            cvv: "",
            expiryMonth: "",
            expiryYear: "",
            code: "",
            totalCost: 0,
            paymentMethod: 'Card Payment'
        }
    }

    handleChange = (event) => {
        const { target: { name, value } } = event
        this.setState({ [name]: value })
    }

    componentDidMount() {
        this.setTotalCost();
    }

    setTotalCost = () => {
        let cost = 0;
        this.props.cartbooks.map(post => {
            cost = cost + post.bookCost;
        });
        this.setState({ totalCost: cost })
    }

    promocode = (code) => {
        let cost = 0;
        this.props.cartbooks.map(post => {
            cost = cost + post.bookCost;
            this.setState({ totalCost: cost })
        });
        let off = 0;
        if (code === "MONTH150") {
            if (cost > 999)
                off = 150;
            else


                swal({
                    type: 'error',
                    title: 'Oops...Something went wrong!',
                    text: 'total cost should be greater than 999',

                })
        }
        else if (code === "FS50")
            off = cost / 2;

        else if (code === "CB200") {
            if (cost > 1000)
                off = 200;
            else
                alert("total cost should be greater than 999")
        }
        else if (code === "CH50") {
            if (cost > 500)
                off = 50;
            else
                swal({
                    type: 'error',
                    title: 'Oops...Something went wrong!',
                    text: 'total cost should be greater than 499',

                })
        }
        else if (code === "CB200")
            off = 200;
        else if (code === "CH50")
            off = 50;
        else
            swal({
                type: 'error',
                title: 'Oops...Something went wrong!',
                text: 'Not valid prmocode',

            })
        this.setState({ totalCost: cost - off })
    }

    isValid = () => {
        if (this.state.name === '') {
            swal({
                type: 'error',
                title: 'Oops...Wrong Input!!',
                text: 'Should not contain  empty spaces and it should contain more than 1 letter and less than 40 letters',
            })

            return false;
        }
        else if (this.state.area === '') {
            swal({
                type: 'error',
                title: 'Oops...Wrong Input!!',
                text: 'give proper area credentials should not contain empty spaces',
            })


            return false;
        }
        else if (this.state.flatNo === '') {
            swal({
                type: 'error',
                title: 'Oops...Wrong Input!!',
                text: 'flatno should not be empty',
            })


            return false;
        }
        else if (this.state.state === '') {
            swal({
                type: 'error',
                title: 'Oops...Wrong Input!!',
                text: 'please enter a valid state name',
            })

            return false;
        }
        else if (this.state.pin.length !== 6) {
            swal({
                type: 'error',
                title: 'Oops...Wrong Input!!',
                text: 'Pincode should contain 6 characters',
            })

            return false;
        }
        else if (this.state.cvv.length !== 3) {
            swal({
                type: 'error',
                title: 'Oops...Wrong Input!!',
                text: 'CVV should contain 3 characters only',
            })

            return false;
        }
        else if (this.state.cardsOwner === '') {
            swal({
                type: 'error',
                title: 'Oops...Wrong Input!!',
                text: 'Should not contain  empty spaces and it should contain more than 1 letter and less than 40 letters',
            })

            return false;
        }
        else if (this.state.cardNumber.length < 12 || this.state.cardNumber.length > 17) {
            swal({
                type: 'error',
                title: 'Oops...Wrong Input!!',
                text: 'Card number should have more than 11 numbers and should have less than 17',
            })

            return false;
        }
        else if (config.REGEX_VALIDATE_FORM.phoneregex.test(this.state.phoneNo) === false) {
            swal({
                type: 'error',
                title: 'Oops...Wrong Input!!',
                text: 'Phone no is not valid',
            })

            return false;
        }
        
        else if (config.REGEX_VALIDATE_FORM.mailregex.test(this.state.email_ID) === false) {
            swal({
                type: 'error',
                title: 'Oops...Wrong Input!!',
                text: 'Email ID  is not valid',
            })

            return false;
        }
        else if (this.state.expiryYear < 2018) {
            swal({
                type: 'error',
                title: 'Oops ... Wrong Input!!',
                text: 'Enter a proper expiry year'
            })
            
            return false;
        }
        else if (this.state.expiryMonth < 1 || this.state.expiryMonth > 12) {
            swal({
                type: 'error',
                title: 'Oops... Wrong Input!!',
                text: 'Enter a proper month'
            })
            
            return false;
        }
        else {
            return true;
        }
    }

    orderPlaced = () => {
        if (this.isValid()) {
            actionOderPlace(this.state);
             this.props.history.push("/")
        }
    }

    render() {
        return (
            <div className="container">
                <br></br>
                <div className="row">
                    <div className="col-lg-2">
                    </div>
                    <div className="col-lg-8">
                        <center>
                            <h5 style={{ fontFamily: 'Bungee Inline, cursive' }}>Net Price : {this.state.totalCost}    </h5>
                            <input className="form-control" type="text"
                                name="code"
                                placeholder="PromoCode"
                                value={this.state.code}
                                onChange={this.handleChange}
                                style={{
                                    width: "200px",
                                    fontSize: 18
                                }}
                            />
                            <button className="btn btn-primary" onClick={() => this.promocode(this.state.code)}>Apply</button>
                        </center>
                        <Card>
                            <br />
                            <form onSubmit={this.orderPlaced}>
                                <center><h3 style={{fontFamily:'Brawler, serif'}}> Personal Information</h3></center>

                                <h6 style={{ marginLeft: '5%' }}><AccountCircle style={{ margin: '5px' }} />Enter the Name:</h6>
                                <center>
                                    <input
                                        type="text"
                                        required
                                        placeholder="Name "
                                        label="name"
                                        name="name"
                                        style={{ width: '90%', padding: 12 }}
                                        value={this.state.name}
                                        onChange={this.handleChange}
                                    />
                                </center>
                                <br />
                                <h6 style={{ marginLeft: '5%' }}><Mail style={{ margin: '5px' }} />Shipping Address</h6>
                                <center>
                                    <input
                                        type="text"
                                        placeholder="Area"
                                        name="area"
                                        style={{ width: '90%', padding: 12 }}
                                        value={this.state.area}
                                        onChange={this.handleChange}
                                        required
                                    />
                                    <br />
                                    <input
                                        type="text"
                                        placeholder="flatNo"
                                        label="name"
                                        name="flatNo"
                                        style={{ width:'90%', padding: 12 }}
                                        value={this.state.flatNo}
                                        onChange={this.handleChange}
                                    />
                                    <br />
                                    <input
                                        type="text"
                                        placeholder="Landmark"
                                        label="name"
                                        name="landmark"
                                        style={{ width: '90%', padding: 12 }}
                                        value={this.state.landmark}
                                        onChange={this.handleChange}
                                    />
                                    <br />
                                    <input
                                        type="text"
                                        placeholder="State"
                                        label="name"
                                        name="state"
                                        style={{ width: '90%', padding: 12 }}
                                        value={this.state.state}
                                        onChange={this.handleChange}
                                        required
                                    />
                                    <br />
                                    <input
                                        type="text"
                                        placeholder="pincode"
                                        label="name"
                                        name="pin"
                                        style={{ width:'90%', padding: 12 }}
                                        value={this.state.pin}
                                        onChange={this.handleChange}
                                        required
                                    />
                                    <br />
                                    <input
                                        type="text"
                                        placeholder="email_ID"
                                        label="name"
                                        name="email_ID"
                                        style={{ width: '90%', padding: 12 }}
                                        value={this.state.email_ID}
                                        onChange={this.handleChange}
                                    />
                                    <br />
                                    <input
                                        type="text"
                                        placeholder="phoneNo"
                                        label="name"
                                        name="phoneNo"
                                        style={{ width: '90%', padding: 12 }}
                                        value={this.state.phoneNo}
                                        onChange={this.handleChange}
                                    />
                                </center>
                                <br />
                                <center>
                                    <h4 style={{fontFamily:'Brawler, serif'}}>Card Details </h4>
                                </center>
                                <div style={{ padding: '5%' }}>
                                    <h6 ><AccountCircle style={{ margin: '5px' }} />Name on Card:</h6>
                                    <input
                                        type="text"
                                        placeholder="Name on card"
                                        label="name"
                                        name="cardsOwner"
                                        style={{ width: '90%', padding: 12 }}
                                        value={this.state.cardsOwner}
                                        onChange={this.handleChange}
                                        required
                                    />
                                    <br />
                                    <br />
                                    <h6>CardNumber:</h6>
                                    <input
                                        type="text"
                                        placeholder="CardNumber"
                                        label="name"
                                        name="cardNumber"
                                        style={{ width: '90%', padding: 12 }}
                                        value={this.state.cardNumber}
                                        onChange={this.handleChange}
                                        required
                                    />
                                    <br />
                                    <br />
                                    <h6><Lock style={{ margin: '5px' }} />CVV number</h6>

                                    <input
                                        type="password"
                                        placeholder="CVV"
                                        label="name"
                                        name="cvv"
                                        style={{ width: '20%', padding: 12 }}
                                        value={this.state.cvv}
                                        onChange={this.handleChange}
                                        required
                                    />
                                    <br />
                                    <br />
                                    <h6>Expiration Date</h6>

                                    <input
                                        type="text"
                                        placeholder="Month"
                                        name="expiryMonth"
                                        style={{ width: '30%', padding: 12 }}
                                        value={this.state.expiryMonth}
                                        onChange={this.handleChange}
                                        required
                                    />
                                    <input
                                        type="text"
                                        placeholder="year"
                                        name="expiryYear"
                                        style={{ width: '30%', padding: 12 }}
                                        value={this.state.expiryYear}
                                        onChange={this.handleChange}
                                        required
                                    />
                                </div>
                                <center><Button onClick={this.orderPlaced} variant="contained" color="primary">Submit</Button></center>
                                <br />
                            </form>
                        </Card>

                    </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        cartbooks: state.storeCartdata
    };
};

export default connect(
    mapStateToProps,
    null
)(CreditCard);


