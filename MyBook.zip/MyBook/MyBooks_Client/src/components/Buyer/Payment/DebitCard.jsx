//React Imports
import React from 'react';
import {Link} from 'react-router-dom';

//Material UI Imports
import Card from '@material-ui/core/Card';
import Button from '@material-ui/core/Button';
import Lock from '@material-ui/icons/Lock';

class DebitCard extends React.Component {
    render() {
        return (<div className="container">
            <br />
            <div className="row">
                <div className="col-lg-2">
                </div>
                <Card>
                    <br />
                    <center><h3> Card Details</h3></center>
                    <div className="col-lg-8">
                        <h6>Name on Card:</h6>
                        <input
                            label="Name"
                            type="text"
                            placeholder="Name on card"
                            style={{ width: 700, padding: 12 }}
                        />
                        <br />
                        <h6>CardNumber:</h6>
                        <input
                            label="CardNumber"
                            type="text"
                            placeholder="CardNumber"
                            style={{ width: 700, padding: 12 }}
                        />
                        <br />
                        <h6>CVV number</h6>
                        <Lock style={{ margin: 10 }} />
                        <input
                            label="CVV"
                            type="password"
                            placeholder="CVV"
                            style={{ width: 200, padding: 12 }}
                        />
                        <h6>Expiration Date</h6>
                        <input
                            label="Month"
                            type="text"
                            placeholder="Month"
                            style={{ width: 100, padding: 12 }}
                        />
                        <input
                            label="year"
                            type="text"
                            placeholder="year"
                            style={{ width: 100, padding: 12 }}
                        />
                    </div>
                    <center><Link to="/ThankyouShopping"><Button variant="contained" color="primary">Submit</Button></Link></center>
                    <br />
                </Card>
            </div>
        </div>)
    }
}

export default DebitCard;