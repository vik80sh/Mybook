import DebitCard from './DebitCard.jsx'

it('Debit card rendering',()=>{
    shallow(<DebitCard/>);
})