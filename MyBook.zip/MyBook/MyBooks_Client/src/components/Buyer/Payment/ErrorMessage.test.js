import ErrorMessage from './ErrorMessage.jsx'

it('Error msg rendering ',()=>{
    shallow(<ErrorMessage/>);
})