//React Imports
import React from 'react';
import { Link} from 'react-router-dom';

//Material UI Imports
import Card from '@material-ui/core/Card';
import Button from '@material-ui/core/Button';

class NetBanking extends React.Component {
    render() {
        return (<div className="container" style={{marginBottom:'18%'}}>
            <br></br>
            <div className="row">
                <div className="col-lg-2">
                </div>
                <div className="col-lg-8">
                    <Card>
                        <br />
                        <center><h4  style={{fontFamily:'Brawler, serif'}}>Select Your Bank</h4></center>
                        <form>
                            <input
                                type="radio"
                                label="Sbi"
                                name="bank"
                                style={{ margin: 20 }}
                            />  State Bank of India
                            <br />
                            <input
                                type="radio"
                                label="Icici"
                                name="bank"
                                style={{ margin: 20 }}
                            />  ICICI Bank
                            <br />
                            <input
                                type="radio"
                                label="PNB"
                                name="bank"
                                style={{ margin: 20 }}
                            />  Punjab National Bank
                            <br />
                            <input
                                type="radio"
                                label="Axis"
                                name="bank"
                                style={{ margin: 20 }}
                            />  Axis Bank
                            <br />
                            <input
                                type="radio"
                                label="HDFC"
                                name="bank"
                                style={{ margin: 20 }}
                            />  HDFC Bank
                             <br />
                            <center><Link to="/ThankyouShopping"><Button variant="contained" color="primary"> Continue Banking</Button></Link></center>
                        </form>
                        <br />
                    </Card>
                </div>
            </div>
        </div>)
    }
}

export default NetBanking;