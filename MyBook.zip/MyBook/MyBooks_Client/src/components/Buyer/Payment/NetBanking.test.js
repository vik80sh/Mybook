import NetBanking from './NetBanking.jsx'

it('Premium rendering without crashing',()=>{
    shallow(<NetBanking/>);
})