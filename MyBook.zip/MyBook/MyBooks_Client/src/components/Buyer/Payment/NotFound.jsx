//React Imports
import React, { Component } from 'react';

//Material UI Imports
import Card from '@material-ui/core/Card';

//Image Import
import notFound from '../../../Assests/Error/notFound.jpg';

var styles = {
    columnTitle: {
        fontWeight: 'bold',
        fontFamily: 'Verdana, Geneva, sans-serif',
        marginTop: '5px',
        textAlign: 'center',
        fontSize: 35,
        color: "#1a1a1a",
        width: "100%",
    }
}

const whenClick = () => {
    window.history.back()
}

class ErrorMessage extends Component {
    render() {
        return (
            <div>
                <div className="container">
                    <center>
                        <Card style={{ marginTop: '15px', padding: '10px', backgroundColor: '#e6f2ff', marginBottom: '15px' }}>
                            <p style={styles.columnTitle}>!! ERROR !!</p>
                            <img className="img-fluid" src={notFound} alt="Error" height='350px' width='790px' />
                            <h3 style={{ margin: '20px', padding: '10px' }}>The page you are looking for is NOT FOUND</h3>
                            <button className="btn btn-primary" onClick={whenClick} style={{ fontFamily: 'Trebuchet MS", Helvetica, sans-serif', fontWeight: 'bold', fontSize: 20 }}>GO BACK</button>
                        </Card>
                    </center>
                </div>
            </div>
        )
    }
}

export default ErrorMessage;
