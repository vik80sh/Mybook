import ErrorMessage from './NetBanking.jsx'

it('Premium rendering without crashing',()=>{
    shallow(<ErrorMessage/>);
})