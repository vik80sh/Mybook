//React Imports
import React from 'react';
import { Link} from 'react-router-dom';

//Material UI Imports
import Card from '@material-ui/core/Card';
import Button from '@material-ui/core/Button';

//Image Import
import paytm from '../../../Assests/PaymentImages/paytmIcon.png';
import QRcode from '../../../Assests/PaymentImages/QRcode.png';

class Paytm extends React.Component {
    render() {
        return (<div className="container">
            <br></br>
            <div className="row">
                <div className="col-lg-2">
                </div>
                <Card>
                    <br></br>
                    <center><h3  style={{fontFamily:'Brawler, serif'}}> Paytm Details</h3></center>
                    <center><img src={paytm} alt="paytm" /></center>
                    <div className="col-lg-8">
                        <center>
                            <form>
                                <input
                                    type="text"
                                    placeholder="Paytm number"
                                    label="name"
                                    style={{ width: 700, padding: 12, margin: 10 }}
                                /><br></br>
                                <input
                                    type="password"
                                    placeholder="Paytm password"
                                    label="name"
                                    style={{ width: 700, padding: 12, margin: 10 }}
                                />
                            </form>
                        </center>
                    </div>
                    <center> <h3  style={{fontFamily:'Brawler, serif'}}>Please Scan the below QR Code</h3> </center>
                    <center><img src={QRcode} alt="QR" height='300px' width='300px' /></center>
                    <center> <h3 style={{fontFamily:'Merienda, cursive'}}>Simple and Incredible PAYTM KARO...</h3> </center>
                    <br />
                    <center><Link to="/ThankyouShopping"><Button variant="contained" color="primary">SUBMIT</Button></Link>
                    </center>
                    <br></br>
                </Card>
            </div>
        </div>)
    }
}

export default Paytm;