import Paytm from './Paytm.jsx'

it('Premium rendering without crashing',()=>{
    shallow(<Paytm />);
})