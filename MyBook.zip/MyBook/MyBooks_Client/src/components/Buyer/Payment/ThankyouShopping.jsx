//React Imports
import React, { Component } from 'react';

//Material UI Imports
import Card from '@material-ui/core/Card';

//Image Import
import paymentSuccessful from '../../../Assests/PaymentImages/paymentSuccessful.png';
import thankYou from '../../../Assests/PaymentImages/Thankyou.png';

class ThankyouShopping extends Component {
  render() {
    return (
      <div className="container">
        <center>
          <Card style={{ marginTop: '30px', padding: '10px', backgroundColor: '#e6f2ff', marginBottom: '5%' }}>
            <img className="img-fluid" src={paymentSuccessful} alt="Payment Successful" height='150px' width='300px' />
            <h2 style={{ fontFamily:'Merienda, cursive', margin: '20px', padding: '10px' }}>Payment is done Successfully</h2>
            <div className='row'>
              <div className='col-md-2'>
                <img className="img-fluid" src={thankYou} alt="Thank you" height='200px' width='120px' />
              </div>
              <div className='col-md-9'>
                <h3 style={{ fontFamily:'Satisfy, cursive', marginTop: '10%' }}>It was really a pleasure doing business with you! Thank you for choosing us!</h3>
                <h1 style={{ fontFamily:'Satisfy, cursive', marginTop: '5%', fontSize:70 }}>Spend Less and Read More...</h1>
              </div>
            </div>
          </Card>
        </center>
      </div>
    )
  }
}

export default ThankyouShopping;
