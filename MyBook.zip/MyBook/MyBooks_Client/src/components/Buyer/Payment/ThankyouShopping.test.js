import ThankyouShopping from './ThankyouShopping.jsx'

it('ThankYou Page rendering without crashing',()=>{
    shallow(<ThankyouShopping/>);
})