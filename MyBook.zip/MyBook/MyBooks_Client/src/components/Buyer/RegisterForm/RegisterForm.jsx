//React Imports
import React, { Component } from 'react';
import { withRouter } from 'react-router-dom';

//React 3rd Party npm package Imports
import swal from 'sweetalert2';

//Firebase Import
import fire from './../../../Firebase/Firebase.jsx';

//Action Imports
import { buyerRegistration } from '../../../actions/actionsBuyerRegistration/actionsBuyerRegistration';

//Config Import
import config from '../../../config.js';

const styles = {
    card: {
        maxWidth: '80%',
        display: 'block',
        margin: '0px auto',
        marginTop: '31px',
        height: '100%',
        position: 'relative'
    },
    bullet: {
        display: 'inline-block',
        margin: '0 2px',
        transform: 'scale(0.8)',
    },
    title: {
        marginBottom: 16,
        fontSize: 17,
        color: "#1a1a1a",
        fontFamily: 'Tahoma, Geneva, sans-serif'
    },
    maintitle: {
        marginBottom: 16,
        marginTop: 55,
        fontSize: 35,
        color: "#1a1a1a",
        fontFamily: 'Arial Black", Gadget, sans-serif',
        fontWeight: 'bold'
    },
    titleAuthor: {

        alignText: 'center',
        fontSize: 17,
        fontWeight: 'bold',
    },
    pos: {
        marginBottom: 12,

    },
    formText:
    {
        fontSize: 18,
        color: "#1a1a1a",
        fontFamily: 'Tahoma, Geneva, sans-serif'
    },
    buttonText:
    {
        fontSize: 15,
        color: "#1a1a1a",
        fontFamily: 'Trebuchet MS", Helvetica, sans-serif',
        fontWeight: 'bold'
    },
    forgotPassword: {
        marginTop: '20px'
    },
    line: {
        width: '112px',
        height: '47px',
        border: '3px solid white',
        position: 'absolute'
    },
    createButton:
    {
        fontSize: 15,
        borderColor: '#1a1a1a',
        color: "#1a1a1a",
        fontFamily: 'Trebuchet MS", Helvetica, sans-serif',
        fontWeight: 'bold'
    },
    Copyright: {
        marginTop: '10px',
        marginBottom: '9px',
        fontSize: 12,
        fontFamily: 'Trebuchet MS", Helvetica, sans-serif',
    }
};

const INITIAL_STATE = {
    name: '',
    userName: '',
    phoneNo: '',
    email_ID: '',
    password: '',
    preferenece:
    {
        Fiction: false,
        Action: false,
        horror: false,
        healthFitenss: false,
        textBook: false,
        comic: false,
        biographies: false,
        others: true
    },
    isPremium: false,
    isAdmin: false,
    isGoogle: false,
    error: true,
    open: false
}

const byPropKey = (propertyName, value) => ({ [propertyName]: value, });

class RegisterForm extends Component {
    constructor() {
        super();
        this.state = { ...INITIAL_STATE }
    }

    validation = () => {
        const { email_ID, phoneNo, password, name } = this.state;
        if (name === '') {
            swal({
                type: 'error',
                title: 'Oops...Wrong Input!!',
                text: 'Please enter Name',
                   })
              return false;
        }
        if (config.REGEX_VALIDATE_FORM.regex.test(name) === false) {
            swal({
                type: 'error',
                title: 'Oops...Wrong Input!!',
                text: 'Name can contains only alphabets and single space between first and last name',
                   })
            
            
            return false;
        }
        if (email_ID === '') {
            swal({
                type: 'error',
                title: 'Oops...Wrong Input!!',
                text: 'Please enter Email ID',
                   })
            
            
            return false;
        }
        else if (config.REGEX_VALIDATE_FORM.mailregex.test(email_ID) === false) {
            swal({
                type: 'error',
                title: 'Oops...Wrong Input!!',
                text: 'Email is not valid',
                   })
            
            return false;
        }
        if (phoneNo === '') {
            swal({
                type: 'error',
                title: 'Oops...Wrong Input!!',
                text: 'Please Phone no.',
                   })
            
            
            return false;
        }
        else if (config.REGEX_VALIDATE_FORM.phoneregex.test(phoneNo) === false) {
            swal({
                type: 'error',
                title: 'Oops...Wrong Input!!',
                text: 'Phone no is not valid',
                   })
            
            
            return false;
        }
        if (password === '') {
            swal({
                type: 'error',
                title: 'Oops...Wrong Input!!',
                text: 'Please enter Password',
                   })
            
            return false;
        }
        else if (config.REGEX_VALIDATE_FORM.passwordregex.test(password) === false) {
            swal({
                type: 'error',
                title: 'Oops...Wrong Input!!',
                text: 'Password length between 8-20 and contain atleast a capital letter , small letter , a number and a special character',
                  })
            
            return false;
        }
        else {
            return true;
        }
    }

    handleSubmit = (event) => {
        const { email_ID, password } = this.state;
        event.preventDefault();
        if (this.validation()) {
            fire.auth().createUserWithEmailAndPassword(email_ID, password).then((data) => {
                this.props.history.push('/Login')
                this.state.userName = data.user.uid;
                swal({
                    position: 'top-end',
                    type: 'success',
                    title: 'Buyer registered succesfully',
                    showConfirmButton: false,
                    timer: 1500
                  })
                buyerRegistration(this.state)
            })
                .catch(error => {
                    if (error.message === "The email address is badly formatted.") {
                        error.message = "Please enter a correct email address"
                    }
                    if (error.message === "The password is invalid or the user does not have a password.") {
                        error.message = "Please enter a correct password"
                    }
                    swal({
                        type: 'error',
                        title: 'Oops...Wrong Input!!',
                        text: `${error}`,
                          })  
                    
                }
                );
        }
    }

    render() {
        const { userName, email_ID, phoneNo, password,  name } = this.state;
        return (
            <div style={styles.card}>
                <center>
                    <p style={styles.maintitle}>
                    </p>
                </center>
                <form style={styles.formText} onSubmit={this.handleSubmit}>
                    <div className="form-group">
                        <p className="formText"> Name</p>
                        <input type="text" className="form-control" id="exampleInputUserName" aria-describedby="usernameHelp" placeholder="Enter Your Name"
                            value={name}
                            onChange={event => this.setState(byPropKey('name', event.target.value))}
                        ></input>
                    </div>
                    <div className="form-group">
                        <p className="formText"> Email ID</p>
                        <input type="text" className="form-control" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Enter Email ID"
                            value={email_ID}
                            onChange={event => this.setState(byPropKey('email_ID', event.target.value))}
                        ></input>
                    </div>
                    <div classNamge="form-group">
                        <p className="formText">Contact Number</p>
                        <input type="text" className="form-control" id="exampleInputContactNumber" aria-describedby="contactnumberHelp" placeholder="Enter Contact Number"
                            value={phoneNo}
                            onChange={event => this.setState(byPropKey('phoneNo', event.target.value))}></input>
                    </div>
                    <div className="form-group">
                        <p> Password </p>
                        <input type="password" className="form-control" id="exampleInputPassword1" placeholder="Enter Password"
                            value={password}
                            onChange={event => this.setState(byPropKey('password', event.target.value))}></input>
                    </div>
                    <center>
                        <button type="submit" onClick={this.handleClick} className="btn btn-primary" style={{ fontFamily: 'Trebuchet MS", Helvetica, sans-serif', fontWeight: 'bold', fontSize: 20, margin: 20 }}>
                            REGISTER</button>
                        <p style={styles.Copyright}>Copyright © 2018 - 2019 Uptown Books LLC. All rights reserved.</p>
                    </center>
                </form>
            </div>
        );
    }
}
export default withRouter(RegisterForm);
