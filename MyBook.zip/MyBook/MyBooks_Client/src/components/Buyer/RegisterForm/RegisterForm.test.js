import RegisterForm from './RegisterForm.jsx'

it('RegisterForm rendering without crashing',()=>{
    shallow(<RegisterForm />);
})