//React Imports
import React, { Component } from 'react';
import { Link } from 'react-router-dom';


class SearchFilter extends Component {

    render() {
        return (<div style={{ overflowX: 'hidden', backgroundColor: '#fbfbfb' }}>
            <center>
                <div className="btn-group" style={{ padding: '1%' }}>
                    <h3 style={{ fontFamily: 'Trocchi, serif' }}>Apply Sorting & Filters to Refine & Explore &nbsp;</h3>
                    <button type="button" className="btn btn-primary">Sort & Filters</button>
                    <button type="button" className="btn btn-primary dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span className="sr-only">Sort & Filters</span>
                    </button>
                    <div className="dropdown-menu">
                        <p className="dropdown-item" >
                            <Link color="inherit" variant="title" to={`/SortbyBookname`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                Sort by Book Name
              </Link>
                        </p>
                        <p className="dropdown-item" >
                            <Link color="inherit" variant="title" to={`/SortbyBookauthor`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                Sort by Author Name
              </Link>
                        </p>
                        <p className="dropdown-item" >
                            <Link color="inherit" variant="title" to={`/SortbyBookcost`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                Sort by Book Cost (Low -> High)
              </Link>
                        </p>
                        <p className="dropdown-item" >
         ks                   <Link color="inherit" variant="title" to={`/SortbyBookcostHigh`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                Sort by Book Cost (High -> Low)
              </Link>
                        </p>
                        <p className="dropdown-item" >
                            <Link color="inherit" variant="title" to={`/SortbyBookrating`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                Sort by Book Rating
              </Link>
                        </p>
                        <div className="dropdown-divider"></div>
                        <p className="dropdown-item" >
                            <Link color="inherit" variant="title" to={`/FilterbyBookcost1to100`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                Filter by Book Cost 1 to 100
              </Link>
                        </p>
                        <p className="dropdown-item" >
                            <Link color="inherit" variant="title" to={`/FilterbyBookcost101to300`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                Filter by Book Cost 101 to 300
              </Link>
                        </p>
                        <p className="dropdown-item" >
                            <Link color="inherit" variant="title" to={`/FilterbyBookcost301andAbove`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                Filter by Book Cost 301 and above
              </Link>
                        </p>
                    </div>
                </div>
            </center>
        </div>
        )
    }
}


export default SearchFilter;

