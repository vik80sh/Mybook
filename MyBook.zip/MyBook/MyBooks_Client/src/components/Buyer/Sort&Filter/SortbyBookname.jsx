//React Imports 
import React from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';

//Material UI Imports 
import Divider from '@material-ui/core/Divider';
import Card from '@material-ui/core/Card';

//Components Import 
import BookCard from '../BookCard/BookCard';
import Categories from '../Home/Categories';
let _ = require('underscore');

const styles = {
    columnTitle: {
        fontWeight: 'bold',
        fontFamily: 'Trocchi, serif',
        left: 0,
        marginLeft: '3.5%',
        marginTop: '15px',
        fontSize: 30,
        color: "#1a1a1a",
        width: "100%",
    },
    card: {
        maxWidth: 280,
        padding: '8px',
        boxShadow: '12px 0 15px -4px rgba(31, 73, 125, 0.3), -12px 0 8px -4px rgba(31, 73, 125, 0.3)',
        margin: '0px auto',
        width: '100%',
        height: '100%',
    }
}

function SortbyBookname({ books }) {
    var sortBooks = _.sortBy(books, 'bookName');

    if (!books.length) {
        return (
            <div>
                No Books is Here Till Now
</div>
        )
    }

    return (
        <div>
            <Categories />
            <Divider />
            <center>
                <div className="btn-group" style={{ padding: '1%' }}>
                    <h3 style={{ fontFamily: 'Trocchi, serif' }}>Apply Sorting & Filters to Refine & Explore &nbsp;</h3>
                    <button type="button" className="btn btn-primary">Sort & Filters</button>
                    <button type="button" className="btn btn-primary dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span className="sr-only">Sort & Filters</span>
                    </button>
                    <div className="dropdown-menu">
                        <p className="dropdown-item" >
                            <Link color="inherit" variant="title" to={`/SortbyBookname`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                Sort by Book Name
              </Link>
                        </p>
                        <p className="dropdown-item" >
                            <Link color="inherit" variant="title" to={`/SortbyBookauthor`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                Sort by Author Name
              </Link>
                        </p>
                        <p className="dropdown-item" >
                            <Link color="inherit" variant="title" to={`/SortbyBookcost`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                Sort by Book Cost (Low -> High)
              </Link>
                        </p>
                        <p className="dropdown-item" >
                            <Link color="inherit" variant="title" to={`/SortbyBookcostHigh`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                Sort by Book Cost (High -> Low)
              </Link>
                        </p>
                        <p className="dropdown-item" >
                            <Link color="inherit" variant="title" to={`/SortbyBookrating`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                Sort by Book Rating
              </Link>
                        </p>
                        <div className="dropdown-divider"></div>
                        <p className="dropdown-item" >
                            <Link color="inherit" variant="title" to={`/FilterbyBookcost1to100`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                Filter by Book Cost 1 to 100
              </Link>
                        </p>
                        <p className="dropdown-item" >
                            <Link color="inherit" variant="title" to={`/FilterbyBookcost101to300`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                Filter by Book Cost 101 to 300
              </Link>
                        </p>
                        <p className="dropdown-item" >
                            <Link color="inherit" variant="title" to={`/FilterbyBookcost301andAbove`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                Filter by Book Cost 301 and above
              </Link>
                        </p>
                    </div>
                </div>
            </center>
            <center><p style={styles.columnTitle}>Books Sorted by Book Name</p></center>
            <div className='row'>
                {sortBooks.map((post) => {
                    return (
                        <div className='col-md-3' style={{ marginBottom: 20 }} key={post._id}>
                            <Link color="inherit" variant="title" to={`/Category/BookPreview/${post._id}`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                <Card style={styles.card}>
                                    <BookCard post={post} key={post._id} />
                                    <button className="btn btn-primary" style={{ fontFamily: 'Berlin Sans fb', fontWeight: 'bold', fontSize: 15, margin: '4px', width: '70%', marginLeft: '15%', marginBottom: '1%' }}>PREVIEW</button>
                                </Card>
                            </Link>
                        </div>
                    );
                })}
            </div>
        </div>
    );
}

const mapStateToProps = state => {
    return {
        books: state.storeSearchResult
    };
};

export default connect(
    mapStateToProps,
)(SortbyBookname);

