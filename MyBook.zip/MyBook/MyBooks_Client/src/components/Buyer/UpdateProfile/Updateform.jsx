//React Imports
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';

//Material UI Imports
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';

//React 3rd Party npm package Imports
import swal from 'sweetalert2';

//Action Imports
import Updatedetails from './../../../actions/actionsUserDetails/actionsUserUpdate';

//Config Import
import config from './../../../config.js';

const INITIAL_STATE = {
  name: '',
  phoneNo: ''
};

const byPropKey = (propertyName, value) => ({ [propertyName]: value });
let email_ID;
class Updateform extends Component {
  constructor({ props, match }) {
    super(props);
    email_ID = match.params.email_ID;
    this.state = { ...INITIAL_STATE };
  }

  componentDidMount() {
    this.props.user.map(user => {
      if (user.email_ID === email_ID) {
        this.setState({
          name: user.name,
          phoneNo: user.phoneNo
        })
      }
    })
  }

  validation = () => {
    const { name, phoneNo } = this.state;
    if (name === '') {
      swal({
        type: 'error',
        title: 'Oops...Wrong Input!!',
        text: 'Please enter Name',
          })
            return false;
    }
    if (config.REGEX_VALIDATE_FORM.regex.test(name) === false) {
      swal({
        type: 'error',
        title: 'Oops...Wrong Input!!',
        text: 'Name can contains only alphabets and single space between first and last name',
          })
      
        return false;
    }
    if (phoneNo === '') {
      swal({
        type: 'error',
        title: 'Oops...Wrong Input!!',
        text: 'Please enter Phone no.',
          })
      
      
      return false;
    }
    else if (config.REGEX_VALIDATE_FORM.phoneregex.test(phoneNo) === false) {
      swal({
        type: 'error',
        title: 'Oops...Wrong Input!!',
        text: 'Phone no is not valid',
          })
      
      
      return false;
    }
    else {
      return true;
    }
  }

  handleSubmit = (event) => {
    // const { name, phoneNo } = this.state;
    if (this.validation()) {
      swal({
        position: 'top-end',
        type: 'success',
        title: 'Profile Updated succesfully',
        showConfirmButton: false,
        timer: 1500
      })
      this.props.dispatch(Updatedetails(this.state));

      this.props.history.push("/UserDetails");
    }
    event.preventDefault();
  };

  render() {
    const { name, phoneNo } = this.state;
    return (
      <div style={{marginBottom:'21.5%'}}>
        <br />
        <br />
        <center>
          <h1>Update your details</h1>
          <Card style={{ width: "50%", height: "80%" }}>
            <CardContent>
              <form onSubmit={this.handleSubmit}>
                <label>User Name:</label>
                <br />
                <input type="text"
                  value={name}
                  onChange={event => { this.setState(byPropKey('name', event.target.value)) }} />
                <br />
                <label>Phone number:</label>
                <br />
                <input type="text"
                  value={phoneNo}
                  onChange={event => { this.setState(byPropKey('phoneNo', event.target.value)) }} />
                <br />
                <br />
                <br />
                <Link to="/UserDetails">
                  <Button variant="contained">Back</Button>
                </Link>
                <Button type="submit" variant="contained" style={{ marginLeft: 50 }}>Save</Button>
              </form>
            </CardContent>
          </Card>
        </center>
      </div>
    )
  }
};

const mapStateToProps = (state) => {
  return {
    user: state.storeUserData
  }
};

export default connect(mapStateToProps, null)(Updateform);