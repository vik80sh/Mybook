//React Imports
import React from 'react';
import StarRatingComponent from 'react-star-rating-component';

//Material UI Imports
import TextField from '@material-ui/core/TextField';

export class Rating extends React.Component {
  constructor() {
    super();
    this.state = {
      rating: 1,
      feedback: 'g'
    };
  }

  onStarClick(nextValue, prevValue, name) {
    this.setState({
      rating: nextValue,
    });
  }

  onChangeFeedback = (event) => {
    this.setState({ feedback: event.target.value });
    console.log("Hello ", this.state.feedback)
  }

  render() {
    return (
      <div class="row">
        <h2>Rating from state: {this.state.rating}</h2>
        <h4>feedback: {this.state.feedback}</h4>
        <div>
          <StarRatingComponent
            name="rate1"
            starCount={5}
            value={this.state.rating}
            onStarClick={this.onStarClick.bind(this)}
          />
        </div>
        <textarea
          label="Type Something..."
          margin="normal"
          onChange={this.onChangeFeedback} rows="3" col="4">
        </textarea>
      </div>
    );
  }
}