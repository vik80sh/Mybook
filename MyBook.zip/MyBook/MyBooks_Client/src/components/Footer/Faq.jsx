//React Imports
import React from 'react';

class Faq extends React.Component {
    render() {
        return (<div>
            <br /><br />
            <center>  <h3> Frequently Asked Questions</h3> </center>
            <br /><br />
            <h4>Is it necessary to have an account to shop on Uptown Books?</h4>
            <h6>Yes, it's necessary to log into your Uptown account to shop. Shopping as a logged-in user is fast & convenient and also provides extra security.</h6>
            <h6>You'll have access to a personalised shopping experience including recommendations and quicker check-out.</h6><br />
            <h4>What does 'Preorder' or 'Forthcoming' mean?</h4>
            <h6>Items marked as 'Preorder' or 'Forthcoming' are expected to be released soon and you can pre-book them with sellers. Such items will be shipped after their official release by the seller with whom you've pre-booked them.</h6><br />
            <h4>I missed the delivery of my order today. What should I do?</h4>
            <h6>The courier service delivering your order usually tries to deliver on the next business day in case you miss a delivery.</h6>
            <h6>You can check your SMS for more details on when the courier service will try to deliver again.</h6>
            <br />
            <h5>What should I do if my order is approved but hasn't been shipped yet?</h5>
            <h6>Sellers usually ship orders 1-2 business days before the delivery date so that they reach you on time. In case your order hasn't been shipped within this time please contact our Customer Support so that we can look into it.</h6>
        </div>)
    }
}

export default Faq;