import React from 'react';
import ReactDOM from 'react-dom';
import Faq from './Faq.jsx';

it('faq render without crashing', () => {
    shallow(<Faq />);
});