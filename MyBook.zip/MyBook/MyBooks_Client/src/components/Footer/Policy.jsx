//React Imports
import React from 'react';

class Policy extends React.Component {
    render() {
        return (<div style={{ minHeight: 500 }}>
            <center><h1>Cancellation and Returns Policy</h1></center><br />
            <h5>Do I have to return the freebie when I return a product?</h5>
            <h6>Yes, the freebie has to be returned along with the product.</h6><br />
            <h5>Can items be returned after the time period mentioned in the seller's Returns Policy?</h5>
            <h6>No, sellers will not be able to accept returns after the time period mentioned in the seller's Returns Policy.</h6><br />
            <h5>If I request for a replacement, when will I get it?</h5>
            <h6>Visit My Orders to check the status of your replacement.</h6>
            <h6>In most locations, the replacement item is delivered to you at the time of pick-up. In all other areas, the replacement is initiated after the originally delivered item is picked up.</h6><br />
        </div>)
    }
}

export default Policy;