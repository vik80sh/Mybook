import React from 'react';
import ReactDOM from 'react-dom';
import Policy from './Policy.jsx';

it('Policy render without crashing', () => {
    shallow(<Policy />);
});