//React Imports
import React, { Component } from 'react';
import { Route, Redirect } from 'react-router-dom'

//Components Import
import {  AdminloginLogout, SellerloginLogout, login,Feedback } from '../SessionManagement/SessionManagement';

//Container Imports
// import adminNavbar from '../../containers/Admin/adminNavbar';

export const PrivateRoutesForAdmin = ({ component: Component, ...rest }) => (
  <Route {...rest} render={(props) => (
    (AdminloginLogout() === true)
      ? <Component {...props} /> : <Redirect to={'/'} />
  )} />
)

export const LoginRoutes = ({ component: Component, ...rest }) => (
  <Route {...rest} render={(props) => (
    (login() === true)
      ? <Component {...props} />
      : <Redirect to={'/ErrorMessage'} />
  )} />
)

export const ErrorRoutes = ({ component: Component, ...rest }) => (
  <Route {...rest} render={(props) => (
    (login() === false)
      ? <Component {...props} />
      : <Redirect to={'/Login'} />
  )} />
)

export const PrivateRoutesForUser = ({ component: Component, ...rest }) => (
  <Route {...rest} render={(props) => (
    ((AdminloginLogout() === false) && (login() === false))
      ? <Component {...props} /> : <Redirect to={'/adminNavbar'} />
  )} />
)

export const PrivateRoutesForSeller = ({ component: Component, ...rest }) => (
  <Route {...rest} render={(props) => (
    ((SellerloginLogout() === true))
      ? <Component {...props} /> : <Redirect to={'/SellerLogin'} />
  )} />
)
export const PrivateRoutesForFeedback = ({ component: Component, ...rest }) => (
  <Route {...rest} render={(props) => (
    ((Feedback() === true))
      ? <Component {...props} /> : <Redirect to={'/'} />
  )} />
)


