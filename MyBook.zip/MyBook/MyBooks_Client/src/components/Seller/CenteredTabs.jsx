//React Imports
import React from 'react';
import PropTypes from 'prop-types';
import {Link } from 'react-router-dom';

//Material UI Imports
import { withStyles } from '@material-ui/core/styles';
import Paper from '@material-ui/core/Paper';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';

const styles = {
  root: {
    flexGrow: 1,
  },
};

let matchParams;
class CenteredTabs extends React.Component {
  constructor(props) {
    super(props)
    matchParams = this.props.sellerID
   
  }

  

  render() {
    const { classes } = this.props;
    //const { value } = this.state;
    return (
      <div>
        <Paper className={classes.root}>
          <Tabs
            /* value={this.state.value} */
           // onChange={this.handleChange}
            indicatorColor="primary"
            textColor="primary"
            variant="contained"
            centered
          >
            <Tab label="ManageBooks" component={Link} to='/ManageBooksSeller' />
            <Tab label="Statistics" component={Link} to={`/SellerNavBar/${matchParams}`} />
            <Tab label="Add Books" component={Link} to={`/SellerAddBookForm/${matchParams}`} />
            <Tab label="User Profile" component={Link} to={'/SellerProfile'} />
          </Tabs>
        </Paper>
      </div>
    );
  }
}

CenteredTabs.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(CenteredTabs);