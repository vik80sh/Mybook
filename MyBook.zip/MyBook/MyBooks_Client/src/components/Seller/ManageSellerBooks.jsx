//React Imports
import React from 'react';
import { connect } from 'react-redux'
import {Link } from 'react-router-dom';
import { bindActionCreators } from 'redux';

//Material UI Imports
import Card from '@material-ui/core/Card';
import Divider from '@material-ui/core/Divider';

//Components Import
import BookCard from '../Buyer/BookCard/BookCard';
import CenteredTabs from './CenteredTabs';

//Action Imports
import deleteBookFromCollection from '../../actions/actionsCRUDonBooks/actionsDeleteBookFromCollection';


let flag = false;
const styles = {
    card: {
        maxWidth: 280,
        padding: '8px',
        boxShadow: '12px 0 15px -4px rgba(31, 73, 125, 0.3), -12px 0 8px -4px rgba(31, 73, 125, 0.3)',
        margin: '0px auto',
        width: '100%',
        height: '100%',
    },
    alignRight: {
        color: "inherit",
        fontSize: "25px",
        fontWeight: "bold",
        marginLeft: "25px",
        textDecoration: "none"
    }
}

const sellerID = localStorage.getItem('sellerID');


function ManageBooksBySeller({ match, books, deleteBookFromCollection }) {
    const matchParams = sellerID;
    return (
        <div>
            <CenteredTabs sellerID={matchParams} />
            <Divider />
            <br /><br />
            <center> <h2>{`Entire Books List Added by ${matchParams}`}</h2> </center>
            <br /><br />
            <div className='row'>
                {books.map((post,key) => {
                    if (post.seller_ID === matchParams) {
                        flag = true;
                        return (
                            <div className='col-md-3' style={{ marginBottom: 20 }} key={post._id}>
                                <Card style={styles.card}>
                                    <Link color="inherit" variant="title" to={`/AdminBookPreview/${post._id}`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                        <BookCard post={post} key={post._id} />
                                    </Link>
                                    <Link color="inherit" variant="title" to={`/UpdateBookSeller/${post._id}`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                        <button className="btn btn-primary" style={{ fontFamily: 'Berlin Sans fb', fontWeight: 'bold', fontSize: 15, margin: '4px', width: '70%', marginLeft: '15%', marginBottom: '1%' }}>UPDATE</button>
                                    </Link>
                                    <button className="btn btn-danger" onClick={() => deleteBookFromCollection(post._id)} style={{ fontFamily: 'Berlin Sans fb', fontWeight: 'bold', fontSize: 15, margin: '4px', width: '70%', marginLeft: '15%', marginBottom: '1%' }}>DELETE </button>
                                </Card>
                            </div>
                        )
                    }
                })}
                {!flag &&
                    <h2 style={{ textAlign: 'center' }}>-------NO BOOKS ENTERED BY YOU---------  </h2>}
            </div>
        </div>
    )
}

const mapStateToProps = state => {
    return {
        books: state.storeBookData
    }
}

const mapDispatchToProps = dispatch => {
    return bindActionCreators({ deleteBookFromCollection: deleteBookFromCollection }, dispatch)
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(ManageBooksBySeller);