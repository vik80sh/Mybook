//React Imports
import React from "react";
import { Link } from "react-router-dom";

//Material UI Imports
import Button from "@material-ui/core/Button";
import Menu from "@material-ui/core/Menu";
import MenuItem from "@material-ui/core/MenuItem";


//Components Import
import { SellerloginLogout } from "../SessionManagement/SessionManagement";

const styles = {
  alignRight: {
    color: "inherit",
    fontSize: "22px",
    marginTop: 5,
    marginRight:90,
    textDecoration: "none"
  }
}

class SimpleMenu extends React.Component {
  constructor() {
    super()
    this.state = {
      anchorEl: null
    };
    this.handleLogOut = this.handleLogOut.bind(this);
  }

  handleClick = event => {
    this.setState({ anchorEl: event.currentTarget });
  };

  handleClose = () => {
    this.setState({ anchorEl: null });
  };

  handleLogOut = event => {
    console.log("Hello LogOut ")
    // let localStorageToken = localStorage.getItem('isSellerLoggedIn');
    localStorage.removeItem('isSellerLoggedIn');
    this.handleClose();
  };

  render() {
    const { anchorEl } = this.state;
    // let localStorageToken = localStorage.getItem('isSellerLoggedIn');
    return (
      <div>
        {!SellerloginLogout() && (
          <div>
            <Button
              aria-owns={anchorEl ? "simple-menu" : null}
              aria-haspopup="true"
              onClick={this.handleClick}
              style={styles.alignRight}
            >
              More
            </Button>
            <Menu
              id="simple-menu"
              anchorEl={anchorEl}
              open={Boolean(anchorEl)}
              onClose={this.handleClose}
            >
              <Link color="inherit" to="/SellerLogin" style={{ textDecoration: 'none', boxDecorationBreak: 'none' }}>
                <MenuItem onClick={this.handleClose}>Sell Books on UpTown Books</MenuItem>
              </Link>
            </Menu>
          </div>
        )}
      </div>
    );
  }
}

export default SimpleMenu;
