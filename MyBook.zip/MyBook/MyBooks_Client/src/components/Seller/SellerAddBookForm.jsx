//React Imports
import React from 'react';
import { connect } from 'react-redux';

//Material UI Imports
import TextField from '@material-ui/core/TextField';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import Checkbox from '@material-ui/core/Checkbox';

//Action Imports
import Addbook from '../../actions/actionsAdmin/actionsAdmin';

//Config Import
import CenteredTabs from './CenteredTabs';
import config from '../../config.js';

//React 3rd Party npm package Imports
import swal from 'sweetalert2';

// const styles = {
//   alignRight: {
//     color: "inherit",
//     fontSize: "25px",
//     fontWeight: "bold",
//     marginLeft: "25px",
//     textDecoration: "none"
//   }
// }

// const whenClick = () => {
//   localStorage.clear();
// };

const INITIAL_STATE = {
  ISBN: '',
  bookName: '',
  fiction: false,
  action: false,
  horror: false,
  health: false,
  textbook: false,
  comics: false,
  biography: false,
  romance: false,
  adventure: false,
  others: true,
  imageURL: '',
  author: '',
  description: '',
  bookCost: '',
  bookQuantity: '',
  seller_ID: '',
};

let matchParams;
const byPropKey = (propertyName, value) => ({ [propertyName]: value, });

class SellerAddBookForm extends React.Component {
  constructor({ match }) {
    super();
    this.state = { ...INITIAL_STATE }
    matchParams = match.params.id;

  }

  handleChecked = (name) => (event) => {
    this.setState({ [name]: event.target.checked });
  }

  isValid = () => {
     if (/[1-9]+[.]/.test(this.state.ISBN) === true || this.state.ISBN < 1 || this.state.bookRating.length>6) {
      swal({
          type:'error',
          title :'Oops... Wrong Input!!',
          text:'ISBN Should only contain numbers and more than 5 digit'
       })
      return false;
  }
    else if (this.state.bookName.trim().length > 30 || this.state.bookName.trim().length < 1) {
      swal({
        type:'error',
        title :'Oops... Wrong Input!!',
        text:'BookName should conatin characters between 1 and 30 '
     })
      return false;
    }
    else if (config.REGEX_VALIDATE_FORM.regex.test(this.state.author.trim()) === false || this.state.author.trim().length > 30) {
      swal({
        type:'error',
        title :'Oops... Wrong Input!!',
        text:'Author name  should be more than 1 and less than 30 letters and only alphabets'
     })
      return false;
    }

    else if (this.state.description.trim().length < 100 || this.state.description.trim().length>1000) {
      swal({
        type:'error',
        title :'Oops... Wrong Input!!',
        text:'Description should be more than 100 letters and less than 1000'
     })
      return false;
    }
    else if (this.state.bookCost < 1 || (this.state.bookCost>1500)) {
      swal({
        type:'error',
        title :'Oops... Wrong Input!!',
        text:'Enter proper cost details cost should be more than 0 and cost should not be more than 1500'
     })
      return false;
    }
    else if (/[1-9]+[.]/.test(this.state.bookQuantity) === true || this.state.bookQuantity < 5 ) {
      swal({
        type:'error',
        title :'Oops... Wrong Input!!',
        text:'Book quantity should be 5 0r more  and decimals ashould not be present'
     })
      return false;
    }
    else if (/[1-9]+[.]/.test(this.state.bookCost) === true || this.state.bookCost < 1) {
      swal({
        type:'error',
        title :'Oops... Wrong Input!!',
        text:'Enter proper cost details cost should be more than 0 and should not contain any decimals'
     })
      return false;
    }
    else if (this.state.seller_ID.trim().length > 20 || this.state.seller_ID.trim().length < 1) {
      swal({
        type:'error',
        title :'Oops... Wrong Input!!',
        text:'Enter Seller_ID'
     })
      return false;
    }
    else if (/[1-9]+[.]/.test(this.state.bookRating) === true || this.state.bookRating < 1 || this.state.bookRating > 5) {
      swal({
          type:'error',
          title :'Oops... Wrong Input!!',
          text:'Enter proper rating details rating should be below or equal to 5 and above or equal to 1 (Not including the decimal)'
       })
      return false;
  }
    return true;
  }

  handleSubmit = (event) => {
    // eslint-disable-next-line
    this.setState(byPropKey('seller_ID', matchParams))
    if (this.isValid()) {
      this.props.dispatch(Addbook(this.state));
     
      this.props.history.push(`/ManageBooksSeller`)
    }

    event.preventDefault();
  };

  render() {
    //const { classes } = this.props;
    return (<div>
      <br />
      <CenteredTabs sellerID={matchParams} />
      <br />
      <center>
        <div className="container-fluid" style={{ backgroundColor: "#ffffff" }}>
          <div className="row">
            <div className="col-lg-3">
            </div>
            <div className="col-lg-6">
              <br />
              <h1>Add books</h1>
              <br />
              <br />
              <Card style={{ backgroundColor: "#e6feeb" }}>
                <CardContent>
                  <form onSubmit={this.handleSubmit}>
                    <TextField
                      id="ISBN"
                      label="ISBN"
                      placeholder="Enter ISBN"
                      margin="normal"
                      type="Number"
                      style={{ width: 400, padding: 12 }}
                      value={this.state.ISBN}
                      onChange={event => { this.setState(byPropKey('ISBN', event.target.value)) }}
                      required
                    />
                    <TextField
                      type="text"
                      id="bookName"
                      label="bookName"
                      style={{ width: 400, padding: 12 }}
                      placeholder="Enter bookName"
                      margin="normal"
                      value={this.state.bookName}
                      onChange={event => this.setState(byPropKey('bookName', event.target.value))}
                      required
                    />
                    <br />
                    <br />
                    <div className="row">
                    <div className="col-lg-3">
                    </div>
                    <div className="col-lg-3">
                      <Checkbox
                        type="checkbox"
                        checked={this.state.ficton}
                        onChange={this.handleChecked('fiction')}
                        value='fiction'
                        style={{ width: 30, margin: 10 }}
                      />fiction
                      <br />
                      <Checkbox
                        type="checkbox"
                        checked={this.state.action}
                        onChange={this.handleChecked('action')}
                        style={{ width: 30, margin: 10 }}
                      />action
                      <br />
                      <Checkbox
                        type="checkbox"
                        checked={this.state.horror}
                        onChange={this.handleChecked('horror')}
                        style={{ width: 30, margin: 10 }}
                      />horror
                      <br />
                      <Checkbox
                        type="checkbox"
                        checked={this.state.romance}
                        onChange={this.handleChecked('romance')}
                        style={{ width: 30, margin: 10, marginRight: 10 }}
                      />romance
                      <br />
                      <Checkbox
                        type="checkbox"
                        checked={this.state.health}
                        onChange={this.handleChecked('health')}
                        style={{ width: 30, margin: 10 }}
                      />health
                      <br />
                    </div>
                    <div className="col-lg-3">
                      <Checkbox
                        type="checkbox"
                        checked={this.state.comics}
                        onChange={this.handleChecked('comics')}
                        style={{ width: 30, margin: 10 }}
                      />comics
                      <br />
                      <Checkbox
                        type="checkbox"
                        checked={this.state.textbook}
                        onChange={this.handleChecked('textbook')}
                        style={{ width: 30, margin: 10 }}
                      />textbook
                      <br />
                      <Checkbox
                        type="checkbox"
                        checked={this.state.biography}
                        onChange={this.handleChecked('biography')}
                        style={{ width: 30, margin: 10 }}
                      />biography
                      <br />

                      <Checkbox
                        type="checkbox"
                        checked={this.state.adventure}
                        onChange={this.handleChecked('adventure')}
                        style={{ width: 30, margin: 10 }}
                      />adventure
                      <br />
                      <Checkbox
                        type="checkbox"
                        checked={this.state.others}
                        onChange={this.handleChecked('others')}
                        style={{ width: 30, margin: 10 }}
                      />others
                      <br />
                    </div>
                    <div className="col-lg-2">
                    </div>
                  </div>
                  <TextField
                      id="author"
                      label="author"
                      type="text"
                      placeholder="Enter Author Name"
                      margin="normal"
                      style={{ width: 400, padding: 12 }}
                      value={this.state.author}
                      onChange={event => this.setState(byPropKey('author', event.target.value))}
                      required
                    />
                    <TextField
                      id="bookCost"
                      label="bookCost"
                      type="Number"
                      placeholder="Enter the bookCost"
                      margin="normal"
                      style={{ width: 400, padding: 12 }}
                      value={this.state.bookCost}
                      onChange={event => this.setState(byPropKey('bookCost', event.target.value))}
                      required
                    />
                    <br />
                    <br />
                    <TextField
                      id="bookQuantity"
                      label="bookQuantity"
                      type="Number"
                      placeholder="Enter the bookQuantity"
                      margin="normal"
                      style={{ width: 400, padding: 12 }}
                      value={this.state.bookQuantity}
                      onChange={event => this.setState(byPropKey('bookQuantity', event.target.value))}
                      required
                    />
                    <TextField
                      id="bookRating"
                      label="bookRating"
                      type="Number"
                      style={{ width: 400, padding: 12 }}
                      placeholder="Enter the bookRating"
                      margin="normal"
                      value={this.state.bookRating}
                      onChange={event => this.setState(byPropKey('bookRating', event.target.value))}
                      required
                    />
                    <br /><br />
                    <TextField
                      id="imageURL"
                      label="imageURL"
                      type="text"
                      placeholder="Enter the imageURL"
                      margin="normal"
                      style={{ width: 400, padding: 12 }}
                      value={this.state.imageURL}
                      onChange={event => this.setState(byPropKey('imageURL', event.target.value))}
                      required
                    />
                    <br /><br />
                    <TextField
                      id="description"
                      label="description"
                      type="text"
                      placeholder="Enter the description"
                      margin="normal"
                      style={{ width: 400, padding: 12 }}
                      value={this.state.description}
                      onChange={event => this.setState(byPropKey('description', event.target.value))}
                      required
                    />
                    <br /><br />
                    <TextField
                      id="seller_id"
                      label="seller_id"
                      placeholder="Click For Seller_ID"
                      margin="normal"
                      style={{ width: 400, padding: 12 }}
                      value={this.state.seller_ID}
                      /* readonly */
                      onClick={event => this.setState(byPropKey('seller_ID', matchParams))}
                    />
                    <br />
                    <br />
                    <br />
                    <Button variant="contained" color="secondary" type="submit" >Add Book</Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </center>
    </div>
    );
  }
}

const mapStateToProps = (state) => {
  return state;
};

export default connect(mapStateToProps)(SellerAddBookForm);