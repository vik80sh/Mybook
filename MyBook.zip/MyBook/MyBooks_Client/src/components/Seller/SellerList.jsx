//React Imports
import React from 'react';
import { connect } from 'react-redux';

//Material UI Imports
import Card from '@material-ui/core/Card';

//Action Imports
import { fetchSellers } from './../././../actions/actionsSellerRegistration/fetchSellers';

//Components Import
import CenteredTabs from '../Admin/CenteredTabs';


class SellerList extends React.Component {
    constructor(props) {
        super(props);
        this.props.onFetchSellers();
    }

    render() {
        return (
            <div className="container-fluid">
                <CenteredTabs />
                <div className="row">
                    <div className="col-2">
                    </div>
                    <div className="col-8">
                        <br />
                        <br />
                        <br />
                        <center><Card style={{ width: "50%", backgroundColor: "#0099cc", color: "white" }}>
                            <h1>Sellers List</h1>
                        </Card></center>

                        <Card>
                            <br />
                              <div className="row">
                            {this.props.sellers.map((data, key) => {
                                if (data.isVerified === true) {
                                    return (
                                        <div key={data._id} className="col-4">
                                            
                                            <div className="card" style={{width:'18rem',marginRight:10,marginLeft:10,marginTop:10,marginBottom:20}}>
                                                <div className="card-body">
                                                    <h5 className="card-title">{data.userName}</h5>
                                                    <h6 className="card-subtitle mb-2 text-muted">Details</h6>
                                                    <p className="card-text"> Email_id:{data.email_ID}<br />
                                                    Phone:{data.address.phoneNo}
                                                    </p>
                                                </div>
                                                <br/>
                                            </div>
                                           
                                         

                                        </div>
                                    )
                                }
                            })}
                            </div>
                        </Card>
                        <br />
                        <br />
                    </div>
                    <div className="col-2">
                    </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        sellers: state.storeSellerData
    };
};

const mapDispatchToProps = dispatch => {
    return {
        onFetchSellers: () => {
            dispatch(fetchSellers());
        }
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(SellerList);