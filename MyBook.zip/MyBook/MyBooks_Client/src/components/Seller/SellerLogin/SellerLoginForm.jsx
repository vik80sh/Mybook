//React Imports
import React from 'react';
import { Link } from "react-router-dom";



//Config Import
import config from '../../../config.js';

//Material UI Imports
import Card from '@material-ui/core/Card';
import Button from '@material-ui/core/Button';
//import { SellerloginLogout } from "../../../components/SessionManagement/SessionManagement";

//Image Import
import bookIcon from "../../../Assests/MyBooksIcon/myBooksIcon.png";

//React 3rd Party npm package Imports
import swal from 'sweetalert2';

const styles = {
    card: {
        maxWidth: "80%",
        display: "block",
        margin: "0px auto",
        marginTop: "10px",
        height: "auto",
        position: "relative"
    },
    bullet: {
        display: "inline-block",
        margin: "0 2px",
        transform: "scale(0.8)"
    },
    title: {
        marginBottom: 16,
        fontSize: 17,
        color: "#1a1a1a",
        fontFamily: "Tahoma, Geneva, sans-serif"
    },
    maintitle: {
        marginTop: 10,
        marginBottom: 13,
        fontSize: 33,
        color: "#1a1a1a",
        fontFamily: 'Arial Black", Gadget, sans-serif',
        fontWeight: "bold",
        textAlign: "center"
    },
    titleAuthor: {
        alignText: "center",
        fontSize: 17,
        fontWeight: "bold"
    },
    pos: {
        marginBottom: 12
    },
    formText: {
        fontSize: 18,
        color: "#1a1a1a",
        fontFamily: "Tahoma, Geneva, sans-serif"
    },
    buttonText: {
        fontSize: 15,
        color: "#000000",
        fontFamily: 'Trebuchet MS", Helvetica, sans-serif',
        fontWeight: "bold"
    },
    forgotPassword: {
        marginTop: "20px"
    },
    line: {
        width: "112px",
        height: "47px",
        border: "3px solid white",
        position: "absolute"
    },
    createButton: {
        fontSize: 15,
        borderColor: "#1a1a1a",
        color: "#1a1a1a",
        fontFamily: 'Trebuchet MS", Helvetica, sans-serif',
        fontWeight: "bold"
    },
    Copyright: {
        fontSize: 12,
        fontFamily: 'Trebuchet MS", Helvetica, sans-serif'
    }
};


export default class SellerLoginForm extends React.Component {

    state = {
        UserName: '',
        Password: ''
    }

    handleInputChange = e => {
        this.setState({
            [e.target.name]: e.target.value
        });
    };

    validation = () => {
        const { UserName, Password } = this.state;
        if (config.REGEX_VALIDATE_FORM.mailregex.test(UserName.trim()) === false) {
            swal({
                type:'error',
                title :'Oops... Wrong Input!!',
                text:'Enter correct Email-ID'
             })
            
            return false;
        }
        else {
            return true;
        }
    };

    handleSubmit = e => {

        e.preventDefault();
       
            if (this.validation()) {
                this.props.onSellerLoginData(this.state);
              
            }
           
        }
    

    handleReset = () => {
        this.setState({
            UserName: '',
            Password: ''
        });
    };

    render() {
        return (
            <div className='container'>
                <div style={{
                    backgroundColor: '#ffffff', position: 'relative',
                    width: '100%',
                    height: 'auto'
                }}>
                    <Card style={{ marginTop: '5%', marginBottom: '4%', boxShadow: '22px 0 20px -4px rgba(31, 73, 125, 0.3), -12px 0 8px -4px rgba(31, 73, 125, 0.3)' }}>
                        <div style={styles.card}>
                        <p style={styles.maintitle}>
                                <img src={bookIcon} alt="Up Town Books" height="55px" width="55px" style={{ margin: 10 }} />Uptown Books
                                            Seller Login</p>
                                <form style={styles.formText} onSubmit={this.handleSubmit}>
                                    <div className="form-group">
                                        <br />
                                        <p style={{ textAlign: "left" }}> Email ID: </p>
                                        <input
                                            type="text"
                                            className="form-control"
                                            id="UserName"
                                            name="UserName"
                                            placeholder="Enter Seller Email id"
                                            onChange={this.handleInputChange}
                                            value={this.state.UserName}
                                            required />
                                    </div>
                                    <br />
                                    <div className="form-group">
                                        <p style={{ textAlign: "left" }}> Password : </p>

                                        <input
                                            type="password"
                                            className="form-control"
                                            id="Password"
                                            name="Password"
                                            placeholder="Enter Password"
                                            onChange={this.handleInputChange}
                                            value={this.state.Password}
                                            required />
                                    </div>
                                    <center>
                                        <button
                                            type="submit"
                                            className="btn btn-primary"
                                            style={{
                                                fontFamily: 'Trebuchet MS", Helvetica, sans-serif',
                                                fontWeight: "bold",
                                                fontSize: 20
                                            }}
                                        >
                                            LOGIN
                                        </button>
                                        <p style={styles.forgotPassword}>--- Want to Sell your books ? ---</p>
                                        <Link
                                            color="inherit"
                                            variant="title"
                                            to="/sellerregistration"
                                            style={{ color: "#1a1a1a", textDecoration: "none" }}
                                        >
                                            <Button variant="outlined" style={styles.createButton}>
                                                Create an Account
                                            </Button>
                                        </Link>
                                        <br />
                                        <br />
                                        <p style={styles.Copyright}>
                                            Copyright © 2018 - 2019 Uptown Books LLC. All rights reserved.
                                          </p>
                                    </center>
                                </form>
                           
                        </div>
                    </Card>
                </div>
            </div>

        )
    }
}
