import SellerLoginForm from './SellerLoginForm.jsx'

it('SellerLoginForm rendering without crashing',()=>{
    shallow(<SellerLoginForm />);
})