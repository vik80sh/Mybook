//React Imports
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';

//Material UI Imports
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';

//Action Imports
import { fetchsellerdetails } from '../../actions/actionsSellerDetails/actionsSellerDetails';

//Components Import
import CenteredTabs from './CenteredTabs';

let matchParams;

class SellerProfile extends Component {
    constructor(props) {
        super(props);
        const sellerID = localStorage.getItem('sellerID');
        matchParams = sellerID;
        this.props.onFetchseller(sellerID);
    }

    render() {
        return (
            <div>
                <br />
                <CenteredTabs sellerID={matchParams} />
                <br />
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-3">
                        </div>
                        {this.props.seller.map((data, key) =>
                            <div className="col-md-6" key={data._id}>
                                <br />
                                <Card>
                                    <CardContent>
                                        <center>
                                            <h3>Your Details</h3>
                                        </center>
                                        <hr />
                                        <div>
                                            <h6>NAME</h6><h5>{data.address.name}</h5>
                                            <br />
                                            <h6>UserName:</h6><h5>{data.userName}</h5>
                                            <br />
                                            <h6>Email ID:</h6><h5>{data.email_ID}</h5>
                                            <br />
                                            <hr />
                                            <center>
                                                <h4>Address</h4>
                                            </center>
                                            <hr />
                                            <h6>FlatNo</h6><h5>{data.address.flatNo}</h5>
                                            <br />
                                            <h6>Area:</h6><h5>{data.address.area}</h5>
                                            <br />
                                            <h6>State:</h6><h5>{data.address.state}</h5>
                                            <br />
                                            <h6>PIN:</h6><h5>{data.address.pin}</h5>
                                            <hr />
                                            <center>
                                                <h4>PAN details</h4>
                                            </center>
                                            <hr />
                                            <h6>PAN:</h6><h5>{data.PAN}</h5>
                                            <br />
                                        </div>
                                        <br />
                                        <br />
                                        <Link to="/ManageBooksSeller">
                                            <Button>Back</Button>
                                        </Link>
                                        <Link to={`/Updatesellerdetails/${data.email_ID}`}>
                                            <Button style={{ marginLeft: 250 }}>Edit</Button>
                                        </Link>
                                    </CardContent>
                                </Card>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        seller: state.storeSellerData
    };
};

const mapDispatchToProps = dispatch => {
    return {
        onFetchseller: (userName) => {
            dispatch(fetchsellerdetails(userName));
        },
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(SellerProfile);