//React Imports
import React from 'react';
import { connect } from 'react-redux';

//Material UI Imports
import Button from '@material-ui/core/Button';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
//Action Imports
import Seller from '../../actions/actionsSellerRegistration/actionsSellerRegistration';

//Config Import
import config from '../../config.js';

//React 3rd Party npm package Imports
import swal from 'sweetalert2';

const styles = {
    containerfluid: {
        backgroundColor: "whitesmoke"
    }
}

let INITIAL_STATE = {
    msg: "",
    Name: '',
    userName: '',
    email_ID: '',
    Phone: '',
    password: '',
    GST_NO: '',
    PAN: '',
    isVerified: false,
    area: '',
    flatNo: '',
    landmark: '',
    state: '',
    pin: ''
}

const byPropKey = (propertyName, value) => ({ [propertyName]: value });

class SellerRegistration extends React.Component {
    constructor() {
        super();
        this.state = { ...INITIAL_STATE }
    }

    isValid = () => {
        const { Name, userName, email_ID, Phone, password, GST_NO, PAN,
            state, pin } = this.state;
        if (Name === '') {
            this.setState({ msg: "Enter name" })
            return false;
        }
        else if (config.REGEX_VALIDATE_FORM.regex.test(Name) === false) {
            swal({
                type: 'error',
                title: 'Oops... Wrong Input!!',
                text: 'Name can contains only alphabets and single space between first and last name'
            })

            return false;
        }
        else if (userName.trim() === '') {
            swal({
                type: 'error',
                title: 'Oops... Wrong Input!!',
                text: 'username  is not valid'
            })
            return false;
        }
        else if (email_ID === '') {
            this.setState({ msg2: "Enter correct emailid" })
            return false;
        }
        else if (config.REGEX_VALIDATE_FORM.mailregex.test(email_ID) === false) {
            swal({
                type: 'error',
                title: 'Oops... Wrong Input!!',
                text: 'Email is not valid'
            })

            return false;
        }
        else if (Phone === '') {
            swal({
                type: 'error',
                title: 'Oops... Wrong Input!!',
                text: 'Please Phone no.'
            })
            return false;
        }
        else if (config.REGEX_VALIDATE_FORM.phoneregex.test(Phone) === false) {
            swal({
                type: 'error',
                title: 'Oops... Wrong Input!!',
                text: 'Phone no is not valid'
            })
            return false;
        }
        else if (password === '') {
            swal({
                type: 'error',
                title: 'Oops... Wrong Input!!',
                text: 'Please enter Password'
            })
            return false;
        }
        else if (config.REGEX_VALIDATE_FORM.passwordregex.test(password) === false) {
            swal({
                type: 'error',
                title: 'Oops... Wrong Input!!',
                text: 'Password length between 8-20 and contain atleast a capital letter , small letter , a number and a special character'
            })

            return false;
        }
        else if (PAN.length !== 10 || PAN.trim() === '') {
            swal({
                type: 'error',
                title: 'Oops... Wrong Input!!',
                text: 'Pan number should be 10 characters'
            })
            return false;
        }
        else if (/[A-Z]{5}[0-9]{4}[A-Z]/.test(PAN) === false) {
            swal({
                type: 'error',
                title: 'Oops...Wrong Input!!,Please enter a proper PAN no',
                text: 'Pan number should be in correct format,it should contain first 5 letters as Capital letters and 4numbers and one alphabet'
            })
            return false;
        }
        else if (GST_NO.length !== 15 || GST_NO.trim() === '') {
            swal({
                type: 'error',
                title: 'Oops... Wrong Input!!',
                text: 'GST_NO should be 15 characters'
            })
            return false;
        }
        else if (/[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[0-9]{3}/.test(GST_NO) === false) {
            swal({
                type: 'error',
                title: 'Oops... Wrong Input!!,please enter a proper GST_No',
                text: 'GST_NO should be in a proper format such that it contains Statecode,PANnumber,entity and check numbers'
            })
            return false;
        }
        else if (pin.length !== 6) {
            swal({
                type: 'error',
                title: 'Oops... Wrong Input!!',
                text: 'PIN code should be exactly 6 characters and only numbers are accepted'
            })
        }
        else if (state.length === 0) {
            swal({
                type: 'error',
                title: 'Oops... Wrong Input!!',
                text: 'enter a proper state name'
            })
            return false;
        }
        else {
            return true;
        }
    }

    handleSubmit = (event) => {
        if (this.isValid()) {
            this.props.dispatch(Seller(this.state))
            this.props.history.push("/SellerLogin");
        }
        event.preventDefault();
    }

    render() {
       // const { classes } = this.props;
        return (
            <div className="container-fluid" style={styles.containerfluid}>
                <div className="container">
                    <div className="row">
                        <div className="col-2">
                        </div>
                        <div className="col-9">
                            <br /><br />
                            <center> <Card style={{ height: "3vw", width: "70%", backgroundColor: "#0099cc", Color: "white" }}><CardContent><Typography> <h4>Create Account</h4></Typography></CardContent> </Card></center>
                            <Card >
                                <CardContent>
                                    <center> <form onSubmit={this.handleSubmit}>
                                        <TextField
                                            type="text"
                                            label="Name"
                                            placeholder="Enter Name"
                                            margin="normal"
                                            style={{ width: "70%" }}
                                            value={this.state.Name}
                                            onChange={event => { this.setState(byPropKey('Name', event.target.value, { msg: false })) }}
                                            required
                                        />
                                        <br />
                                        <TextField
                                            type="text"
                                            label="userName"
                                            placeholder="Enter userName"
                                            margin="normal"
                                            style={{ width: "70%" }}
                                            value={this.state.userName}
                                            onChange={event => { this.setState(byPropKey('userName', event.target.value)) }}
                                            required
                                        />
                                        <br />
                                        <TextField
                                            type="text"
                                            label="email_ID"
                                            placeholder="Enter email_id"
                                            margin="normal"
                                            style={{ width: "70%" }}
                                            value={this.state.email_ID}
                                            onChange={event => { this.setState(byPropKey('email_ID', event.target.value)) }}
                                            required
                                        /><br />
                                        <TextField
                                            type="tel"
                                            label="Phone"
                                            placeholder="Enter Phone"
                                            margin="normal"
                                            style={{ width: "70%" }}
                                            value={this.state.Phone}
                                            onChange={event => { this.setState(byPropKey('Phone', event.target.value)) }}
                                            required
                                        /><br />   <TextField
                                            type="text"
                                            label="PAN"
                                            placeholder="Enter PANNumber"
                                            margin="normal"
                                            style={{ width: "70%" }}
                                            value={this.state.PAN}
                                            onChange={event => { this.setState(byPropKey('PAN', event.target.value)) }}
                                            required
                                        />
                                        <TextField
                                            type="text"
                                            label="GST_NO"
                                            placeholder="Enter GSTNumber"
                                            margin="normal"
                                            style={{ width: "70%" }}
                                            value={this.state.GST_NO}
                                            onChange={event => { this.setState(byPropKey('GST_NO', event.target.value)) }}
                                            required
                                        />
                                        <br />

                                        <Typography> Address: </Typography>
                                        <TextField
                                            type="text"
                                            label="flatNo"
                                            placeholder="Enter flatNo"
                                            margin="normal"
                                            style={{ width: '70%', marginLeft: 10 }}
                                            value={this.state.flatNo}
                                            onChange={event => { this.setState(byPropKey('flatNo', event.target.value)) }}
                                            required
                                        />
                                        <TextField
                                            type="text"
                                            label="landmark"
                                            placeholder="Enter LandMark"
                                            margin="normal"
                                            style={{ width: '70%', marginLeft: 10 }}
                                            value={this.state.landmark}
                                            onChange={event => { this.setState(byPropKey('landmark', event.target.value)) }}
                                            required
                                        />
                                        <br />
                                        <TextField
                                            type="text"
                                            label="area"
                                            placeholder="Enter Area"
                                            margin="normal"
                                            style={{ width: "70%" }}
                                            value={this.state.area}
                                            onChange={event => { this.setState(byPropKey('area', event.target.value)) }}
                                            required
                                        />
                                        <br />
                                        <TextField
                                            type="text"
                                            label="state"
                                            placeholder="Enter state"
                                            margin="normal"
                                            value={this.state.state}
                                            style={{ width: "70%", marginLeft: 20 }}
                                            onChange={event => { this.setState(byPropKey('state', event.target.value)) }}
                                            required
                                        />
                                        <TextField
                                            type="text"
                                            label="pin"
                                            placeholder="Enter pincode"
                                            margin="normal"
                                            style={{ width: "70%", marginLeft: 30 }}
                                            value={this.state.pin}
                                            onChange={event => { this.setState(byPropKey('pin', event.target.value)) }}
                                            required
                                        />
                                        <br />
                                        <TextField
                                            type="password"
                                            label="Password"
                                            placeholder="Enter Password"
                                            margin="normal"
                                            style={{ width: "70%" }}
                                            value={this.state.password}
                                            onChange={event => { this.setState(byPropKey('password', event.target.value)) }}
                                            required
                                        />
                                        <br />
                                        <br />
                                        <center> <Button color="primary" variant="contained" type="submit">Submit</Button></center>
                                    </form>
                                    </center>
                                </CardContent>
                            </Card>
                            <br />
                            <br />
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return state;
};

export default connect(mapStateToProps)(SellerRegistration); 