//React Imports
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';

//Material UI Imports
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';

//Action Imports
import Updatesellerdetails from "./../../actions/actionsSellerDetails/Updatesellerdetails";

//Config Import
import config from './../../config.js';

//React 3rd Party npm package Imports
import swal from 'sweetalert2';

const INITIAL_STATE = {
  name: '',
  PAN: '',
  area: '',
  flatNo: '',
  state: '',
  pin: '',
  phoneNo: ''
};

const byPropKey = (propertyName, value) => ({ [propertyName]: value, });
let email_ID;

class UpdateSellerProfile extends Component {
  constructor({ props, match }) {
    super(props);
    email_ID = match.params.email_ID;
    this.state = { ...INITIAL_STATE };
  }

  componentDidMount() {
    this.props.seller.map(seller => {
      if (seller.email_ID === email_ID) {
        this.setState({
          name: seller.address.name,
          PAN: seller.PAN,
          area: seller.address.area,
          flatNo: seller.address.flatNo,
          state: seller.address.state,
          pin: seller.address.pin,
          phoneNo: seller.address.phoneNo
        })
      }
    })
  }

  isValid = () => {

    if (this.state.name.length === 0) {
      swal({
        type: 'error',
        title: 'Oops... Wrong Input!!',
        text: 'enter name'
      })
      return false;
    }
    else if (config.REGEX_VALIDATE_FORM.regex.test(this.state.name) === false) {
      swal({
        type: 'error',
        title: 'Oops... Wrong Input!!',
        text: 'enter proper name'
      })
      return false;
    }
    if (this.state.PAN.length !== 10) {
      swal({
        type: 'error',
        title: 'Oops... Wrong Input!!',
        text: 'Pan number should be 10 characters'
      })
      return false;
    }
    else if (/[A-Z]{5}[0-9]{4}[A-Z]/.test(this.state.PAN) === false) {
      swal({
        type: 'error',
        title: 'Oops...Wrong Input!!,Please enter a proper PAN no',
        text: 'Pan number should be in correct format,it should contain first 5 letters as Capital letters and 4numbers and one alphabet'
      })
      return false;
    }
    if (this.state.flatNo.length === 0) {
      swal({
        type: 'error',
        title: 'Oops... Wrong Input!!',
        text: 'Enter the flat no '
      })
      return false;
    }
    if (this.state.pin.length !== 6) {
      swal({
        type: 'error',
        title: 'Oops... Wrong Input!!',
        text: 'PIN code should be exactly 6 characters'
      })
    }

    if (this.state.state.length === 0) {
      swal({
        type: 'error',
        title: 'Oops... Wrong Input!!',
        text: 'enter a proper state name'
      })
      return false;
    }
    else {
      return true;
    }
  }

  handleSubmit = (event) => {
    if (this.isValid()) {
      this.props.dispatch(Updatesellerdetails(this.state));
      this.props.history.push("/SellerProfile");
      swal({
        position: 'top-end',
        type: 'success',
        title: 'Updated seller profile',
        showConfirmButton: false,
        timer: 1500
      })
    }
    event.preventDefault();
  };

  render() {
    return (
      <div>
        <br />
        <br />
        <center>
          <h1>Update your details</h1>
          <Card style={{ width: "50%", height: "50%" }}>
            <CardContent>
              <div>
                <center>
                  <form onSubmit={this.handleSubmit}>
                    <label>Name:</label>
                    <br />
                    <input
                      type="text"
                      value={this.state.name}
                      onChange={event => { this.setState(byPropKey('name', event.target.value)) }}
                      style={{ width: "50%" }} />
                    <br />
                    <label>FlatNo:</label>
                    <br />
                    <input
                      type="number"
                      value={this.state.flatNo}
                      onChange={event => { this.setState(byPropKey('flatNo', event.target.value)) }}
                      style={{ width: "50%" }} />
                    <br />
                    <label>Area:</label>
                    <br />
                    <input
                      type="text"
                      value={this.state.area}
                      onChange={event => { this.setState(byPropKey('area', event.target.value)) }}
                      style={{ width: "50%" }} />
                    <br />
                    <label>State:</label>
                    <br />
                    <input
                      type="text"
                      value={this.state.state}
                      onChange={event => { this.setState(byPropKey('state', event.target.value)) }}
                      style={{ width: "50%" }} />
                    <br />
                    <label>Pin:</label>
                    <br />
                    <input
                      type="number"
                      value={this.state.pin}
                      onChange={event => { this.setState(byPropKey('pin', event.target.value)) }}
                      style={{ width: "50%" }} />
                    <br />
                    <label>PAN:</label>
                    <br />
                    <input type="text"
                      value={this.state.PAN}
                      onChange={event => { this.setState(byPropKey('PAN', event.target.value)) }}
                      style={{ width: "50%" }} />
                    <br />
                    <br />
                    <br />
                    <Link to="/SellerProfile">
                      <Button variant="contained">Back</Button>
                    </Link>
                    <Button type="submit" variant="contained" style={{ marginLeft: 50 }}>Save</Button>
                  </form>
                </center>
              </div>
            </CardContent>
          </Card>

        </center>
      </div>
    )
  };
}

const mapStateToProps = (state) => {
  return {
    seller: state.storeSellerData
  }
};

export default connect(mapStateToProps)(UpdateSellerProfile)