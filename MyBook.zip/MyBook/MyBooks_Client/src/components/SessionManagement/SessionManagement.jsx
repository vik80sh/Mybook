// let localStorageSeller = localStorage.getItem('isSellerLoggedIn');
// let localStorageTokenUser = localStorage.getItem('Token');
let values = [];
let keys;
let i;

function allStorage() {
    values = [];
    keys = Object.keys(localStorage);
    i = keys.length;
  while (i--) {
    values.push(localStorage.getItem(keys[i]));
  }
  return values;
}

export let login = () => {
  let localStorageSeller = localStorage.getItem('isSellerLoggedIn');
  let localStorageTokenUser = localStorage.getItem('Token');
  if ((localStorageSeller) || (localStorageTokenUser)) {
    return false;
  }
  else
    return true;
}

export let loginLogout = () => {
  let localStorageTokenUser = localStorage.getItem('Token');
  if (localStorageTokenUser === null) {
    return true
  }
  else {
    return false
  }
}

export let AdminloginLogout = () => {
  let localStorageToken = localStorage.getItem('Token');
  if (localStorageToken === 'RQxWYnA2uFYWR6hyWU2zgGBS5q53') {
    return true
  }
  else {
    return false
  }
}

export let SellerloginLogout = () => {
  let localStorageSeller = localStorage.getItem('isSellerLoggedIn');
  if (localStorageSeller != null) {
    return true
  }
  else {
    return false
  }
}
export let Feedback = () => {
  let localStorageFeedback = localStorage.getItem('feedback');
  if (localStorageFeedback) {
    return true
  }
  else {
    return false
  }
}
