//React Imports
import React from 'react';
import { connect } from 'react-redux';

//Material UI Imports
import TextField from '@material-ui/core/TextField';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
//import Typography  from '@material-ui/core/Typography';
import Checkbox from '@material-ui/core/Checkbox';
import Select from '@material-ui/core/Select';
//import NativeSelect from '@material-ui/core/NativeSelect';


//React 3rd Party npm package Imports
import swal from 'sweetalert2';

//Action Imports
import Addbook from '../../actions/actionsAdmin/actionsAdmin';

//Components Import
import CenteredTabs from '../Admin/CenteredTabs';

//Config Import
import config from '../../config.js';

const INITIAL_STATE = {
  _id: '',
  ISBN: '',
  bookName: '',
  fiction: false,
  action: false,
  horror: false,
  health: false,
  textbook: false,
  comics: false,
  biography: false,
  romance: false,
  adventure: false,
  others: false,
  imageURL: '',
  author: '',
  description: '',
  bookCost: '',
  bookQuantity: '',
  seller_ID: ''
};
let matchParams='admin';
const byPropKey = (propertyName, value) => ({ [propertyName]: value, });
class AddBookForm extends React.Component {
  constructor() {
    super();
    this.state = { ...INITIAL_STATE }
    // matchParams=match.params.id;
  }

  handleChecked = (name) => (event) => {
    this.setState({ [name]: event.target.checked });
  }

  isValid = () => {
    if (this.state.bookName.trim().length > 30 || this.state.bookName.trim().length < 1) {
      
      swal({
        type: 'error',
        title: 'Oops...Wrong input!!',
        text: 'BookName should be more than1 and less than 30 letters',
        
      })
      return false;
    }
    else if (config.REGEX_VALIDATE_FORM.regex.test(this.state.author.trim()) === false || this.state.author.trim().length > 30) {
      swal({
        type: 'error',
        title: 'Oops...Wrong input!!',
        text: 'Author name  should be more than 1 and less than 30 letters and only alphabets',
      
      })
      
      return false;
    }
    else if (/^[1-9][0-9]*$\d{6}/.test(this.state.ISBN) ===false && this.state.ISBN<0) {
      swal({
        type: 'error',
        title: 'Oops...Wrong input!!',
        text: 'ISBN should be more than 6 digits and should not start with zeroes',
            })
      
      return false;
    }
    else if (this.state.description.trim().length < 100 || this.state.description.trim().length>1000) {
      swal({
        type: 'error',
        title: 'Oops...Wrong input!!',
        text: 'Description should be more than 100 letters and less than 1000',
        
      })
      
      return false;
    }
    else if (this.state.seller_ID.trim().length > 20 || this.state.seller_ID.trim().length < 1) {
      swal({
        type: 'error',
        title: 'Oops...Wrong input!!',
        text: 'Seller_ID should be more than 1 and less than 20 letters',
      
      })
      
      return false;
    }
    else if (/[1-9]+[.]/.test(this.state.bookQuantity) === true || this.state.bookQuantity < 1||this.state.bookQuantity>80 ) {
      swal({
        type: 'error',
        title: 'Oops...Wrong input!!',
        text: 'Enter proper quantity details atleast one should be present and decimals ashould not be present and u can add only 80 books at once ',

      })
     
      
      return false;
    }
   
    else if (/[1-9]+[.]/.test(this.state.bookCost) === true || this.state.bookCost < 1 || this.state.bookCost>1500) {
      swal({
        type: 'error',
        title: 'Oops...Wrong input!!',
        text: 'Enter proper cost details cost should be more than 0 and should not contain any decimals and book cost should not be more than 1500',

      })
      return false;
    }
    else if (this.state.bookRating > 5 || this.state.bookRating < 1) {
      swal({
        type: 'error',
        title: 'Oops...Wrong input!!',
        text: 'Enter proper rating details rating should be below or equal to 5 and abpve or equal to 1',
      })
      return false;
    }
 
    if( this.state.others===false &&
        this.state.fiction===false &&
        this.state.action===false &&
        this.state.comics===false &&
        this.state.horror===false &&
        this.state.textbook===false &&
        this.state.romance===false &&
        this.state.biography===false &&
        this.state.adventure===false &&
        this.state.health===false
      ){
        swal({
          type: 'error',
          title: 'Choose Category!!',
          text: 'Please select proper category',
        })
        return false;
      }
    return true;
  }

  handleSubmit = (event) => {
    if (this.isValid()) {
      this.props.dispatch(Addbook(this.state));
      this.props.history.push('/adminNavbar')
    }
    event.preventDefault();
  };

  render() {

    return (<div>
      <center>
        <div className="container-fluid">
          <CenteredTabs  seller_ID={matchParams}/>
          <br />
          <div className="row">
            <div className="col-lg-3">
            </div>
            <div className="col-lg-6">
            <Card style={{ width: "50%", backgroundColor: "#0099cc", color: "white" }}>
                        <h1>Add Book</h1>
                    </Card>
            {/* <Card style={{ height: "3vw", width: "70%", backgroundColor: "#0099cc", Color: "white" }}><CardContent><Typography style={{fontSize:25}}> Add a book</Typography></CardContent></Card> */}
              <Card>
                <CardContent>
                  <form onSubmit={this.handleSubmit}>
                    <TextField
                      id="ISBN"
                      label="ISBN"
                      placeholder="Enter ISBN"
                      margin="normal"
                      type="Number"
                      style={{ width: 400, padding: 10 }}
                      value={this.state.ISBN}
                      onChange={event => { this.setState(byPropKey('ISBN', event.target.value)) }}
                      required
                    />
                    <br/>
                    <TextField
                      type="text"
                      id="bookName"
                      label="bookName"
                      style={{ width: 400, padding: 10 }}
                      placeholder="Enter bookName"
                      margin="normal"
                      value={this.state.bookName}
                      onChange={event => this.setState(byPropKey('bookName', event.target.value))}
                      required
                    />
                    <br />
                    <br />
                    <div className="row">
                      <div className="col-lg-3">
                      </div>
                      <div className="col-lg-3">
                        <Checkbox
                          type="checkbox"
                          checked={this.state.ficton}
                          onChange={this.handleChecked('fiction')}
                          value='fiction'
                          style={{ width: 30, margin: 10 }}
                        />fiction
                        <br />
                        <Checkbox
                          type="checkbox"
                          checked={this.state.action}
                          onChange={this.handleChecked('action')}
                          style={{ width: 30, margin: 10 }}
                        />action
                        <br />
                        <Checkbox
                          type="checkbox"
                          checked={this.state.horror}
                          onChange={this.handleChecked('horror')}
                          style={{ width: 30, margin: 10 }}
                        />horror
                        <br />
                        <Checkbox
                          type="checkbox"
                          checked={this.state.romance}
                          onChange={this.handleChecked('romance')}
                          style={{ width: 30, margin: 10, marginRight: 10 }}
                        />romance
                        <br />
                        <Checkbox
                          type="checkbox"
                          checked={this.state.health}
                          onChange={this.handleChecked('health')}
                          style={{ width: 30, margin: 10 }}
                        />health
                        <br />
                      </div>
                      <div className="col-lg-3">
                        <Checkbox
                          type="checkbox"
                          checked={this.state.comics}
                          onChange={this.handleChecked('comics')}
                          style={{ width: 30, margin: 10 }}
                        />comics
                        <br />
                        <Checkbox
                          type="checkbox"
                          checked={this.state.textbook}
                          onChange={this.handleChecked('textbook')}
                          style={{ width: 30, margin: 10 }}
                        />textbook
                        <br />
                        <Checkbox
                          type="checkbox"
                          checked={this.state.biography}
                          onChange={this.handleChecked('biography')}
                          style={{ width: 30, margin: 10 }}
                        />biography
                        <br />

                        <Checkbox
                          type="checkbox"
                          checked={this.state.adventure}
                          onChange={this.handleChecked('adventure')}
                          style={{ width: 30, margin: 10 }}
                        />adventure
                        <br />
                        <Checkbox
                          type="checkbox"
                          checked={this.state.others}
                          onChange={this.handleChecked('others')}
                          style={{ width: 30, margin: 10 }}
                        />others
                        <br />
                      </div>
                      <div className="col-lg-2">
                      </div>
                    </div>
                    <TextField
                      id="imageURL"
                      label="imageURL"
                      type="text"
                      placeholder="Enter the imageURL"
                      margin="normal"
                      style={{ width: 400, padding: 10 }}
                      value={this.state.imageURL}
                      onChange={event => this.setState(byPropKey('imageURL', event.target.value))}
                      required
                    />
                    <br />
                    <TextField
                      id="author"
                      label="author"
                      type="text"
                      placeholder="Enter Author Name"
                      margin="normal"
                      style={{ width: 400, padding: 10 }}
                      value={this.state.author}
                      onChange={event => this.setState(byPropKey('author', event.target.value))}
                      required
                    />
                    <br />
                    <TextField
                      id="description"
                      label="description"
                      type="text"
                      placeholder="Enter the description"
                      margin="normal"
                      style={{ width: 400, padding: 10 }}
                      value={this.state.description}
                      onChange={event => this.setState(byPropKey('description', event.target.value))}
                      required
                    />
                    <br/>
                    <TextField
                      id="bookCost"
                      label="bookCost"
                      type="number"
                      placeholder="Enter the bookCost"
                      margin="normal"
                      style={{ width: 400, padding: 10 }}
                      value={this.state.bookCost}
                      onChange={event => this.setState(byPropKey('bookCost', event.target.value))}
                      required
                    />
                    <br />
                    <TextField
                      id="bookQuantity"
                      label="bookQuantity"
                      type="Number"
                      placeholder="Enter the bookQuantity"
                      margin="normal"
                      style={{ width: 400, padding: 10 }}
                      value={this.state.bookQuantity}
                      onChange={event => this.setState(byPropKey('bookQuantity', event.target.value))}
                      required
                    />
                    <br/>
                    <h6>BookRating:
                    <Select
                     native
                     value={this.state.bookRating}
                     onChange={event => this.setState(byPropKey('bookRating', event.target.value))}
                     >
                      <option value=""></option>
                      <option value={1}>1</option>
                      <option value={2}>2</option>
                      <option value={3}>3</option>
                      <option value={4}>4</option>
                      <option value={5}>5</option>
                     </Select></h6>
                    <br />
                    <TextField
                      id="seller_id"
                      label="seller_id"
                      type="text"
                      placeholder="Enter the sellerid"
                      margin="normal"
                      style={{ width: 400, padding: 10 }}
                      value={this.state.seller_ID}
                  
                      onClick={event => this.setState(byPropKey('seller_ID', matchParams))}
                      required
                    />
                    <br /><br />
                    <Button variant="contained" color="secondary" type="submit" >Add Book</Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </center>
    </div>);
  }
}
const mapStateToProps = (state) => {
  return state;
};
export default connect(mapStateToProps)(AddBookForm);