//React Imports
import React from 'react';
import { connect } from 'react-redux';

//Material UI Imports
import TextField from '@material-ui/core/TextField';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import Snackbar from '@material-ui/core/Snackbar';

//Action Imports
import Updatebook from '../../actions/actionsAdmin/updateActionAdmin';

//React 3rd Party npm package Imports
import swal from 'sweetalert2';

let bookId;
const byPropKey = (propertyName, value) => ({ [propertyName]: value, });

class UpdateBookForm extends React.Component {
    constructor({ match }) {
        super();
        bookId = match.params.id;
        this.state = {
            bookName: '',
            fiction: false,
            action: false,
            horror: false,
            health: false,
            textbook: false,
            comics: false,
            biography: false,
            romance: false,
            adventure: false,
            others: true,
            imageURL: '',
            author: '',
            description: '',
            bookCost: '',
            bookQuantity: '',
            bookRating: '',
            msg: '',
            open: false
        }
    }

    componentDidMount() {
        this.props.books.map(book => {
            if (book._id === bookId) {
                this.setState({
                    bookName: book.bookName,
                    fiction: book.bookcategory.fiction,
                    action: book.bookcategory.action,
                    horror: book.bookcategory.horror,
                    health: book.bookcategory.health,
                    textbook: book.bookcategory.textbook,
                    comics: book.bookcategory.comics,
                    biography: book.bookcategory.biography,
                    romance: book.bookcategory.romance,
                    adventure: book.bookcategory.adventure,
                    others: true,
                    imageURL: book.imageURL,
                    author: book.author,
                    description: book.description,
                    bookCost: book.bookCost,
                    bookQuantity: book.bookQuantity,
                    bookRating: book.bookRating
                })
            }
        })
    }

    handleClose = () => {
        this.setState({
            open: false
        });
    };

    handleChecked = (name) => (event) => {
        this.setState({ [name]: event.target.checked });
    }

    isValid = () => {
        if (this.state.bookName.trim().length > 80 || this.state.bookName.trim().length < 1) {
            swal({
                type: 'error',
                title: 'Oops... Wrong Input!!',
                text: 'BookName should be more than 1 and less than 80 letters '
            })

            return false;
        }
        else if (this.state.author.trim().length > 30 || this.state.author.trim().length < 1) {
            swal({
                type: 'error',
                title: 'Oops... Wrong Input!!',
                text: 'Author name  should be more than 1 and less than 30 letters '
            })
            return false;
        }
        else if (this.state.description.trim().length < 100 || this.state.description.trim().length>1000) {
            swal({
                type: 'error',
                title: 'Oops... Wrong Input!!',
                text: 'Description should be more than 100 letters and less than 1000 letters'
            })

            return false;
        }
        else if (/[1-9]+[.]/.test(this.state.bookCost) === true || this.state.bookCost < 1 || this.state.bookCost>1500) {
            swal({
                type: 'error',
                title: 'Oops...Wrong input!!',
                text: 'Enter proper cost details cost should be more than 0 and should not contain any decimals and should not exceed 1500',

            })
            return false;
        }

        else if (/[1-9]+[.]/.test(this.state.bookQuantity) === true || this.state.bookQuantity < 2 || this.state.bookQuantity>80) {
            swal({
                type: 'error',
                title: 'Oops... Wrong Input!!',
                text: 'Book quantity should be atleast 2 and decimals should not be present and you cannot add more than 80 books'
            })
            return false;
        }



        else if (/[1-9]+[.]/.test(this.state.bookRating) === true || this.state.bookRating < 1 || this.state.bookRating > 5) {
            swal({
                type: 'error',
                title: 'Oops... Wrong Input!!',
                text: 'Enter proper rating details rating should be below or equal to 5 and above or equal to 1 (Not including the decimal)'
            })
            return false;
        }
        return true;

    }

    handleSubmit = (event) => {
        if (this.isValid()) {
            swal({
                position: 'top-end',
                type: 'success',
                title: 'Book updated successfully',
                showConfirmButton: false,
                timer: 1500
            })
            this.props.dispatch(Updatebook(bookId, this.state));
            window.history.back();
        }
        event.preventDefault();
    };

    render() {
        return (<div>
            <Snackbar
                open={this.state.open}
                onClose={this.handleClose}
                TransitionComponent={this.state.Transition}
                ContentProps={{
                    'aria-describedby': 'message-id',
                }}
                message={<span id="message-id" >{this.state.msg}</span>}
            />
            <center>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-lg-2">
                        </div>
                        <div className="col-lg-8">
                            <h1>Update Book</h1>
                            <Card>
                                <CardContent>
                                    <form onSubmit={this.handleSubmit}>
                                        <TextField
                                            type="text"
                                            label="bookName"
                                            style={{ width: 700, padding: 12 }}
                                            placeholder="Enter bookName"
                                            margin="normal"
                                            value={this.state.bookName}
                                            onChange={event => this.setState(byPropKey('bookName', event.target.value))}
                                            required
                                        />
                                        <br />
                                        <div className="row">
                                            <div className="col-lg-4">
                                            </div>
                                            <div className="col-lg-2" style={{ textAlign: "left" }}>
                                                <input
                                                    type="checkbox"
                                                    checked={this.state.fiction}
                                                    onChange={this.handleChecked('fiction')}
                                                    value='fiction'
                                                    style={{ width: 30, margin: 10 }}
                                                />fiction
                                                <br />
                                                <input
                                                    type="checkbox"
                                                    checked={this.state.action}
                                                    onChange={this.handleChecked('action')}
                                                    style={{ width: 30, margin: 10 }}
                                                />action
                                                <br />
                                                <input
                                                    type="checkbox"
                                                    checked={this.state.horror}
                                                    onChange={this.handleChecked('horror')}
                                                    style={{ width: 30, margin: 10 }}
                                                />horror
                                                <br />
                                                <input
                                                    type="checkbox"
                                                    checked={this.state.romance}
                                                    onChange={this.handleChecked('romance')}
                                                    style={{ width: 30, margin: 10, marginRight: 10 }}
                                                />romance
                                                <br />
                                                <input
                                                    type="checkbox"
                                                    checked={this.state.health}
                                                    onChange={this.handleChecked('health')}
                                                    style={{ width: 30, margin: 10 }}
                                                />health
                                                <br />
                                            </div>
                                            <div className="col-lg-3" style={{ textAlign: "left" }}>
                                                <input
                                                    type="checkbox"
                                                    checked={this.state.comics}
                                                    onChange={this.handleChecked('comics')}
                                                    style={{ width: 30, margin: 10 }}
                                                />comics
                                                <br />
                                                <input
                                                    type="checkbox"
                                                    checked={this.state.textbook}
                                                    onChange={this.handleChecked('textbook')}
                                                    style={{ width: 30, margin: 10 }}
                                                />textbook
                                                <br />
                                                <input
                                                    type="checkbox"
                                                    checked={this.state.biography}
                                                    onChange={this.handleChecked('biography')}
                                                    style={{ width: 30, margin: 10 }}
                                                />biography
                                                <br />
                                                <input
                                                    type="checkbox"
                                                    checked={this.state.adventure}
                                                    onChange={this.handleChecked('adventure')}
                                                    style={{ width: 30, margin: 10 }}
                                                />adventure
                                                <br />
                                                <input
                                                    type="checkbox"
                                                    checked={this.state.others}
                                                    style={{ width: 30, margin: 10 }}
                                                />others
                                                <br />
                                            </div>
                                            <div className="col-lg-2">
                                            </div>
                                        </div>
                                        <TextField
                                            label="imageURL"
                                            type="text"
                                            placeholder="Enter the imageURL"
                                            margin="normal"
                                            style={{ width: 700, padding: 12 }}
                                            value={this.state.imageURL}
                                            onChange={event => this.setState(byPropKey('imageURL', event.target.value))}
                                            required
                                        />
                                        <br />
                                        <TextField
                                            label="description"
                                            type="text"
                                            placeholder="Enter the description"
                                            margin="normal"
                                            style={{ width: 700, padding: 12 }}
                                            value={this.state.description}
                                            onChange={event => this.setState(byPropKey('description', event.target.value))}
                                            required
                                        />
                                        <br />
                                        <TextField
                                            label="author"
                                            type="text"
                                            placeholder="Enter Author Name"
                                            margin="normal"
                                            style={{ width: 350, padding: 12 }}
                                            value={this.state.author}
                                            onChange={event => this.setState(byPropKey('author', event.target.value))}
                                            required
                                        />
                                        <TextField
                                            label="bookCost"
                                            type="Number"
                                            placeholder="Enter the bookCost"
                                            margin="normal"
                                            style={{ width: 350, padding: 12 }}
                                            value={this.state.bookCost}
                                            onChange={event => this.setState(byPropKey('bookCost', event.target.value))}
                                            required
                                        />
                                        <br />
                                        <TextField
                                            label="bookQuantity"
                                            type="Number"
                                            placeholder="Enter the bookQuantity"
                                            margin="normal"
                                            style={{ width: 350, padding: 12 }}
                                            value={this.state.bookQuantity}
                                            onChange={event => { this.setState(byPropKey('bookQuantity', event.target.value)) }}
                                            required
                                        />
                                        <TextField
                                            label="bookRating"
                                            type="Number"
                                            style={{ width: 350, padding: 12 }}
                                            placeholder="Enter the bookRating"
                                            margin="normal"
                                            value={this.state.bookRating}
                                            onChange={event => { this.setState(byPropKey('bookRating', event.target.value)) }}
                                            required
                                        />
                                        <br />
                                        <Button variant="contained" color="secondary" type="submit" >Update Book</Button>
                                    </form> </CardContent>
                            </Card>
                        </div>
                    </div>
                </div>
            </center>
        </div>);
    }
}
const mapStateToProps = (state) => {
    return {
        books: state.storeBookData
    }
};

export default connect(mapStateToProps)(UpdateBookForm);