//Server Connection URL

//const url = "http://localhost:4000";
const url = "https://myBooks-wt-dev-server.azurewebsites.net";
// const url = "https://myBooks-wt-server.azurewebsites.net";

//URL Connection routes for making AXIOS calls to server
const urlConnection = {
  urlUserCollection: `${url}/user`,
  urlBookCollection: `${url}/bookdata`,
  urlCartCollection: `${url}/usercart`,
  urlFeedbackCollection: `${url}/feedback`,
  urlOrderCollection: `${url}/order`,
  urlSellerCollection: `${url}/seller`,
  urlSellerCollection: `${url}/sellerdata`,
  urlSubscribe: `${url}/subscribe`,
};

//ACTION Types
const ACTIONS = {
  BOOK_DATA: "BOOK_DATA",
  ADD_BOOK_TO_CART: "ADD_BOOK_TO_CART",
  DELETE_BOOK_FROM_CART: "DELETE_BOOK_FROM_CART",
  DELETE_BOOK_FROM_COLLECTION: "DELETE_BOOK_FROM_COLLECTION",
  GET_USER_DETAILS: "GET_USER_DETAILS",
  ADD_PREFERENCES: "ADD_PREFERENCES",
  TRENDING_BOOKS: "TRENDING_BOOKS",
  FEEDBACK_DATA: "FEEDBACK_DATA",
  FEEDBACK_DATA_UPDATE: "FEEDBACK_DATA_UPDATE",
  USERORDER_DATA: "USERORDER_DATA",
  GET_USER_DETAILS: "GET_USER_DETAILS",
  GET_SELLER_DETAILS: "GET_SELLER_DETAILS",
  GET_USERS: "GET_USERS",
  SELLER_DATA: "SELLER_DATA",
  GET_SELLERS: "GET_SELLERS",
  ADD_BOOK: "ADD_BOOK",
  SELLER_LOGIN: "SELLER_LOGIN",
  SEARCH_RESULT: "SEARCH_RESULT"
};

//Regular Expressions for Validation for Login and Register forms
const REGEX_VALIDATE_FORM = {
  regex: /^[a-zA-Z]+[a-zA-Z ]*$/,
  passwordregex: /^(?=.*[A-Z])(?=.*[a-z])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^''"&*]{8,20}$/,
  mailregex: /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
  phoneregex: /^(\+91[\-\s]?)?[0]?(91)?[6789]\d{9}$/
};

export default {
  urlConnection,
  ACTIONS,
  REGEX_VALIDATE_FORM
};
