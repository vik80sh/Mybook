//React Imports
import React from 'react';
import PropTypes from 'prop-types';


//Material UI Imports
import { withStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';

//Component Imports
import BarChart from '../../components/Admin/Graphs/BarChart';
import PieChart from '../../components/Admin/Graphs/PieChart';
import CenteredTabs from '../../components/Admin/CenteredTabs';

const styles = theme => ({
  root: {
    flexGrow: 1,
    height: 700,
    zIndex: 1,
    backgroundColor: theme.palette.background.default,
    display: 'flex',
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
  },
  drawerPaper: {
    position: 'relative',
    width: 250,
  },
  content: {
    flex: 1,
    backgroundColor: theme.palette.background.default,
    padding: theme.spacing.unit * 3,
    minWidth: 0,
  },
  toolbar: theme.mixins.toolbar,
});

function adminNavbar(props) {
  const { classes } = props;
  return (
    <div className={classes.root}>
      <main className={classes.content}>
        <CenteredTabs />
        <div className={classes.toolbar} />
        <br /><br />
        <div className="row">
          <div className="col-sm-6">
            <Card style={{ backgroundColor: "green" }}>
              <CardContent>
                <Card>
                  <CardContent>
                    <BarChart />
                  </CardContent>
                </Card>
              </CardContent>
            </Card>
          </div>
          <div className="col-sm-6">
            <Card style={{ backgroundColor: "orange" }}>
              <CardContent>
                <Card>
                  <CardContent>
                    <PieChart />
                  </CardContent>
                </Card>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}

adminNavbar.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(adminNavbar);
