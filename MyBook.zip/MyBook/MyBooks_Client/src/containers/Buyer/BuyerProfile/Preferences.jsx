//React Imports
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';

//Material UI Imports
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';

//Action Imports
import { Addpreference } from './../../../actions/actionsUserDetails/actionsUserPreferences';

//State Declaration
const INITIAL_STATE = {
    fiction: false,
    action: false,
    horror: false,
    health: false,
    textbook: false,
    comics: false,
    biography: false,
    romance: false,
    adventure: false,
    others: false,
};
class Preferences extends Component {
    constructor(props) {
        super(props);
        this.state = { ...INITIAL_STATE };
    }

    handleSubmit = (event) => {
        this.props.dispatch(Addpreference(this.state));
        event.preventDefault();
        this.props.history.push("/Profile");
    };

    handleChecked = (name) => (event) => {
        this.setState({ [name]: event.target.checked });
    }

    render() {
        return (
            <div className="container-fluid">
                <br />
                <br />
                <div className="row">
                    <div className="col-md-2">
                    </div>
                    <div className="col-md-8">
                        <Card style={{ width: "70%" }}>
                            <CardContent>
                                <form onSubmit={this.handleSubmit}>
                                    <div className="row">
                                        <div className="col-md-2">
                                        </div>
                                        <div className="col-md-5">
                                            <input
                                                type="checkbox"
                                                checked={this.state.ficton}
                                                onChange={this.handleChecked('fiction')}
                                                value='fiction'
                                                style={{ width: 100 }}
                                            />
                                            <h6>fiction</h6>
                                        </div>
                                        <div className="col-md-5">
                                            <input
                                                type="checkbox"
                                                checked={this.state.action}
                                                onChange={this.handleChecked('action')}
                                                style={{ width: 100 }}
                                            />
                                            <h6>action</h6>
                                        </div>
                                    </div>
                                    <br />
                                    <div className="row">
                                        <div className="col-md-2">
                                        </div>
                                        <div className="col-md-5">
                                            <input
                                                type="checkbox"
                                                checked={this.state.horror}
                                                onChange={this.handleChecked('horror')}
                                                style={{ width: 100 }}
                                            />
                                            <h6>horror</h6>
                                        </div>
                                        <div className="col-md-5">
                                            <input
                                                type="checkbox"
                                                checked={this.state.romance}
                                                onChange={this.handleChecked('romance')}
                                                style={{ width: 100 }}
                                            />
                                            <h6>romance</h6>
                                        </div>
                                    </div>
                                    <br />
                                    <div className="row">
                                        <div className="col-md-2">
                                        </div>
                                        <div className="col-md-5">
                                            <input
                                                type="checkbox"
                                                checked={this.state.health}
                                                onChange={this.handleChecked('health')}
                                                style={{ width: 100 }}
                                            />
                                            <h6>health</h6>
                                        </div>
                                        <div className="col-md-5">
                                            <input
                                                type="checkbox"
                                                checked={this.state.comics}
                                                onChange={this.handleChecked('comics')}
                                                style={{ width: 100 }}
                                            />
                                            <h6>comics</h6>
                                        </div>
                                    </div>
                                    <br />
                                    <div className="row">
                                        <div className="col-md-2">
                                        </div>
                                        <div className="col-md-5">
                                            <input
                                                type="checkbox"
                                                checked={this.state.textbook}
                                                onChange={this.handleChecked('textbook')}
                                                style={{ width: 100 }}
                                            />
                                            <h6>textbook</h6>
                                        </div>
                                        <div className="col-md-5">
                                            <input
                                                type="checkbox"
                                                checked={this.state.biography}
                                                onChange={this.handleChecked('biography')}
                                                style={{ width: 100 }}
                                            />
                                            <h6>biography</h6>
                                        </div>
                                    </div>
                                    <br />
                                    <div className="row">
                                        <div className="col-md-2">
                                        </div>
                                        <div className="col-md-5">
                                            <input
                                                type="checkbox"
                                                checked={this.state.adventure}
                                                onChange={this.handleChecked('adventure')}
                                                style={{ width: 100 }}
                                            />
                                            <h6>adventure</h6>
                                        </div>
                                        <div className="col-md-5">
                                            <input
                                                type="checkbox"
                                                checked={this.state.others}
                                                onChange={this.handleChecked('others')}
                                                style={{ width: 100 }}
                                            />
                                            <h6>others</h6>
                                        </div>
                                    </div>
                                    <center>
                                        <Button variant="contained" color="secondary" type="submit" >Change</Button>
                                        <br />
                                        <Link to="/Profile">
                                            <Button>Back</Button>
                                        </Link>
                                    </center>
                                </form>
                            </CardContent>
                        </Card>
                    </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return state;
};

export default connect(mapStateToProps, null)(Preferences);