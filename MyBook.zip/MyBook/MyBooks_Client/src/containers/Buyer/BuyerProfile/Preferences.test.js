import Preferences from './Preferences.jsx'

describe('prefernces',()=>{
    let wrapper

    beforeEach(()=>{
        wrapper = shallow(<Preferences/>)
        
    })

    it('+++ render the DUMB component', () => {
       expect(wrapper.length).toEqual(1)
    });
         
});
