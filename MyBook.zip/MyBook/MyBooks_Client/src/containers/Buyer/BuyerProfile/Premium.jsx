//React Imports
import React, { Component } from 'react'
import { Link } from 'react-router-dom';

//Material UI Imports
import Paper from '@material-ui/core/Paper';
import Button from '@material-ui/core/Button'

class Premium extends Component {
  render() {
    return (
      <div>
        <br />
        <br />
        <Paper style={{ margin: 20 }}>
          <center>
            <h1>About Premium</h1>
          </center>
          <br />
          <h5>Unlimited FREE fast delivery</h5>
          <br />
          <p>Guaranteed free One-Day, Two-Day and Standard Delivery on eligible items
                Why pay Rs.100 for One-Day Delivery every time you need an item quickly? As a Premium member, get unlimited FREE One-Day and Two-Day Delivery on eligible items from India’s largest online store, to over a hundred cities. Premium items that are not eligible for free One-Day or Two-Day Delivery to your location, will always qualify for free Standard Delivery with no minimum purchase value. The fastest, free Premium delivery speed available for an item will be shown on the product page.

                Premium members also enjoy discounted Same-Day and Morning Delivery to pin-codes in select cities across India. Get exclusive 2-hour Express Delivery to eligible pin-codes in Delhi, Mumbai, Bangalore & Hyderabad via the Premium Now App.</p>
          <br />
          <hr />
          <br />
          <h5>Grab the best deals first</h5>
          <br />
          <p>Exclusive access to top deals & coupons
As a Premium member, you get access to exclusive deals across categories. Be among the first to decide what's hot and what's not, and get 30-minute early access to top Lightning Deals every day. Choose the Prime Early Access filter when you search, to see the day’s selected deals. Premium members save an additional 15% on diaper subscriptions and get exclusive discounts and recommendations, all tailored for their family.</p>
          <br />
          <br />
          <center>
            <Link to="/Profile">
              <Button>Back</Button>
            </Link>
          </center>
        </Paper>
      </div>
    )
  }
}
export default Premium;