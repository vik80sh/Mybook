import Premium from './Premium.jsx'

it('Premium rendering without crashing',()=>{
    shallow(<Premium/>);
})