//React Imports
import React, { Component } from 'react';

//Material UI Imports
import Card from '@material-ui/core/Card';

//Image Import
import feedback from '../../../Assests/PaymentImages/feedback.png';
import thankYou from '../../../Assests/PaymentImages/Thankyou.png';

class Thankyou extends Component {
  render() {
    return (
      <div className="container">
        <center>
          <Card style={{ marginTop: '30px', padding: '10px', backgroundColor: '#e6f2ff', marginBottom: '5%' }}>
            <img className="img-fluid" src={feedback} alt="Payment Successful" height='215px' width='420px' />
            <h2 style={{ margin: '20px', padding: '10px' }}>Submitted Feedback Successfully</h2>
            <div className='row'>
              <div className='col-md-2'>
                <img className="img-fluid" src={thankYou} alt="Thank you" height='200px' width='125px' />
              </div>
              <div className='col-md-9'>
                <h3 style={{ marginTop: '10%' }}>It was really a pleasure doing business with you! Thank you for choosing us!</h3>
              </div>
            </div>
          </Card>
        </center>
      </div>
    )
  }
}

export default Thankyou;
