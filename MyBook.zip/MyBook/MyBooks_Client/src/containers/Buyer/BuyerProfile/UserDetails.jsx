//React Imports
import React, { Component } from 'react'
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';

//Material UI Imports
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';

//Action Imports
import { fetchuserdetails } from '../../../actions/actionsUserDetails/fetchUserDetails';

class UserDetails extends Component {
    constructor(props) {
        super(props);
        const userID = localStorage.getItem('Token');
        this.props.onFetchUser(userID);
    }
    render() {
        return (
            <div>
                <div className="container-fluid">
                    <div className="row">
                        <div className="col-md-3">
                        </div>
                        {this.props.user.map((data,key) =>
                            <div className="col-md-6" key={data._id} style={{marginBottom:'15.5%'}}>
                                <br />
                                <Card style={{ width: "100%", height: "100%" }}>
                                    <CardContent>
                                        <center>
                                            <h3>Your Details</h3>
                                            <hr />
                                            <div>
                                                <h6>Name:</h6><h3><b>{data.name}</b></h3>
                                                <br />
                                                <h6>Email ID:</h6><h5>{data.email_ID}</h5>
                                                <br />
                                                <h6>Phone number:</h6><h5>{data.phoneNo}</h5>
                                            </div>
                                            <br />
                                            <br />
                                        </center>
                                        <Link to="/Profile">
                                            <Button>Back</Button>
                                        </Link>
                                        <Link to={`/UpdateProfile/${data.email_ID}`}>
                                            <Button style={{ marginLeft: 250 }}>Edit</Button>
                                        </Link>
                                    </CardContent>
                                </Card>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        )
    }
}

const mapStateToProps = state => {

    return {
        user: state.storeUserData
    };
};

const mapDispatchToProps = dispatch => {
    return {
        onFetchUser: (userName) => {
            dispatch(fetchuserdetails(userName));
        },
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(UserDetails);