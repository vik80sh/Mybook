//React Imports
import React, { Component } from 'react';
import { connect } from 'react-redux';
import {Link } from 'react-router-dom';

//Material UI Imports
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';

//Action Imports
import { fetchuserdetails } from '../../../actions/actionsUserDetails/fetchUserDetails';

class Userprofile extends Component {
    constructor(props) {
        super(props);
        const userID = localStorage.getItem('Token');
        this.props.onFetchUser(userID);
    }

    render() {
        return (
            <div className="container" style={{marginBottom:0}}>
                <Card style={{marginLeft:"70px",marginBottom:"20px",marginTop:"15px",marginRight:"40px"}}>
                        <center>
                    <CardContent>
                    <br />
                    <br />
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-md-2">
                                </div>
                            {/* <div className="col-md-2"  style={{marginleft:"120px", paddingRight: 0 }}>
                            <img src={require('./../../../Assests/UserProfileimages/profile2.png')} width="70" height="70"alt="profile"/>
                            </div> */}
                            {this.props.user.map((data,key) =>
                                <div className="col-md-8" key={data._id}>
                                <img src={require('./../../../Assests/UserProfileimages/profile2.png')} width="70" height="70"alt="profile"/>
                                    <h4><b>Hello &nbsp;{data.name}!! </b></h4>
                                </div>
                            )}
                            <div className="col-md-2">
                                </div>
                        </div>
                        <br/>
                        <br/>
                        <div className="row" style={{marginLeft:20}}>
                             <div className="col-md-6" >
                                <Card style={{ width: "100%", height: "100%"}}>
                                    <Link color="inherit" variant="title" to={`/UserDetails`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                        <CardContent>
                                            <div className="row">
                                                <div className="col-md-1">
                                                </div>
                                                <div className="col-md-3">
                                                    <img src={require('./../../../Assests/UserProfileimages/information.png')} width="70" height="70" alt="feedback" />
                                                </div>
                                                <div className="col-md-6" style={{paddingTop:"4%"}}>
                                                    <h3><b>Your Details</b></h3>
                                                </div>
                                            </div>
                                        </CardContent>
                                    </Link>
                                </Card>
                            </div>
                           
                            <div className="col-md-6">
                                <Card style={{ width: "100%", height: "100%"}}>
                                    <Link color="inherit" variant="title" to={`/Myorders`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                        <CardContent>
                                            <div className="row">
                                                <div className="col-md-1">
                                                </div>
                                                <div className="col-md-3">
                                                    <img src={require('./../../../Assests/UserProfileimages/orders.png')} width="70" height="70" alt="ordersimage"/>
                                                </div>
                                                <div className="col-md-6" style={{paddingTop:"4%"}}>
                                                    <h3><b>Your Orders</b></h3>
                                                </div>
                                            </div>
                                        </CardContent>
                                    </Link>
                                </Card>
                            </div>
                        </div>
                       <div className="row">
                           <div className="col-md-12">
                               </div>
                           </div>
                        <div className="row"style={{marginLeft:20}}>
       
                            <div className="col-md-6" >
                                <Card style={{ width: "100%", height: "100%"}}>
                                    <Link color="inherit" variant="title" to={`/Preferences`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                        <CardContent>
                                            <div className="row">
                                                <div className="col-md-1">
                                                </div>
                                                <div className="col-md-3">
                                                    <img src={require('./../../../Assests/UserProfileimages/preferences.png') } alt="wishlist" width="70" height="70" />
                                                </div>
                                                <div className="col-md-6" style={{paddingTop:"4%"}}>
                                                    <h3><b>Preferences</b></h3>
                                                </div>
                                            </div>
                                        </CardContent>
                                    </Link>
                                </Card>
                            </div>
                            <div className="col-md-6" >
                                <Card style={{ width: "100%", height: "100%"}}>
                                    <Link color="inherit" variant="title" to={`/Premium`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                        <CardContent>
                                            <div className="row">
                                                <div className="col-md-1">
                                                </div>
                                                <div className="col-md-3">
                                                    <img src={require('./../../../Assests/UserProfileimages/premium2.png')}  alt="premiumuser"width="70" height="70" />
                                                </div>
                                                <div className="col-md-6" style={{paddingTop:"4%"}}>
                                                    <h3><b>Premium </b></h3>
                                                </div>
                                            </div>
                                        </CardContent>
                                    </Link>
                                </Card>
                            </div>
                        </div>
                        <br />
                        <br />
                        <br />
                        <br />
                    </div>
                    </CardContent>
                    </center>
                </Card>
            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        user: state.storeUserData
    };
};

const mapDispatchToProps = dispatch => {
    return {
        onFetchUser: (userName) => {
            dispatch(fetchuserdetails(userName));
        }
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(Userprofile);