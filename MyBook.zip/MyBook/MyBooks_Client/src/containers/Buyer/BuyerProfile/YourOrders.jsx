//React Imports
import React, { Component } from 'react'
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';

//Material UI Imports
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';

//Action Imports
import { setBookData } from '../../../actions/actionFeedback/actionFeedbackupdate'
import { fetchUserOrder } from '../../../actions/actionsUserDetails/actionUserOrder';

import emptyCart from '../../../Assests/Cart/emptyCart.png';


const styles = {
    columnTitle: {
        fontWeight: 'bold',
        fontFamily: 'Verdana, Geneva, sans-serif',
        marginTop: '5px',
        textAlign: 'center',
        fontSize: 35,
        color: "#1a1a1a",
        width: "100%",
    }
}
class YourOrders extends Component {
    constructor(props) {
        super(props);
        const userID = localStorage.getItem('Token');
        this.props.onFetchUser(userID);
    }

    handleClick = (data) => {
        localStorage.setItem('feedback','feedback')
        const bookName = data.bookName,
            author = data.author;
        setBookData(author, bookName);
    }

    render() {
      if(this.props.userOrderList.length===0){
        return (
            <div className="container">
                <center>
                    <p style={styles.columnTitle}>Your Orders</p>
                    <Card style={{ marginTop: '30px', padding: '10px', backgroundColor: '#e6f2ff', marginBottom: '15%' }}>
                        <img className="img-fluid" src={emptyCart} alt="Cart is EMPTY" height='350px' width='700px' />
                        <h3 style={{ margin: '20px', padding: '10px' }}>No orders placed, Please Purchase Some Books to make me Happy</h3>
                    </Card>
                </center>
            </div>
        )
      }
      else{
        return (
           
            <div className="container-fluid">
                <center><h3>Your Orders</h3></center>
                
                 {this.props.userOrderList.map((data,key) =>
                    
                <div className="row" key={data._id}>
                    <div className="col-md-3">
                    </div>
                  
                        <div className="col-md-6" >
                            <br />
                            <Card>
                                <CardContent>
                                    <div>
                                        <h6>Shipping Address</h6>
                                        <ExpansionPanel>
                                            <ExpansionPanelSummary expandIcon={<ExpandMoreIcon />}>
                                                <h5> Name : {data.shippingAddress.name}</h5>
                                            </ExpansionPanelSummary>
                                            <ExpansionPanelDetails  >
                                                Address :{data.shippingAddress.area} , {data.shippingAddress.pin} <br />
                                                Phone Number:{data.shippingAddress.phoneNo} <br />
                                            </ExpansionPanelDetails>
                                        </ExpansionPanel>
                                        <br />
                                        {data.orderDetail.map((book,key) =>
                                        <div>
                                            <div className="row" key={book._id}>
                                                <div className="col-5" >
                                                    <img className="img-fluid"src={book.imageURL} style={{ height: 200, width: 150 }} alt="bookimage" />
                                                </div>
                                                <div className="col-6"style={{marginLeft:5}}>
                                                    <h6>Book Name:    {book.bookName}</h6>
                                                    <h6>Author:   {book.author}</h6>
                                                    <h6>Book Quantity:  {book.bookQuantity}</h6>
                                                    <h6>Book Cost:{book.bookCost}</h6>
                                                    <Link to="/Feedbackpage">
                                                    <Button onClick={() => this.handleClick(book)} color="primary" variant="contained" >feedback</Button>
                                                </Link>
                                                </div>
                                                </div>
                                                <br />  
                                            </div>
                                        )}
                                        <br/>
                                        <Card>
                                            <CardContent>
                                                <center> <h6>Total Cost :{data.totalCost}</h6></center>
                                            </CardContent>
                                        </Card>
                                    </div>
                                </CardContent>
                            </Card>
                            <br />
                        </div>
                    
                    <div className="col-3"/>
                </div>
            )}
            <center><Link to="/Profile">
                                <Button variant="contained">Back</Button>
                            </Link></center>
            </div>
        )
    }
}
}


const mapStateToProps = state => {
    return {
        userOrderList: state.storeUserOrder
    };
};

const mapDispatchToProps = dispatch => {
    return {
        onFetchUser: (userName) => {
            dispatch(fetchUserOrder(userName));
        }
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(YourOrders);