//React Imports
import React from 'react';

//Material UI Imports
import Card from '@material-ui/core/Card';
import Button from '@material-ui/core/Button';
import CardContent from '@material-ui/core/CardContent';

//React 3rd Party npm package Imports
import StarRatingComponent from 'react-star-rating-component';

//Action Imports
import { feedbackFromCollection } from '../../../actions/actionFeedback/actionFeedbackupdate';

export class feedback extends React.Component {
  constructor() {
    super();
    this.state = {
      rating: 1,
      feedback: ''
    };
  }

  onStarClick(nextValue, prevValue, name) {
    this.setState({
      rating: nextValue,
    });
  }

  onChangeFeedback = (event) => {
    this.setState({ feedback: event.target.value });
  }
  feedbackSubmit = () => {
    if(this.state.feedback.trim().length===0)
      {
        alert("Please give a proper feedback with out spaces")
      }
      else{
    localStorage.removeItem('feedback');    
    feedbackFromCollection(this.state.feedback, this.state.rating)
    this.props.history.push("/Thankyou");
      }
  }

  render() {

    return (
      <div>
        <Card style={{margin:10}}>
          <CardContent>
             <h2  style={{fontFamily:'Brawler, serif'}}>Rating & Reviews</h2>
           </CardContent>
         </Card>
      <div className="container">
      <br></br>
      <div className="row">
          <div className="col-lg-2">
          </div>
          <div className="col-lg-8">
              <center>
              <Card>
            <CardContent>
               <h3  style={{fontFamily:'Petit Formal Script, cursive', fontWeight:'bold'}}>I'm Calling it the Book Review of the Decade<br/><br/> --- Sam Smith</h3>
             </CardContent>
           </Card>    
           <br/>
           <Card>
              <CardContent>
                  <div style={{ padding: "20px" }}>
                    <h4 style={{fontFamily:'Brawler, serif'}}>Please Give your Rating</h4>
                    <StarRatingComponent
                      name="rate1"
                      starCount={5}
                      style={{  height: '30%' }}
                      value={this.state.rating}
                      onStarClick={this.onStarClick.bind(this)}
                    />
                 

                  <h4 style={{fontFamily:'Brawler, serif'}}>Please Give your Review</h4>
                    <textarea
                      placeholder="Please Type your Review Here ..."
                      margin="normal"
                      style={{ height: '50%', width: "90%" }}
                      onChange={this.onChangeFeedback} rows="5" col="14"
                    >
                    </textarea>    
                    </div>        
               

               <Button class="btn btn-primary btn-lg" color="white" onClick={this.feedbackSubmit}>Submit</Button>
              
              </CardContent>
            </Card>             
              </center>

          </div>
      </div>
  </div>
  </div>
      // <div className="conatiner">
      //   <Card>
      //     <CardContent>
      //       <h2  style={{fontFamily:'Brawler, serif'}}>Rating & Reviews</h2>
      //     </CardContent>
      //   </Card>
      //   <br />
      //   <br />
      //   <Card>
      //       <CardContent>
      //         <div className="col-sm-9"><p>What Makes A Good Review</p><hr /></div>
      //       </CardContent>
      //     </Card>
      //   <div className="row">        
      //     <div className="col-sm-9">
            // <Card>
            //   <CardContent>
            //     <div className="row">
            //       <br />
            //       <div style={{ padding: "20px" }}>
            //         <br />
            //         <StarRatingComponent
            //           name="rate1"
            //           starCount={5}
            //           style={{ height: '100px' }}
            //           value={this.state.rating}
            //           onStarClick={this.onStarClick.bind(this)}
            //         />
            //       </div>
            //     </div>

            //     <div className="row">
            //       <div className='col-sm-4'>
            //         <textarea
            //           label="Type Something..."
            //           margin="normal"
            //           style={{ height: '300px', width: "1100px" }}
            //           onChange={this.onChangeFeedback} rows="3" col="14"
            //         >
            //         </textarea>
            //       </div>
            //     </div>

            //     <div className='row'>

            //       <div className='col-sm-5'></div>
            //       <div className='col-sm-5'></div>
            //       <div className='col-sm-1'><Button color="secondary" onClick={this.feedbackSubmit}>Submit</Button></div>
            //     </div>
            //   </CardContent>
            // </Card>
      //     </div>
      //   </div>
      // </div >
    );
  }
}

export default feedback;

