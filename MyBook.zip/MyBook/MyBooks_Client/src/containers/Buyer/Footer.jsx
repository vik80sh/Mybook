//React Imports
import React from 'react';

//MDB React Imports
import { Col, Container, Row, Footer } from 'mdbreact';



const styles = {
  Footer: {
    marginBottom: 0,
    // background: "#e3f2fd",
    background: "#0052cc",
    position: "static"
  }
}

class FooterPage extends React.Component {
  render() {
    return (
      <Footer style={styles.Footer} >
        <Container fluid className="text-center text-md-left">
          <br />
          <Row className="my-4">
            <Col lg="4">
              <h5 className="text-uppercase mb-4 font-weight-bold">About us</h5>
              <p> UPTOWN books is a online product of Abiba books.<br /> We attempt to extend the customer satisfaction by catering easy user-friendly search engine, quick and user-friendly payment options and quicker delivery systems. Upside to all of this, we are disposed to provide exciting offers and pleasant discounts on our books.</p>
            </Col>
            <Col md="4" lg="4" className="ml-auto">
              <h5 className="text-uppercase mb-4 font-weight-bold">Help</h5>
              <ul className="list-unstyled">
                <p><a href="/Faq">FAQ</a></p>
                <p><a href="/Policy">Cancellation and return policy</a></p>
                <p><a href="/">Terms and Conditions</a></p>
                <p><a href="/">Advertise on our site</a></p>
              </ul>
            </Col>
            <Col md="5" lg="3">
              <h5 className="text-uppercase mb-4 font-weight-bold">Contact Us</h5>
              <p><i className="fa fa-home mr-3"></i> Mindtree Limited,Bhubaneswar</p>
              <p><i className="fa fa-envelope mr-3"></i> mindtree@example.com</p>
              <p><i className="fa fa-phone mr-3"></i> +91-934 567 8788</p>
              <p><i className="fa fa-print mr-3"></i> +91-934 567 6789</p>
            </Col>
          </Row>
        </Container>
        <div className="footer-copyright text-center py-3">
          <Container fluid>
            &copy; {(new Date().getFullYear())} Copyright:  UPTOWN Books
                  </Container>
        </div>
      </Footer>
    );
  }
}

export default FooterPage;