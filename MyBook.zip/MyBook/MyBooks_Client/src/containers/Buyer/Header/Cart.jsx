//React Imports
import React from 'react';
import { bindActionCreators } from 'redux';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';

//Material UI Imports
import Card from '@material-ui/core/Card';
import Button from '@material-ui/core/Button';
import AddShoppingCart from '@material-ui/icons/AddShoppingCart';
import Money from '@material-ui/icons/Money'
import Paper from '@material-ui/core/Paper';

//Action Imports
import deleteBookFromCart from '../../../actions/actionsCart/actionsDeleteBookFromCart';

// //Container Imports
// import Home from '../Home';
// import Payment from '../Payment/Payment';

//Components Import
import { loginLogout } from '../../../components/SessionManagement/SessionManagement';

//Image Import
import emptyCart from '../../../Assests/Cart/emptyCart.png';

const whenClick = () => {
    localStorage.setItem('RederictCart', 'U have to redirect to cart page')
}

const styles = {
    columnTitle: {
        fontWeight: 'bold',
        fontFamily: 'Bungee Inline, cursive',
        marginTop: '5px',
        textAlign: 'center',
        fontSize: 35,
        color: "#1a1a1a",
        width: "100%",
    }
}

class Cart extends React.Component {
    deleteBook(_id) {
        this.props.deleteBookFromCart(_id);
    }

    render() {
        let totalCost = 0;
        if (this.props.cartbooks.length === 0) {
            return (
                <div className="container">
                    <center>
                        <p style={styles.columnTitle}>My Book Cart</p>
                        <Card style={{ marginTop: '30px', padding: '10px', backgroundColor: '#e6f2ff', marginBottom: '15%' }}>
                            <img className="img-fluid" src={emptyCart} alt="Cart is EMPTY" height='350px' width='700px' />
                            <h3 style={{ margin: '20px', padding: '10px' }}>No Items in the Cart, Please Purchase Some Books to make me Happy</h3>
                        </Card>
                    </center>
                </div>
            )
        }
        this.props.cartbooks.map(post => {
            totalCost = totalCost + post.bookCost;
        });
        return (
            <div>
                <Paper>
                    <center> <p style={styles.columnTitle}>My Book Cart</p></center>
                    {this.props.cartbooks.map((data, key) =>
                        <div className="container" key={data._id}>
                            <Card style={{ margin: '10px', padding: '10px' }}>
                                <div className="row">
                                    <div className="col-lg-2">
                                        <img src={data.imageURL} alt="book" height='150' width='100' style={{ margin: 30 }} />
                                    </div>
                                    <div className="col-lg-4">
                                        <h5 style={{ fontFamily: 'Merienda One, cursive' }}>{data.bookName}</h5>
                                        English Book
                                       <p style={{ fontFamily: 'Arima Madurai, cursive' }}> Written By: {data.author}</p>
                                        <p style={{ fontFamily: 'Trocchi, serif' }}> Quantity: {data.bookQuantity} </p>
                                        <h3 style={{ fontFamily: 'Trocchi, serif' }}>Rs. {data.bookCost}</h3>
                                        <Button color="primary" onClick={() => this.deleteBook(data._id)}><b>Remove</b></Button>
                                    </div>
                                    <div className="col-lg-4">
                                        <h6 style={{fontFamily:'Artifika, serif'}}>Delivery in 8-9 days| Free</h6><br></br>
                                    </div>
                                </div>
                            </Card>
                        </div>
                    )}
                    <Card>
                        <br></br>
                        <div className="row">
                            <div className="col-lg-2">
                            </div>
                            <div className="col-lg-5">
                                <h2 style={{fontFamily:'Bungee Inline, cursive'}}>Total Cost: Rs. {totalCost}</h2>
                            </div>
                            <div className="col-lg-4">
                                <Link color="inherit" variant="title" to="/" style={{ color: '#FFF', textDecoration: 'none' }}><Button variant="contained" color="secondary" style={{ margin: 10 }}><AddShoppingCart />Continue Shopping</Button></Link>&nbsp;
                                {loginLogout() && <Link to="/Login" style={{ textDecoration: 'none' }}>
                                    <Button variant="contained" color="secondary" onClick={whenClick}><Money /> Login to Buy</Button>
                                </Link>}
                                {!loginLogout() && <Link to="/Payment" style={{ textDecoration: 'none' }}>
                                    <Button variant="contained" color="secondary"><Money /> Buy Now</Button>
                                </Link>}
                            </div>
                        </div>
                        <br></br>
                    </Card>
                </Paper>
            </div>)
    }
}

const mapStateToProps = state => {
    return {
        cartbooks: state.storeCartdata
    }
}

const mapDispatchToProps = dispatch => {
    return bindActionCreators({ deleteBookFromCart: deleteBookFromCart }, dispatch)
};

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(Cart);