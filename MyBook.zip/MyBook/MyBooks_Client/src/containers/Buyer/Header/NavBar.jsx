//React Imports
import React from "react";
import { Route, Link, Switch } from "react-router-dom";
import PropTypes from 'prop-types';

import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import IconButton from '@material-ui/core/IconButton';
import Typography from '@material-ui/core/Typography';
import MenuItem from '@material-ui/core/MenuItem';
import Menu from '@material-ui/core/Menu';
import { withStyles } from '@material-ui/core/styles';
import AccountCircle from '@material-ui/icons/AccountCircle';
import NotificationsIcon from '@material-ui/icons/Notifications';
import MoreIcon from '@material-ui/icons/MoreVert';
import Button from '@material-ui/core/Button';

//Container Imports
//-------BUYER FOLDER
import Login from "../Login";
import Register from "../Register";
import Home from "../Home";
import Cart from "./Cart";
import SearchResult from "./SearchResult";
import Payment from "../Payment/Payment";
import Seller from "../../Seller/Seller";
import Premium from "./../BuyerProfile/Premium";
import UserProfile from "./../BuyerProfile/UserProfile";
import UserDetails from "./../BuyerProfile/UserDetails";
import Preferences from "./../BuyerProfile/Preferences";
import feedback from "./../BuyerProfile/feedback";

//--------SELLER FOLDER
import Notify from "../../Seller/Notify";
import SellerLogin from "../../Seller/SellerLogin/SellerLogin";
import YourOrders from "./../BuyerProfile/YourOrders";

//Components Import
//-------BUYER FOLDER
import Thankyou from '../../../containers/Buyer/BuyerProfile/Thankyou';
import Search from "../../../components/Buyer/Home/searchBar";
import Categories from '../../../components/Buyer/Home/Categories';
import CategoriesBookPage from "../../../components/Buyer/Home/CategoriesBookPage";
import CreditCard from "../../../components/Buyer/Payment/CreditCard";
import Paytm from "../../../components/Buyer/Payment/Paytm";
import DebitCard from "../../../components/Buyer/Payment/DebitCard";
import NetBanking from "../../../components/Buyer/Payment/NetBanking";
import ThankyouShopping from "../../../components/Buyer/Payment/ThankyouShopping";
import ErrorMessage from "../../../components/Buyer/Payment/ErrorMessage";
import BookPreview from "../../../components/Buyer/BookCard/BookPreview";
import CartBadge from "../../../components/Buyer/Home/Cart/CartBadge";
import NotFound from "../../../components/Buyer/Payment/NotFound";
import BookSeriesBookList from "../../../components/Buyer/Home/BookSeries/BookSeriesBookList";
import Updateform from "./../../../components/Buyer/UpdateProfile/Updateform";
import SortbyBookname from '../../../components/Buyer/Sort&Filter/SortbyBookname';
import SortbyBookauthor from '../../../components/Buyer/Sort&Filter/SortbyBookauthor';
import SortbyBookcost from '../../../components/Buyer/Sort&Filter/SortbyBookcost';
import SortbyBookcostHigh from '../../../components/Buyer/Sort&Filter/SortbyBookcostHigh';
import SortbyBookrating from '../../../components/Buyer/Sort&Filter/SortbyBookrating';
import FilterbyBookcost1to100 from '../../../components/Buyer/Sort&Filter/FilterbyBookcost1to100';
import FilterbyBookcost101to300 from '../../../components/Buyer/Sort&Filter/FilterbyBookcost101to300';
import FilterbyBookcost301andAbove from '../../../components/Buyer/Sort&Filter/FilterbyBookcost301andAbove';

//-------ADMIN FOLDER
import adminNavbar from "../../../containers/Admin/adminNavbar";
import BuyersList from "./../../../components/Admin/BuyersList";

//-------SELLER FOLDER
import SellerRegistration from "../../../components/Seller/SellerRegistration";
import SimpleMenu from "../../../components/Seller/Menu";
import SellerAddBookForm from "../../../components/Seller/SellerAddBookForm";
import ManageBooksBySeller from "../../../components/Seller/ManageSellerBooks";
import SellerProfile from "./../../../components/Seller/SellerProfile";
import Updatesellerdetails from "./../../../components/Seller/UpdateSellerProfile";
import SellerList from "./../../../components/Seller/SellerList";

//--------SESSION MANAGEMENT FOLDER
import { loginLogout } from "../../../components/SessionManagement/SessionManagement";
import { AdminloginLogout, login, SellerloginLogout } from "../../../components/SessionManagement/SessionManagement";

//------- FOOTER FOLDER
import Faq from "../../../components/Footer/Faq";
import Policy from "../../../components/Footer/Policy";

//--------CRUD FORMS FOLDER
import DeleteBook from "../../../components/crudForms/DeleteBook";
import AddBookForm from "../../../components/crudForms/AddBookForm";
import UpdateBookForm from "../../../components/crudForms/updateBookForm";

//--------BOOK DATA FOLDER
import BooksList from "../../../components/BookData/BooksList";
import AdminBookPreview from "../../../components/BookData/AdminBookPreview";

//--------PRIVATE ROUTE FOLDER
import { LoginRoutes, PrivateRoutesForAdmin, PrivateRoutesForUser, ErrorRoutes, PrivateRoutesForSeller,PrivateRoutesForFeedback } from "../../../components/PrivateRoute/PrivateRoute";


//---firebase
import firebase from 'firebase'

const whenClick = () => {
  localStorage.clear();
  firebase.auth().signOut().then(function () {
    console.log('Signed Out');
  }, function (error) {
    alert(error);
  });
};

const styles = theme => ({
  root: {
    width: '100%',
  },
  grow: {
    flexGrow: 1,
  },
  menuButton: {
    marginLeft: -12,
    marginRight: 20,
  },
  title: {
    display: 'none',
    [theme.breakpoints.up('sm')]: {
      display: 'block',
    },
  },
  searchIcon: {
    width: theme.spacing.unit * 9,
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  inputRoot: {
    color: 'inherit',
    width: '100%',
  },
  inputInput: {
    paddingTop: theme.spacing.unit,
    paddingRight: theme.spacing.unit,
    paddingBottom: theme.spacing.unit,
    paddingLeft: theme.spacing.unit * 10,
    transition: theme.transitions.create('width'),
    width: '100%',
    [theme.breakpoints.up('md')]: {
      width: 200,
    },
  },
  sectionDesktop: {
    display: 'none',
    [theme.breakpoints.up('md')]: {
      display: 'flex',
    },
  },
  sectionMobile: {
    display: 'flex',
    [theme.breakpoints.up('md')]: {
      display: 'none',
    },
  },
  accountCircle: {
    marginLeft: 0,
    marginRight:0,
    fontSize: 50,
    marginTop: 5,
    color:"white",
               }
});

class NavBar extends React.Component {
  state = {
    anchorEl: null,
    mobileMoreAnchorEl: null,
  };

  handleProfileMenuOpen = event => {
    this.setState({ anchorEl: event.currentTarget });
  };

  handleMenuClose = () => {
    this.setState({ anchorEl: null });
    this.handleMobileMenuClose();
  };

  handleMobileMenuOpen = event => {
    this.setState({ mobileMoreAnchorEl: event.currentTarget });
  };

  handleMobileMenuClose = () => {
    this.setState({ mobileMoreAnchorEl: null });
  };

  render() {
    const { anchorEl, mobileMoreAnchorEl } = this.state;
    const { classes } = this.props;
    const isMenuOpen = Boolean(anchorEl);
    const isMobileMenuOpen = Boolean(mobileMoreAnchorEl);

    

    const renderMobileMenu = (
      <Menu
        anchorEl={mobileMoreAnchorEl}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
        transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        open={isMobileMenuOpen}
        onClose={this.handleMobileMenuClose}
      >
            <Link to="/">
            <MenuItem>
            UPTOWN BOOKS
            </MenuItem>
            </Link>
        {AdminloginLogout() && (
        <MenuItem onClick={this.props.getDate}>
             <Link to="/Notify">
              <NotificationsIcon  />
          <p>Notifications</p>
             </Link>
        </MenuItem>
         )}
        {!AdminloginLogout() && (
        <MenuItem >
        <SimpleMenu style={{marginLeft:15}}/>
        </MenuItem>
        )}

         {!(AdminloginLogout() || SellerloginLogout()) && (
            <Link to="/Cart">
           <MenuItem>      
              {/* <CartBadge  />  */}
                <Link to="/CartBadge" style={{color:"black",textDecoration:"none"}}> <p style={{marginLeft:10}}>Cart</p></Link>
                 </MenuItem>
              </Link>
                 )}


           {!loginLogout() && (
                 <Link to="/Profile">
             <MenuItem>
             <IconButton>
            <AccountCircle />
          </IconButton>
                <p>Profile</p>
                </MenuItem>
                </Link>
               )}

               
              {login() && (
            <Link color="inherit" variant="title" to="/Login">
            <MenuItem>
               Login
            </MenuItem>
                </Link>)}
              {!login() && !AdminloginLogout() && (
                   
                    <Button>                   
                     {SellerloginLogout() ? <Link color="inherit" variant="title" onClick={whenClick} to="/SellerLogin"
                         >
                         <MenuItem>
                       Logout
                       </MenuItem>
                     </Link> : <Link color="inherit" variant="title" onClick={whenClick} to="/Login">
                       
                         <MenuItem>
                         Logout
                         </MenuItem>
                     </Link>}
                  </Button> )}
                   {AdminloginLogout() && <Button className="btn btn-Info" >
                   <Link color="inherit" variant="title" onClick={whenClick} to="/Login" >
                     <MenuItem>
                     Logout
                     </MenuItem>
                   </Link>
                 </Button>}
            
      </Menu>
    );

    return (
      <div className={classes.root}>
        <AppBar position="static">
          <Toolbar>
            <Typography className={classes.title} variant="title" color="inherit" noWrap>
            {SellerloginLogout() ? <div className='col-md-3'>Uptown Books</div> : <Link
            color="inherit" variant="title" to="/"
                    style={{ color: "#FFF", textDecoration: "none" }}>
              UPTOWN BOOKS
              </Link>}
            </Typography>
            {!AdminloginLogout() && !SellerloginLogout()&&( <div className={classes.search}>
              
              <Search />
            </div> 
          )}
            <div className={classes.grow} />
            <div className={classes.sectionDesktop}>
              
              

              {AdminloginLogout() && (
                 <div className="col-md-1" style={{marginRight:25}}>
                   <Link to="/Notify">
                     <IconButton color="inherit" >
                     <NotificationsIcon onClick={this.props.getDate} style={{color:"white", fontSize:38, margin:10}} />
                      </IconButton>
                   </Link>
                 </div>)}
                {!AdminloginLogout() && <div className="col-md-2" style={{marginRight:15}}>
                 <SimpleMenu />
                 </div>}

                {!(AdminloginLogout() || SellerloginLogout()) && (      
                     <Link color="inherit" to="/Cart">
                  <CartBadge />
                 </Link>)}
                  <div>
             
              {!loginLogout() && (<div className="col-md-1">
              <IconButton
                aria-owns={isMenuOpen ? 'material-appbar' : null}
                aria-haspopup="true"
                onClick={this.handleProfileMenuOpen}
                //color="white"
              >
                 <Link to="/Profile">
                 <AccountCircle className={classes.accountCircle} /> 
                </Link>
                </IconButton>
               </div>)}
              
              </div>
               <div> 
              {login() && (
            <Link color="inherit" variant="title" to="/Login">
                <Button><h4 style={{color:"white", fontWeight:'bold',margin:7}}>Login</h4></Button>
                </Link>)}
                {!login() && !AdminloginLogout() && (
                   <Button  className="btn btn-Info" style={{marginLeft:15}}>
                     {SellerloginLogout() ? <Link  variant="title" onClick={whenClick} to="/SellerLogin"
                         >
                       <h4 style={{color:"white", fontWeight:'bold',margin:7}}>Logout</h4>
                     </Link> : <Link  variant="title" onClick={whenClick} to="/Login">
                         <h4 style={{color:"white", fontWeight:'bold',margin:7}}>Logout</h4>
                     </Link>}
                   </Button>)}
                   {AdminloginLogout() && <Button className="btn btn-Info" >
                   <Link variant="title" onClick={whenClick} to="/Login" >
                    <h4 style={{color:"white", fontWeight:'bold',margin:7}}> Logout</h4>
                   </Link>
                 </Button>}
              </div>
              </div>
            <div className={classes.sectionMobile}>
              <IconButton aria-haspopup="true" onClick={this.handleMobileMenuOpen} color="inherit">
                <MoreIcon />
              </IconButton>
            </div>
          </Toolbar>
        </AppBar>
        {/* {renderMenu} */}
        {renderMobileMenu}



        <Switch>

          {/* ---------- ERROR ROUTES ---------- */}
          <ErrorRoutes path="/ErrorMessage" exact strict component={ErrorMessage} />

          {/* ---------- LOGIN ROUTES ---------- */}
          <LoginRoutes path="/Login" exact strict component={Login} />
          <LoginRoutes path="/Register" exact strict component={Register} />
          <LoginRoutes path="/SellerLogin" exact strict component={SellerLogin} />
          <LoginRoutes exact path="/sellerregistration" component={SellerRegistration} />


          {/* ---------- BUYER ROUTES ---------- */}

          {/* -----++++++----- HOME PAGE ROUTES -----++++++----- */}
          <Route path="/" exact strict component={Home} />
          <Route path="/Categories" exact strict component={Categories} />
          <Route path="/Category/:id" exact strict  component={CategoriesBookPage} />
          <Route path="/Category/BookPreview/:id" exact strict  component={BookPreview} />
          <Route path="/SearchResult" exact strict component={SearchResult} />
          <Route path="/BookSeries/:id" exact strict component={BookSeriesBookList} />
          <Route path="/Faq" exact strict component={Faq} />
          <Route path="/Policy" exact strict component={Policy} />
          <Route path="/Myorders" exact strict component={YourOrders} />
          <Route path="/AdminBookPreview/:id" exact strict component={AdminBookPreview} />
          <Route path="/SellerList" exact strict component={SellerList} />
          <Route path="/Thankyou" exact strict component={Thankyou} />
          <Route path="/SortbyBookname" exact strict component={SortbyBookname} />
          <Route path="/SortbyBookauthor" exact strict component={SortbyBookauthor} />
          <Route path="/SortbyBookcost" exact strict component={SortbyBookcost} />
          <Route path="/SortbyBookcostHigh" exact strict component={SortbyBookcostHigh} />
          <Route path="/SortbyBookrating" exact strict component={SortbyBookrating} />
          <Route path="/FilterbyBookcost1to100" exact strict component={FilterbyBookcost1to100} />
          <Route path="/FilterbyBookcost101to300" exact strict component={FilterbyBookcost101to300} />
          <Route path="/FilterbyBookcost301andAbove" exact strict component={FilterbyBookcost301andAbove} />
         
          {/* ----+++++++------ CART ROUTES -----++++++----- */}
          <PrivateRoutesForUser path="/Cart" exact strict component={Cart} />
          <Route path="/CartBadge" exact strict component={CartBadge}/>
          <PrivateRoutesForFeedback path="/Feedbackpage" exact strict component={feedback} />

          {/* ----++++++------ PROFILE ROUTES -----++++++----- */}
          <PrivateRoutesForUser path="/Profile" exact strict component={UserProfile} />
          <PrivateRoutesForUser path="/UpdateProfile/:email_ID" component={Updateform} />
          <PrivateRoutesForUser path="/UserDetails" exact strict component={UserDetails} />
          <PrivateRoutesForUser path="/Preferences" exact strict component={Preferences} />
          <PrivateRoutesForUser path="/Premium" exact strict component={Premium} />

          {/* ----+++++++------ PAYMENT ROUTES -----++++++----- */}
          <PrivateRoutesForUser path="/Payment" exact strict component={Payment} />
          <PrivateRoutesForUser path="/CreditCard" component={CreditCard} />
          <PrivateRoutesForUser path="/DebitCard" component={DebitCard} />
          <PrivateRoutesForUser path="/Paytm" component={Paytm} />
          <PrivateRoutesForUser path="/NetBanking" component={NetBanking} />
          <PrivateRoutesForUser path="/ThankyouShopping" component={ThankyouShopping} />

          {/* ---------- ADMIN ROUTES ---------- */}

          <PrivateRoutesForAdmin path="/adminNavbar" exact strict component={adminNavbar} />
          <PrivateRoutesForAdmin exact path="/BuyersList" component={BuyersList} />
          <PrivateRoutesForAdmin path="/BooksList" component={BooksList} />
          <PrivateRoutesForAdmin path="/AddBookForm" component={AddBookForm} />
          <PrivateRoutesForAdmin path="/DeleteBook" component={DeleteBook} />
          <PrivateRoutesForAdmin path="/UpdateBook/:id" component={UpdateBookForm} />
          <PrivateRoutesForAdmin path="/Notify" exact strict component={Notify} />

          {/* ---------- SELLER ROUTES ---------- */}

          <PrivateRoutesForSeller path="/SellerNavBar/:id" exact strict component={Seller} />
          <PrivateRoutesForSeller path="/SellerProfile" exact strict component={SellerProfile} />
          <PrivateRoutesForSeller path="/Updatesellerdetails/:email_ID" exact strict component={Updatesellerdetails} />
          <PrivateRoutesForSeller exact path="/ManageBooksSeller" component={ManageBooksBySeller} />
          <PrivateRoutesForSeller path="/SellerAddBookForm/:id" component={SellerAddBookForm} />
          <PrivateRoutesForSeller path="/UpdateBookSeller/:id" component={UpdateBookForm} />

          <Route path="*" component={NotFound} />
        </Switch>
        
      </div>
    );
  }
}

NavBar.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(NavBar);
