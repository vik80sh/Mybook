//React Imports
import React, { Component } from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';
import { bindActionCreators } from 'redux';

//Axios Import
import axios from 'axios';

//Config Import
import config from '../../../config.js';

//Material UI Imports
import Card from '@material-ui/core/Card';
import Divider from '@material-ui/core/Divider';
import Categories from '../../../components/Buyer/Home/Categories';

//Components Import
import BookCardDB from '../../../components/Buyer/BookCard/BookCard';

//Action Imports
import searchRes from "../../../actions/actionsSearchResult/actionSearchResult";


//Image Import
import noSearchResults from '../../../Assests/SearchBar/noSearchResult.png';

let _ = require('underscore');
const styles = {
    card: {
        maxWidth: 280,
        padding: '8px',
        boxShadow: '12px 0 15px -4px rgba(31, 73, 125, 0.3), -12px 0 8px -4px rgba(31, 73, 125, 0.3)',
        margin: '0px auto',
        width: '100%',
        height: '100%',
    },
    columnTitle: {
        fontWeight: 'bold',
        fontFamily: 'Verdana, Geneva, sans-serif',
        marginTop: '5px',
        textAlign: 'center',
        fontSize: 35,
        color: "#1a1a1a",
        width: "100%",
    }
}

class SearchResult extends Component {

    componentWillMount = () => {
        let arr = [];
        let value = new URL(window.location.href).searchParams;
        let searchurl = value.get('search');
        axios.get(config.urlConnection.urlBookCollection)
            .then(response => {
                response.data.forEach((data) => {
                    arr.push({
                        _id: data._id,
                        ISBN: data.ISBN,
                        bookName: data.bookName,
                        bookcategory: data.bookcategory,
                        imageURL: data.imageURL,
                        author: data.author,
                        description: data.description,
                        bookCost: data.bookCost,
                        bookQuantity: data.bookQuantity,
                        bookRating: data.bookRating,
                        releaseDate: data.releaseDate,
                        seller_ID: data.seller_ID,
                        addedBookDate: data.addedBookDate
                    })
                    let newlyDisplayed = _.filter(arr, book => (book.bookName.toLowerCase().replace(/\s+/g, '').includes(searchurl.toLowerCase().replace(/\s+/g, '')) || book.author.toLowerCase().replace(/\s+/g, '').includes(searchurl.toLowerCase().replace(/\s+/g, ''))));
                    this.props.searchRes(newlyDisplayed);
                })
            })
            .catch(error => {
                throw (error);
            });
    }

    render() {
        if (!this.props.res.length) {
            return (
                <div className="container">
                    <center>
                        <Card style={{ marginTop: '30px', padding: '10px', backgroundColor: '#e6f2ff', marginBottom: '15%' }}>
                            <img className="img-fluid" src={noSearchResults} alt="The Searched Book is not present" />
                            <h3 style={{ margin: '20px', padding: '10px' }}>Ahhhhhhhhhh! We can't seem to find the book what you are looking for!</h3>
                            <h2>Not to worry. We have Plenty of Books for You to Read</h2>
                        </Card>
                    </center>
                </div>
            )
        }

        return (
            <div>
                <Categories />
                <Divider />
                <center>
                    <div className="btn-group" style={{ padding: '1%' }}>
                        <h3 style={{ fontFamily: 'Trocchi, serif' }}>Apply Sorting & Filters to Refine & Explore &nbsp;</h3>
                        <button type="button" className="btn btn-primary">Sort & Filters</button>
                        <button type="button" className="btn btn-primary dropdown-toggle dropdown-toggle-split" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span className="sr-only">Sort & Filters</span>
                        </button>
                        <div className="dropdown-menu">
                            <p className="dropdown-item" >
                                <Link color="inherit" variant="title" to={`/SortbyBookname`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                    Sort by Book Name
              </Link>
                            </p>
                            <p className="dropdown-item" >
                                <Link color="inherit" variant="title" to={`/SortbyBookauthor`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                    Sort by Author Name
              </Link>
                            </p>
                            <p className="dropdown-item" >
                                <Link color="inherit" variant="title" to={`/SortbyBookcost`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                    Sort by Book Cost (Low -> High)
              </Link>
                            </p>
                            <p className="dropdown-item" >
                                <Link color="inherit" variant="title" to={`/SortbyBookcostHigh`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                    Sort by Book Cost (High -> Low)
              </Link>
                            </p>
                            <p className="dropdown-item" >
                                <Link color="inherit" variant="title" to={`/SortbyBookrating`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                    Sort by Book Rating
              </Link>
                            </p>
                            <div className="dropdown-divider"></div>
                            <p className="dropdown-item" >
                                <Link color="inherit" variant="title" to={`/FilterbyBookcost1to100`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                    Filter by Book Cost 1 to 100
              </Link>
                            </p>
                            <p className="dropdown-item" >
                                <Link color="inherit" variant="title" to={`/FilterbyBookcost101to300`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                    Filter by Book Cost 101 to 300
              </Link>
                            </p>
                            <p className="dropdown-item" >
                                <Link color="inherit" variant="title" to={`/FilterbyBookcost301andAbove`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                    Filter by Book Cost 301 and above
              </Link>
                            </p>
                        </div>
                    </div>
                </center>
                <div className='row'>
                    {this.props.res.map((post,key) => {
                        return (
                            <div className='col-md-3' style={{ marginBottom: 20 }} key={post._id}>
                                <Link color="inherit" variant="title" to={`/Category/BookPreview/${post._id}`} style={{ color: '#1a1a1a', textDecoration: 'none' }}>
                                    <Card style={styles.card}>
                                        <BookCardDB post={post} key={post._id} />
                                        <button className="btn btn-primary" style={{ fontFamily: 'Berlin Sans fb', fontWeight: 'bold', fontSize: 15, margin: '4px', width: '70%', marginLeft: '15%', marginBottom: '1%' }}>PREVIEW</button>
                                    </Card>
                                </Link>
                            </div>
                        )
                    })}
                </div>
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        res: state.storeSearchResult,
        books: state.storeBookData
    };
};

function mapdispatchtoProps(dispatch) {
    return bindActionCreators({ searchRes }, dispatch);
}

export default connect(
    mapStateToProps, mapdispatchtoProps
)(SearchResult);

