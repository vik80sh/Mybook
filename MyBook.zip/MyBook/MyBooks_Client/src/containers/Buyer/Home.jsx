//React Imports
import React, { Component } from 'react';
import { connect } from 'react-redux';

//React 3rd Party npm package Imports
import swal from 'sweetalert2';
import { withSwalInstance } from 'sweetalert2-react';

//Material UI Imports
import Divider from '@material-ui/core/Divider';


//Action Imports
import { fetchAllCartBooks } from '../../actions/fetchDataFromStore/actionsFetchAllCartBooks';

//Component Imports
import Carousel from '../../components/Buyer/Home/Carousel';
import Categories from '../../components/Buyer/Home/Categories';
import TrendingBooks from '../../components/Buyer/Home/TrendingBooks';
import Container from '../../components/Buyer/Home/BooksCarousel.jsx/BooksCarousel';
import AuthorFlipCard from '../../components/Buyer/Home/AuthorSection/AuthorFlipCard';
import BookSeries from '../../components/Buyer/Home/BookSeries/BookSeries';

//Container Imports
import Footer from './Footer';

// const SweetAlert = withSwalInstance(swal);

const styles = {
  columnTitle: {
    fontWeight: 'bold',
    fontFamily: 'Judson',
    marginTop: '5px',
    pAlign: 'center',
    fontSize: 30,
    color: "#1a1a1a",
    width: "100%",
  },
}

class Home extends Component {
  constructor(props) {
    super(props);
    var uidtoken = localStorage.getItem('Token');
    this.props.onFetchAllCartBooks(uidtoken);
    this.state = {
      loading: true,
      show: false,
      showAlert: false
    }
  }

  render() {
    // const { loading } = this.state;

    return (
      <div>
        <Categories />
        <Divider />
        <Carousel />
        <Divider />
        {/* <SearchFilter/>         */}
        <center>
          <p style={styles.columnTitle}>Trending Books</p>
        </center>
        <TrendingBooks />
        <Container />
        <Divider />
        <center>
          <p style={styles.columnTitle}>Here are some Entire Book Series Waiting for you...</p>
        </center>
        <BookSeries />
        <Divider />
        <Divider />
        <center>
          <p style={styles.columnTitle}>Let's Listen to some Renowned Author</p>
        </center>
        <div>
          <AuthorFlipCard />
        </div>
        <Footer />
      </div>
    );
  }
}

const mapDispatchToProps = dispatch => {
  return {
    onFetchAllCartBooks: (uidtoken) => {
      dispatch(fetchAllCartBooks(uidtoken));
    }
  };
};

export default connect(
  null,
  mapDispatchToProps
)(Home);