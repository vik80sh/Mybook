//React Imports
import React from 'react';
import { connect } from 'react-redux';
import { Link } from 'react-router-dom';

//Material UI Imports
import Card from '@material-ui/core/Card';
import Paper from '@material-ui/core/Paper';

//Image Imports
import creditCard from '../../../Assests/PaymentImages/creditCard.png';
import debitCard from '../../../Assests/PaymentImages/debitCard.png';
import paytmIcon from '../../../Assests/PaymentImages/paytmIcon.png';
import netBanking from '../../../Assests/PaymentImages/netBanking.png';

var styles = {
    quoteStyle: {
        fontSize: 30,
        textAlign: 'center',
        fontWeight: 'bold',
        fontFamily: 'Caveat, cursive',
        marginBottom: 0,
        padding: 10
    },
    titleAuthor: {
        fontSize: 20,
        fontStyle: 'italic',
        fontWeight: 'bold',
        fontFamily: 'Aladin, cursive',
    },
}
class Payment extends React.Component {
    render() {

        let totalCost = 0;
        this.props.cartbooks.map(post => {
            totalCost = totalCost + post.bookCost;
        });

        return (<div className="container" style={{ padding: 20 }}>

            <div className="row">
                <div className="col-lg-2">
                </div>
                <div className="col-lg-8">
                    <center>
                        <Paper style={{ margin: '20px' }}>
                            <br /><br />
                            <h3 style={{ fontFamily: 'Bungee Inline, cursive' }}>Total Amount to be paid is : Rs. {totalCost}</h3>
                            <br></br>
                            <h3 style={{ fontFamily: 'Trocchi, serif' }}>Please Select a Payment Method</h3>
                            <br></br>
                            <div className="row" style={{ marginLeft: '20px', marginRight: '20px' }}>

                                <div className="col-lg-3">
                                    <Link to="/CreditCard">    
                                    <Card>
                                        <img src={creditCard} height='100px' width='130px' style={{ display: 'block', margin: '5px' }} alt="creditcard" />
                                    </Card>
                                    </Link>
                                    <h6 style={{ marginTop:10, fontFamily: 'Quando, serif' }}>Credit Card</h6>
                                </div>
                                <div className="col-lg-3">
                                    <Link to="/CreditCard">       
                                    <Card>
                                        <img src={debitCard} height='100px' width='120px' style={{ display: 'block', margin: '5px' }} alt="debitcard" /></Card></Link><h6 style={{ marginTop:10, fontFamily: 'Quando, serif' }}>Debit Card</h6>
                                </div>
                                <div className="col-lg-3">
                                    <Link to='/NetBanking'>      <Card ><img src={netBanking} height='100px' width='120px' style={{ display: 'block', margin: '5px' }} alt="netbanking" /></Card></Link><h6 style={{ marginTop:10, fontFamily: 'Quando, serif' }}> Net Banking</h6>
                                </div>
                                <div className="col-lg-3">
                                    <Link to="/Paytm" > <Card><img src={paytmIcon} height='100px' width='130px' style={{ display: 'block', margin: '5px' }} alt="paytm" /></Card></Link><h6 style={{ marginTop:10, fontFamily: 'Quando, serif' }}>Paytm</h6>
                                </div>
                            </div>
                            <br></br>
                            <h2 style={{ fontFamily: 'Merienda One, cursive' }}>BUY MORE & READ MORE</h2>
                            <br />
                            <div style={styles.quoteStyle}>
                                <p>"What on Earth could be More Luxurious than a Sofa, a Book and a Cup of Coffee ?"</p>
                            </div>
                            <div style={styles.titleAuthor}>
                                <p>
                                    --- ANTONY TROLLOPE
                               </p>
                            </div>
                            <br />
                        </Paper>
                    </center>
                </div>
            </div>
        </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        cartbooks: state.storeCartdata
    };
};

export default connect(
    mapStateToProps,
    null
)(Payment);