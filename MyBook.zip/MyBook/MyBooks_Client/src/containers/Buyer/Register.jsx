//React Imports
import React, { Component } from 'react';

//Material UI Imports
import Card from '@material-ui/core/Card';

//Component Imports
import RegisterForm from '../../components/Buyer/RegisterForm/RegisterForm';

class Register extends Component {
  render() {
    return (

      <div>
        <div>
          <div className='container'>
            <div style={{
              backgroundColor: '#ffffff', position: 'relative',
              width: '100%',
              height: 'auto'
            }}>
              <Card style={{ marginTop: '3%', marginBottom: '5%', boxShadow: '22px 0 20px -4px rgba(31, 73, 125, 0.3), -12px 0 8px -4px rgba(31, 73, 125, 0.3)' }}>
                <RegisterForm />
              </Card>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Register;
