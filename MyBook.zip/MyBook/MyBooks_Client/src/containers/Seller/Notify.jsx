//React Imports
import React from "react";
import { connect } from "react-redux";

//Material UI Imports
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import ExpansionPanel from "@material-ui/core/ExpansionPanel";
import ExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
import ExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import Typography from "@material-ui/core/Typography";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import Button from "@material-ui/core/Button";

//Action Imports
import { fetchSellers } from "./../../actions/actionsSellerRegistration/fetchSellers";


//Components Imports
import CenteredTabs from "../../components/Admin/CenteredTabs";

//Axios Imports
import axios from "axios";

//Config Import
import config from "../../config.js";

const styles = theme => ({
  root: {
    width: "100%",
    height:1000,
    marginBottom:100
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    fontWeight: theme.typography.fontWeightRegular
  }
});

class Notify extends React.Component {
  constructor(props) {
    super(props);
    this.props.onFetchSellers();
  }

  handleSubmit = (userName, flag) => {
    axios
      .put(`${config.urlConnection.urlSellerCollection}/Notify`, {
        userName,
        flag
      })
      .then(response => {
        console.log(userName);
      });
  };

  render() {
    
      return (
        <div>
          <CenteredTabs />
          <br /><br />
          {this.props.seller.map((data,key) => {
            if (data.isVerified === false) {
              return (
                <div key={data._id}>
                  <ExpansionPanel>
                    <ExpansionPanelSummary expandIcon={<ExpandMoreIcon />}>
                      <Typography>Notification</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                      <div className="container">
                        <div className="row">
                          <div className="col-sm-3">NAME - </div>
                          <div className="col-sm-3">
                            <h5>{data.address.name}</h5>
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-sm-3">PIN - </div>
                          <div className="col-sm-3">
                            <h5>{data.address.pin}</h5>
                          </div>
                          <div className="col-sm-3" />
                          <div className="col-sm-3">
                            <Button
                              color="primary"
                              variant="contained"
                              type="submit"
                              value={data.userName}
                              onClick={() =>
                                this.handleSubmit(data.userName, 1)}
                            >
                              Accept
                            </Button>
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-sm-3">Area - </div>
                          <div className="col-sm-3">
                            <h5>{data.address.area}</h5>
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-sm-3">PAN - </div>
                          <div className="col-sm-3">
                            <h5>{data.PAN}</h5>
                          </div>
                          <div className="col-sm-3" />
                          <div className="col-sm-3">
                            <Button
                              color="secondary"
                              variant="contained"
                              onClick={() =>
                                this.handleSubmit(data.userName, 0)}
                            >
                              Reject
                            </Button>
                          </div>
                        </div>
                        <div className="row">
                          <div className="col-sm-3">State - </div>
                          <div className="col-sm-3">
                            <h5>{data.address.state}</h5>
                          </div>
                        </div>
                      </div>
                    </ExpansionPanelDetails>
                  </ExpansionPanel>
                </div>
              );
            }
            return true;
          })},
        </div>
      );
    }
  }
const mapStateProps = state => {
  return {
    seller: state.storeSellerData,
    state
  };
};
const mapDispachToProps = dispatch => {
  return {
    onFetchSellers: () => dispatch(fetchSellers())
  };
};

Notify.propTypes = {
  classes: PropTypes.object.isRequired
};

export default connect(mapStateProps, mapDispachToProps)(
  withStyles(styles)(Notify)
);
