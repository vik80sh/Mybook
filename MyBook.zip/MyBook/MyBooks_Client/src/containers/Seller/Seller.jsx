//React Imports
import React from 'react';

//Material UI Imports
import { withStyles } from '@material-ui/core/styles';

//Components Import
import BarChart from '../../components/Admin/Graphs/BarChartForSeller';
import CenteredTabs from'../../components/Seller/CenteredTabs'

const styles = {
  alignRight: {
    color: "inherit",
    fontSize: "25px",
    fontWeight: "bold",
    marginLeft: "25px",
    textDecoration: "none"
  },
};

let matchParams
function SellerNavbar({match}) {
  matchParams=match.params.id;
 
  return (
    <div>
  
  <CenteredTabs sellerID={matchParams}/>
        <br/>
      <center><h1>Seller DashBoard</h1></center>
      <br/>  
      <br/>
        <div className="row">
            <div className="col-sm-2" />
            <div className="col-sm-8">
            <BarChart seller={matchParams}/>
            </div>
       </div>
       <br />
       <br />
        
    </div>
  );
}
;
export default  withStyles(styles)(SellerNavbar);
