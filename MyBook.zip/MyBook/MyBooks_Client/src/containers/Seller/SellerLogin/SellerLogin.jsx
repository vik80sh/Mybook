//React Imports

import { connect } from "react-redux";
import { withRouter } from "react-router-dom";

//Axios Imports
import axios from "axios";

//Config Import
import config from "../../../config.js";

//Action Import
import { SellerID } from "../../../actions/actionsSellerLogin/actionSellerID.jsx";



//Components Import
import SellerLoginForm from "../../../components/Seller/SellerLogin/SellerLoginForm";
//import { SellerloginLogout } from "../../../components/SessionManagement/SessionManagement";

//React 3rd Party npm package Imports
import swal from 'sweetalert2';

const mapDispatchToProps = (dispatch, props) => {
  return {
    onSellerLoginData: post => {
     // let localStorageToken = localStorage.getItem("isSellerLoggedIn");
      let UserName = post.UserName;
      let Password = post.Password;
      axios
        .post(`${config.urlConnection.urlSellerCollection}/login`, {
          UserName,
          Password
        })
        .then(response => {
          if (response.status === 204) {
            swal({
              type:'error',
              title :'Oops... Wrong Input!!',
              text:'Entered Email / password is wrong'
           })  
          } else if (response.status === 200) {
            localStorage.isSellerLoggedIn = response.data;
            dispatch(SellerID(UserName));
            swal({
              position: 'top-end',
              type: 'success',
              title: 'Login as a seller succesful',
              showConfirmButton: false,
              timer: 1500
            })
          }else if (response.status === 203) {
            swal({
              type:'error',
              title :'You Are Not Verified',
              text:'Please Wait  '
           })  
          }
        })
        .catch(error => {
          console.log("Seller Login Error", error);
        });
    }
  };
};

const A = withRouter(SellerLoginForm);
export default connect(null, mapDispatchToProps)(A);