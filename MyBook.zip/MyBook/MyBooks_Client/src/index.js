//React Imports
import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import thunk from 'redux-thunk';
import registerServiceWorker, { callCache } from './registerServiceWorker';
import { BrowserRouter } from "react-router-dom";
import { createStore, applyMiddleware } from 'redux';
import { Provider } from 'react-redux';

//Bootstrap Imports
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

//Font Awesome Imports
import '../node_modules/font-awesome/css/font-awesome.min.css';

//MDB REACT Imports
import 'font-awesome/css/font-awesome.min.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'mdbreact/dist/css/mdb.css';

//Reducer Imports
import rootReducer from './reducers/index.jsx';

//Action Imports
import { fetchAllBooks } from './actions/fetchDataFromStore/actionsFetchAllBooks.jsx';
import { fetchAllCartBooks } from './actions/fetchDataFromStore/actionsFetchAllCartBooks.jsx';
import { fetchAllTrendingBook } from './actions/fetchDataFromStore/actionsFetchTrendingBooks.jsx';


const store = createStore(rootReducer, applyMiddleware(thunk));

const uidtoken = localStorage.getItem('Token');

//Fetching data for the store
store.dispatch(fetchAllBooks());
store.dispatch(fetchAllCartBooks(uidtoken));
store.dispatch(fetchAllTrendingBook());
// store.dispatch(fetchuserdetails(uidtoken));

ReactDOM.render(
    <Provider store={store}>
        <BrowserRouter>
            <App />
        </BrowserRouter>
    </Provider>, document.getElementById('root'));

registerServiceWorker();
callCache();
