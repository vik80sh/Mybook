import { combineReducers } from 'redux';
import { postBookReducer } from './postBookReducer';
import { postCartReducer } from './postCartReducer';
import { searchReducer } from './searchReducer';
import { postUserReducer } from './postUserReducer';
import { postSellerReducer } from './postSellerReducer';
import { trendingBookReducer } from './postTrendingBooksReducer';
import { feedbackBookReducer } from './postFeedback';
import { postUserOrderReducer } from './postUserOrder';

export default combineReducers({
    storeBookData: postBookReducer,
    storeCartdata: postCartReducer,
    storeSearchResult: searchReducer,
    storeUserData: postUserReducer,
    storeTrendingBookData: trendingBookReducer,
    storeFeedbackData: feedbackBookReducer,
    storeUserOrder: postUserOrderReducer,
    storeSellerData: postSellerReducer
});