//Config Import
import config from '../config.js';

export function postBookReducer(state = [], action) {
    switch (action.type) {
        case config.ACTIONS.BOOK_DATA:
            return action.bookData;
        case config.ACTIONS.DELETE_BOOK_FROM_COLLECTION:
            return action.bookData;
        default:
            return state;
    }
}
