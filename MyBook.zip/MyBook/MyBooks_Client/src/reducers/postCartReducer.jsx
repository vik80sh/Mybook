//Config Import
import config from '../config.js';

export function postCartReducer(cartState = [], action) {
    switch (action.type) {
        case config.ACTIONS.ADD_BOOK_TO_CART:
            return action.data;
        case config.ACTIONS.DELETE_BOOK_FROM_CART:
            return action.data;
        default:
            return cartState;
    }
}