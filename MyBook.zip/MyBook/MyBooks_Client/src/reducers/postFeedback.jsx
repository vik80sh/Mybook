//Config Import
import config from '../config.js';

export function feedbackBookReducer(state = [], action) {
    switch (action.type) {
        case config.ACTIONS.FEEDBACK_DATA:
            return action.feedback;
        case config.ACTIONS.FEEDBACK_DATA_UPDATE:
            return [...state, action.feedback];
        default:
            return state;
    }
}