//Config Import
import config from '../config.js';

export function postSellerReducer(state = [], action) {
    switch (action.type) {
        case config.ACTIONS.GET_SELLERS:
            return action.data;
        case config.ACTIONS.GET_SELLER_DETAILS:
            return action.data;
        default:
            return state;
    }
}