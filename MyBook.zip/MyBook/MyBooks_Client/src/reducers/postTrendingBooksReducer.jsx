//Config Import
import config from '../config.js';

export function trendingBookReducer(state = [], action) {
    switch (action.type) {
        case config.ACTIONS.TRENDING_BOOKS:
            return action.bookData;
        default:
            return state;
    }
}