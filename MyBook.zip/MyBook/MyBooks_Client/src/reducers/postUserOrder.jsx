//Config Import
import config from '../config.js';

export function postUserOrderReducer(state = [], action) {
    switch (action.type) {
        case config.ACTIONS.USERORDER_DATA:
            return action.orderData;
        default:
            return state;
    }
}