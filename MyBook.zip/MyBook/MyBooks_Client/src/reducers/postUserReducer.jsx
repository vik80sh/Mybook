//Config Import
import config from '../config.js';

export function postUserReducer(state = [], action) {
    switch (action.type) {
        case config.ACTIONS.GET_USER_DETAILS:
            return action.data;
        case config.ACTIONS.GET_USERS:
            return action.data;
        default:
            return state;
    }
}
