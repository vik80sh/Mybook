
module.exports = ({
    bookTrueData : {
        ISBN : 120456283920,
        bookName : "Life is What",
        author : "Preeti Shenoy",
        bookcategory : {
            action : true,
            fiction : false,
            horror : false,
            health : false,
            textbook : false,
            comics: false,
            biography : false,
            romance: true,
            adventure : false,
            others : true
        },
        description : "The second book by Preeti Shenoy, Life Is What You Make It, was published on January 1, 2011 and it turned out to be a national bestseller. The book has also featured in the “Top Books of 2011, ” a Nielsen list, which is released by the Hindustan Times The book was also selected as one of the all-time bestsellers of 2011 by the Times of India. ",
        bookCost : 100,
        bookQuantity : 100,
        bookRating: 5,
        seller_ID : "johns1",
        imageURL : "https://firebasestorage.googleapis.com/v0/b/mybooks-6a624.appspot.com/o/Book_Cover%2FLife%20is%20What%20You%20Make%20It.jpeg?alt=media&token=c9a97e63-5b12-40c4-98a7-ccfd19ca7c75",
    },

    bookFalseData : {
        description : "The second book by Preeti Shenoy, Life Is What You Make It, was published on January 1, 2011 and it turned out to be a national bestseller. The book has also featured in the “Top Books of 2011, ” a Nielsen list, which is released by the Hindustan Times The book was also selected as one of the all-time bestsellers of 2011 by the Times of India. ",
        bookCost : 100,
        bookQuantity : 100,
        bookRating: 5,
    },

    updateBook_trueData:{
       id: "5ba2a135082214d1e0682e8b",
       update:{
        "fiction": true,
        "others": true ,
        "bookQuantity": 102,
        "totalReview": 1,
        "author": "Krishna Readdy",
        "bookName": "Indian History",
        "description": "McGraw Hill Education is proud to present the second edition of Indian History By Krishna Reddy which provides a comprehensive approach to the various aspects of the subject. This book is meant for Civil Services Preliminary and Main Examinations, State Civil Services Examinations and other competitive examinations where History is an important area.",
        "bookCost": 110,
        "bookRating": 3,
        "seller_ID": "Vikash",
        "imageURL": "https://rukminim1.flixcart.com/image/832/832/jbgtnrk0/book/5/8/9/ias-mains-general-studies-chapterwise-solved-papers-2017-1997-original-imafytg4fpj2ujav.jpeg?q=70"
       }
    },

    updateBook_falseData:{
        id: "5aa2a135082214d1e0682e2a",
        update:{
            "description": "McGraw Hill Education is proud to present",
            "bookCost": 110,
            "bookRating": 3
        }
     },
     updateBook_errorData:{
        id: "5aa2a",
        update:{
            "description": "McGraw Hill Education is proud to present",
            "bookCost": 110,
            "bookRating": 3
        }
     },

     delete_BookData:{
         flaseValue :{
             id:"5ba3e6d037176bcaa4c66"
         },
         flaseValue1 :{
             id:"5aa3e6d037176bcba4c7634a"
         },
     },

     insertInDatabase : {
        ISBN : 120456283920,
        bookName : "Unit Testing",
        author : "My Book's Group",
        bookcategory : {
            action : true,
            fiction : false,
            horror : false,
            health : false,
            textbook : false,
            comics: false,
            biography : false,
            romance: true,
            adventure : false,
            others : true
        },
        description : "This book is available only for Unit testing ",
        bookCost : 100,
        bookQuantity : 100,
        bookRating: 5,
        seller_ID : "johns1",
        imageURL : "https://rukminim1.flixcart.com/image/832/832/jfu03gw0/headphone/u/2/z/1more-piston-fit-earphones-with-mic-original-imaf47gp8cphf7pj.jpeg?q=70",
    },

    cartData:{
        savaBook:{
            userName : "Vikas1h",
            bookName :  "Unit Testing",
            author   :  "My Books's Group",
            imageURL :  "NA",
            bookCost :  200,
        },
        id:0

    }
     
})
     

