// module.exports = {
//     DB: 'mongodb://localhost:27017/MyBookProject'


//  };
mongoose = require('mongoose')

 const DBconfig = {
     dbUrl      : "orchardmongo.eastus.cloudapp.azure.com",
     db         : "Orchard3",
     user       : "mongoUser3",
     pass       : "User3pwd"
 }

 module.exports={DBconfig}

