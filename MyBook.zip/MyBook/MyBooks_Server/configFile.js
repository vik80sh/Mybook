
module.exports = ({
    server: {
        successfull: "Database is Connected",
        failed: "Cannot connect to the Database  , Error : ",
        listening: "Listening on Port :  "
    },
    error: {
        collectionNotFound: "Database Collection is Not Available",
        missingField: "Some input fields are missing"
    },
    collectionIsEmpty: "Data is not Available",
    dataSaved: "Data saved in database "
})