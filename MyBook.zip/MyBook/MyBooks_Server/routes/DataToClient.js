// const express = require('express'), bodyParser = require('body-parser');
// const app = express();
// app.use(bodyParser.urlencoded({ extended: false }));
// app.use(bodyParser.json());
// const Registration = express.Router();

// // Require Post model in our routes module
// let User = require('../schema/UserSchema');

// // Defined store route

// Registration.route('/registration').post(function (req, res) {
//   console.log("Hello   ",req.body)
//   let user = new User(req.body);
//   user.save()
//     .then(post => {
//       console.log("Hey  ",post)
//       res.status(200).json(post);
//     })
//     .catch(err => {
//       res.status(400).send("unable to save to database");
//     });
// });

// module.exports = Registration;