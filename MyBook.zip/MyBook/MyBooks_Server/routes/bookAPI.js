const express = require('express'), bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
const bookAPI = express.Router();

const Book = require('../schema/bookSchema');
const message = require('../configFile')


bookAPI.route('/').get(function (req, res) {
    Book.find(function (err, post) {
        const errorMessage = message.error.collectionNotFound + "      "+ err ;
        if (err)
            res.status(400).json(errorMessage)
        else 
            res.status(200).json(post)
    });
});

bookAPI.route('/trendingBook').get(function (req, res) {
    Book.aggregate([{ $sample: { size: 8 } }], function (err, result) {
        const errorMessageForTrendingBooks = message.error.collectionNotFound + "       " + err ;
        if (result) 
            res.status(200).json(result)
        else
            res.status(400).json(errorMessageForTrendingBooks)
    })
});

bookAPI.route('/add').post(function (req, res) {
    const insert = {
        ISBN        : req.body.ISBN,
        author      : req.body.author,
        bookName    : req.body.bookName,
        bookcategory: {
            action      : req.body.action,
            fiction     : req.body.fiction,
            horror      : req.body.horror,
            health      : req.body.health,
            textbook    : req.body.textbook,
            comics      : req.body.comics,
            biography   : req.body.biography,
            romance     : req.body.romance,
            adventure   : req.body.adventure,
            others      : req.body.others
        },
        description : req.body.description,
        bookCost    : req.body.bookCost,
        bookQuantity: req.body.bookQuantity,
        //bookQuantity: Math.abs(bookQuantity),
        bookRating  : (req.body.bookRating),
        releaseDate : req.body.releaseDate,
        seller_ID   : req.body.seller_ID,
        imageURL    : req.body.imageURL
    }
    var x="wrong"
    Book.find({author:insert.author , bookName:insert.bookName , seller_ID : insert.seller_ID} , 
        function(err,result){
          if(err) 
            res.status(400).json(x)
          else if(result.length!=0)
            res.status(204).json(x)
          else{
            let user = new Book(insert);
            user.save(function (err, post) {
                const errorMessageForBook = message.error.missingField + "       "+err;
                const dataInserted = message.dataSaved + "    " + post ;
                if (err) 
                    res.status(400).json(errorMessageForBook)
                else
                    res.status(200).json(dataInserted)
                
            });
          }  
        })
});

bookAPI.route('/UpdateBook/:id').put(function (req, res) {
    
    Book.findByIdAndUpdate({ _id: req.params.id }, {
        $set: {
            author      : req.body.author,
            bookName    : req.body.bookName,
            bookcategory: {
                action      : req.body.action,
                fiction     : req.body.fiction,
                horror      : req.body.horror,
                health      : req.body.health,
                textbook    : req.body.textbook,
                comics      : req.body.comics,
                biography   : req.body.biography,
                romance     : req.body.romance,
                adventure   : req.body.adventure,
                others      : req.body.others
            },
            description  : req.body.description,
            bookCost     : req.body.bookCost,
            bookQuantity : req.body.bookQuantity,
            bookRating   : req.body.bookRating,
            imageURL     : req.body.imageURL
        }
        
    }, function (err, post) {
        const inputFiledMissing     = message.error.missingField + "     "+err;
        const dataNotPresent = message.collectionIsEmpty + " for This  " + req.params.id ;
        //let length =Object.keys(post).length;
        
        if (err) 
            res.status(400).json(inputFiledMissing) 
        else if (post!==null)
             res.status(200).json(post) 
        else
             res.status(204).json(dataNotPresent)
    });
});

bookAPI.route('/deleteBookFromCollection/:id').get(function (req, res) {
    Book.findByIdAndRemove({ _id: req.params.id }, function (err, post) {
       
        if (err) res.status(400).json(err);
        else if (post!=undefined){
            
            Book.find(function (error, postdata) {
                if (err) 
                      res.status(400).json(error)
                else 
                     res.status(200).json(postdata)
            });
        }
        else if(post===null)
            res.status(204).json("Id  Not Found")
        else
            res.status(200).json("Delete from Collection")
            
    });
});

module.exports = bookAPI;


