const express = require('express'), bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
const cartAPI = express.Router();

const userCart = require('../schema/cartSchema');
const Book = require('../schema/bookSchema');
const message = require('../configFile')


cartAPI.route('/:id').get(function (req, res) {
    let id = req.params.id;
    userCart.find(
        { userName: id }, function (err, post) {
           
            const errorMessage=message.error.collectionNotFound+ "       "+err;
            if (err)
                res.status(400).json(errorMessage)
            else{
                if(post.length!=0)
                    res.status(200).json(post)
                else
                   res.status(204).json("No Data in Your cart")
            }
        });
});

cartAPI.route('/findCart/:userID').get(function (req, res) {
    let user_ID = req.params.userID
    userCart.find(
        { userName: user_ID }, function (err, post) {
            if (err)
                res.status(400).json(err)
            else
                res.status(200).json(post)
        });
});

cartAPI.route('/addBookToCart').post(function (req, res) {
    const bookName = req.body.bookName,
        author = req.body.author,
        bookCost = req.body.bookCost,
        imageURL = req.body.imageURL,
        _id = req.body._id,
        userName = req.body.uidToken;
    userCart.find(
        { userName: userName, bookName: bookName, author: author }, function (err, post) {
            if (err)
                res.status(400).json(err)
            else {
                if (post.length != 0) {
                    let _id = post[0]._id;
                    let bookQuantity = post[0].bookQuantity + 1;
                    let bookCost1 = post[0].bookCost + bookCost;
                    _id = { _id: _id };
                    bookQuantity = { $set: { bookQuantity: bookQuantity, bookCost: bookCost1 } };
                    userCart.update({ userName: userName, bookName: bookName, author: author },
                        bookQuantity, function (error, postData) {
                            const cartErrorMessage =message.error.collectionNotFound + "    "+error;
                            if (error)
                                res.status(400).json(cartErrorMessage);
                            else
                                userCart.find({ userName: userName }, function (err, post) {
                                    if (err)
                                        res.status(400).json(cartErrorMessage)
                                });
                        })
                }

                else {
                    var insertData = {
                        userName: userName,
                        bookName: bookName,
                        author: author,
                        bookCost: bookCost,
                        imageURL: imageURL,
                        bookQuantity: 1
                    }
                    let userCartData = new userCart(insertData);
                    userCartData.save(function (error, postData) {
                        if (error)
                            res.status(204).send(error);
                        else
                            userCart.find({ userName: userName }, function (err, post) {
                                if (err)
                                    res.status(400).json("Collection not find")
                                else
                                    res.status(200).json(post)
                            });
                    })
                }
            }
        });
});

cartAPI.route('/deleteBookFromCart').post(function (req, res) {
    const _id = req.body._id,
        userName = req.body.userName,
        checkInDb = {
            _id: _id,
            userName: userName
        }
    userCart.findOneAndDelete(checkInDb, function (err, post) {
        if (err) res.json(err);
        else
            userCart.find({ userName: userName }, function (err, post) {
                if (err)
                    res.status(400).json(err)
                else
                    res.status(200).json(post)
            });
    });
});

module.exports = cartAPI; 

