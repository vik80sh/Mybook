const express = require('express'), bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
const feedbackAPI = express.Router();

const Feedback = require('../schema/feedbackSchema');
const User = require('../schema/UserSchema');
const Book = require('../schema/bookSchema');
const message = require('../configFile')

feedbackAPI.route('/feedbackSubmit').post(function (req, res) {
    let name;
    User.find({userName:req.body.userName}, function(err,result){
        if(err) res.status(400).json("UserName Not Found")
        else{
               name   = result[0].name
    
               insert = {
                    userName    : req.body.userName,
                    name        : name,
                    author      : req.body.bookName,
                    bookName    : req.body.author,
                    feedback    : req.body.feedback,
                    bookRating  :  req.body.bookRating   
               }
 
               if(insert.bookName ==='' || insert.author==='')
                   res.status(400).json("BookName or Author is Empty")
               let feedback = new Feedback(insert);
               feedback.save(function (err, post){
                 if(err)
                     res.status(400).json(err)
                 else{
                       Book.find({author:insert.author , bookName : insert.bookName},function(err,result){
                            if(err) res.status(204).json(err)
                            else{
                                let totalFeedback= result[0].totalReview ;
                                let totalStar = result[0].bookRating;
                                totalStar=((totalStar * totalFeedback) + insert.bookRating) / (totalFeedback + 1) ;
                                totalStar=(totalStar).toFixed(1);
                                setBookRate = { $set: {bookRating : totalStar , totalReview : totalFeedback + 1 } };
                                Book.updateOne({author:insert.author , bookName : insert.bookName},setBookRate , function(err,resultx){
                                    if(err) res.status(400).json(err)
                                    else
                                        res.status(200).json("Updated")
                                })
                            }
                       })
                }
            });
        }
    })
});

feedbackAPI.route('/fetchfeedback/:id').get(function(req,res){
    Book.find({_id:req.params.id},function(err,post){
        const errorMessage = message.error.collectionNotFound+"    "+err;
        if(err)
            res.status(400).json(errorMessage);
        else{
            if(post.length!=0){
                let bookName=post[0].bookName,
                author = post[0].author;
                Feedback.find({bookName:bookName},function(err,post){
                    if(err)
                            res.status(400).json(err);
                    else{
                        if(post.length!=0)
                                res.status(200).json(post);
                        else
                                res.status(204).json("No feedback Availabe")
                    }
                })
            }
            else
                res.status(204).json("Book Not Found ",post)
        }
    })
})

module.exports = feedbackAPI;
