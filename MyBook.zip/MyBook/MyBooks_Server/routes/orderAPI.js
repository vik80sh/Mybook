const express = require('express'), bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
const orderAPI = express.Router();

const Order = require('../schema/orderSchema');
const userCart = require('../schema/cartSchema');
const Book = require('../schema/bookSchema');
const message = require('../configFile')


var nodemailer = require("nodemailer");
var transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
        user: "mbooks51@gmail.com",
        pass: "weare@11"
    }
});

orderAPI.route('/userOrder/:userName').get(function (req, res) {
    let userName = req.params.userName;
    Order.find({ userName: userName }, function (err, post) {
        const dataNotFound = message.collectionIsEmpty;
        if (err) res.status(400).json(err)
        else if (post.length != 0)
            res.status(200).json(post)
        else
            res.status(204).json(dataNotFound)
    });
});


orderAPI.route('/orderPlaced').post(function (req, res1) {
    let userName = req.body.userName;
    let array = [],
        bookDetail = [],
        totalNumber = 0;
    userCart.find({ userName: userName }, function (err1, result) {
        let flag = true;
        var numberOfBook;
        totalNumber = Object.keys(result).length;
        for (var i = 0; i < result.length; i++) {
            numberOfBook = result[i].bookQuantity;
            title = result[i].bookName;
            bookAuthor = result[i].author;
            bookDetail.push({ bookName: title, author: bookAuthor })
            Book.find({ bookName: title, author: bookAuthor }, function (err2, bookresult) {
                if (err2) { }
                else {
                    let isGreaterThanZero = bookresult[0].bookQuantity - numberOfBook;
                    array.push(isGreaterThanZero)
                    let bookMessage = numberOfBook + "Books are not Present in Our Book Store Please reduce Number's Of Book";
                    if (isGreaterThanZero < 0) {
                        flag = false;
                        res1.status(203).json(bookMessage)
                    }
                }
            })
        }
        insert = {
            userName: userName,
            shippingAddress: {
                name: req.body.name,
                area: req.body.area,
                flatNo: req.body.flatNo,
                state: req.body.state,
                pin: req.body.pin,
                phoneNo: req.body.phoneNo
            },
            orderDetail: result,
            totalCost: req.body.totalCost,
        }
        email = req.body.email_ID
        let order = new Order(insert);
        setTimeout(
            () => {
                if (flag === true) {
                    userCart.remove({ userName: userName }, function (err4, res3) {
                        if (err4) res3.status(400).json("Collection is not present in Database ")
                    })
                    order.save()
                    const mailOptions = {
                        from: '"Uptown Books"<mbooks@gmail.com>', // sender address 
                        to: email, // list of receivers 
                        subject: "Order Confirmation", // Subject line 
                        html: `<h1>Hi  ${insert.shippingAddress.name}</h1>
                        <br/>
                        <h3>Your Order has been placed Succesfully</h3>
                        <br/><h4>You will receive your order within 8-9 days</h4>
                        <br/>
                        <h5>It was a great experience to have you shop with us visit again.</h5>
                        ----------------------------------------------------
                        <h5>Total Cost : ${insert.totalCost}</h5>
                        <br/><h3>Thanks for shopping with us</h3>
                        <br/><h2>Spend Less & Read More</h2>
                        <br/>` // plain text body 
                    };
                    for (let i = 0; i < totalNumber; i++) {
                        let checkdata = bookDetail[i],
                            totalBook = array[i];
                        if (totalBook <= 0) {
                            Book.remove(checkdata, function (error1, res51) {
                                if (error1) res51.status(400).json("Deteled from Database")
                            })
                        }
                        else {
                           let bookQuantityUpdate = { $set: { bookQuantity: totalBook } };
                            Book.update(checkdata, bookQuantityUpdate, function (error, res5) {
                                if (error) res5.status(400).json("Collection is not present in Database")
                            })
                        }
                    }
                    transporter.sendMail(mailOptions, function (err, info) {
                        if (err) console.log(err);
                        else console.log(info);
                    });
                    res1.status(200).json(" Book Collection Updated ")
                }
            }, 500)
    })
})


module.exports = orderAPI;

