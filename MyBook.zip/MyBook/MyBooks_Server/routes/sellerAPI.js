const express = require("express"),
  bodyParser = require("body-parser");
const app = express();
const jwt = require("jsonwebtoken");
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
const sellerAPI = express.Router();

// Require Post model in our routes module
const Seller = require("../schema/sellerSchema");
const message = require('../configFile')


sellerAPI.route('/SellerID').post(function (req, res){
const email=req.body.email;
Seller.find({email_ID : email},function (err, post){
    if(err)
        res.status(err);
    if(post)
        res.status(200).json(post)  
})
})


// registration

sellerAPI.route("/seller").post(function (req, res) {
  const userName = req.body.userName,
  email_ID = req.body.email_ID;
  var x="wrong"
  
  Seller.find(
    { $or: [{ userName: userName }, { email_ID: email_ID }] },
    function (err, post) {
      
      if (err) res.status(err);
      if (post) {
        if (post.length != 0) {
          res.status(204).json(x)
        } else {
          const sdata = {
            userName: req.body.userName,
            email_ID: req.body.email_ID,
            password: req.body.password,
            address: {
                name: req.body.Name,
                area: req.body.area,
                flatNo: req.body.flatNo,
                //landmark:req.body.landmark,
                state: req.body.state,
                pin: req.body.pin,
                phoneNo: req.body.Phone
            },
            PAN: req.body.PAN,
            GST_NO: req.body.GST_NO,
          };
         
          let sellerdata = new Seller(sdata);
          sellerdata.save(function (err, post) {
            if (err) res.status(400)
            else
              res.status(200).json(post);
          });
        }
      }
    });
});

// getting seller details

sellerAPI.route("/Sellers").get(function (req, res) {
  Seller.find(function (err, post) {
    if (err) res.status(400).json(err);
    else 
      res.status(200).json(post);
  });
});

// notification 

sellerAPI.route("/Notify").put(function (req, res) {
  const userName = req.body.userName;
  const flag = req.body.flag;

  if (flag === 0) {
    Seller.remove({ userName: userName }, function (err, post) {
      if (err) console.log("Error Bro ", err);
      else console.log("Successful ", post);
    });
    return;
  }

  Seller.findOneAndUpdate({ userName: userName }, { $set: { isVerified: true } },
    function (err, post) {
      if (err)  res.status(400).json(err);
      else res.status(200)    
    }
  );
});

// Login 

sellerAPI.route("/login").post(function (req, res) {

  let userName = req.body.UserName,
      password = req.body.Password;
      var x="wrong"
  const isAvailableUserName = {
    userName: userName,
    password: password
  }
 

  Seller.find({ email_ID:userName , password : password }, function (err,post) {
    if (err) res.status(400).json(err);
    else {
      if (post.length != 0) {
        if (post[0].isVerified == false) 
          res.status(203).json(x);
        else 
          jwt.sign(isAvailableUserName, "superSecret", (error, token) => {
            if (err)  res.status(400)
            else  res.status(200).json(token);
          });
      } else
        res.status(204).json("password Not match");
    }
  });
});

// getting seller Id as userName

sellerAPI.route("/SellerID").post(function (req, res) {
  const email = req.body.email;
  Seller.find({ email_ID: email }, function (err, post) {
    if (err) res.status(400)
    if (post) res.status(200).json(post);
  });
});

// getting Seller profile 

sellerAPI.route('/sellerprofile/:userName').get(function (req, res) {
  Seller.find({ userName: req.params.userName }, function (err, post) {
    if (err)
      res.status(400).json(err)
    else 
      res.status(200).json(post);
  });
});

// seller profile Update

sellerAPI.route('/updatesellerdetails').put(function (req, res) {
  const userName = req.body.userName;
  const address = {
    name: req.body.name,
    area: req.body.area,
    flatNo: req.body.flatNo,
    state: req.body.state,
    pin: req.body.pin
  },
    PAN = req.body.PAN
 
  Seller.findOneAndUpdate({ userName: userName },
    { $set: { address: address, PAN: PAN } },
    function (err, post) {
      if (err) res.status(400).json(err)
      else res.status(200).json(post);
    });
});

module.exports = sellerAPI;
