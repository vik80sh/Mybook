const webpush = require('web-push')
const sendNotification = (req, res) => {
    const publicKey =
        "BMRV7gdGKDFYNZUKAQuyGNxa0XGRGCwgckMQe5Mg_Ug6PZxBze3p8gIwipxt0Bd2Qrnu4ZqFzo7-jH2fQwmWSkE"
    const privateKey = "lTJrK8zG9KihoiODVPHnv8RPbK2WUij_KGSMGc22AI0"
    const subscription = req.body.subscription;
    res.send(200)
    const payload = JSON.stringify({ title: "Welcome to Uptown Books" });
    webpush.setVapidDetails(
        "mailto:test@test.com",
        publicKey,
        privateKey
    );
    webpush
        .sendNotification(req.body.subscription, payload)
        .catch(err => console.error(err));
}
module.exports = sendNotification