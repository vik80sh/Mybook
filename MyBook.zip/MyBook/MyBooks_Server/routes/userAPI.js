const express = require('express'), bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
const Registration = express.Router();

const User = require('../schema/UserSchema');
const message = require('../configFile')


Registration.route('/buyerRegistration').post(function (req, res) {
    let user = new User(req.body);
    user.save(function (err, post) {
        if (err)
            res.status(400).json("Email_Id is already present in database")
        else
            res.status(200).json("Thank you for registration ")
    });
});

Registration.route('/userProfile/:userName').get(function (req, res) {
    let userName = req.params.userName;
    User.find({ userName: userName }, function (err, post) {
        if (err) res.status(400).json(err)
        else res.status(200).json(post)
    });
});

Registration.route('/addpreference').post(function (req, res) {
    const userName = req.body.userName,
        preference = {
            fiction: req.body.fiction,
            action: req.body.action,
            horror: req.body.horror,
            health: req.body.health,
            textbook: req.body.textbook,
            comics: req.body.comics,
            biography: req.body.biography,
            romance: req.body.romance,
            adventure: req.body.adventure,
            others: req.body.others
        }
    User.update({ userName: userName }, { $set: { preferenece: preference } }, function (err, post) {
        if (err)
            res.status(400).json(err)
        else
            res.status(200)
    });
});

Registration.route('/updatedetails').put(function (req, res) {
    const userName = req.body.userName,
        name = req.body.name,
        phoneNo = req.body.phoneNo;
    User.findOneAndUpdate({ userName: userName }, { $set: { name: name, phoneNo: phoneNo } }, function (err, post) {
        if (err) res.status(400).json(err)
        else res.status(200).json(post);
    });
});


Registration.route('/fetchusers').get(function (req, res) {
    User.find(function (err, post) {
        if (err) res.status(400).json(err)
        else res.status(200).json(post)
    });
});

module.exports = Registration;
