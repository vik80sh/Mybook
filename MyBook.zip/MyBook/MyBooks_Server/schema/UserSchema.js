const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define collection and schema for Post
var user = new Schema({
  name:           {type: String, max: 35 },
  userName:       {type: String, max: 35,  required: true},
  email_ID:       {type: String, unique:true,required: true } ,
  password:       {type: String, min:5 , max: 25 , required: true  },
  phoneNo :       {type: String, max: 10  },
  preferenece:    {
    fiction:           {type:Boolean , default:0},
    action:            {type:Boolean , default:0},
    horror:            {type:Boolean , default:0},
    health:            {type:Boolean , default:0},
    textbook:          {type:Boolean , default:0},
    comics:            {type:Boolean , default:0},
    biography:         {type:Boolean , default:0},
    romance:           {type:Boolean , default:0},
    adventure:           {type:Boolean , default:0},
    others:            {type:Boolean , default:1}  
  },
  isPremium:      {type: Boolean, default: 0 },
  isAdmin:        {type: Boolean, default: 0 },
  isGoogle:       {type: Boolean, default: 0 }
});

module.exports = mongoose.model('user', user);