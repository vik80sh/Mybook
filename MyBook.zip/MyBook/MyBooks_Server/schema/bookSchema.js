const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define collection and schema for Post
var books = new Schema({

    ISBN: { type: Number, required: true },
    bookcategory: {
        fiction: { type: Boolean, default: 0 },
        action: { type: Boolean, default: 0 },
        horror: { type: Boolean, default: 0 },
        health: { type: Boolean, default: 0 },
        textbook: { type: Boolean, default: 0 },
        comics: { type: Boolean, default: 0 },
        biography: { type: Boolean, default: 0 },
        romance: { type: Boolean, default: 0 },
        adventure: { type: Boolean, default: 0 },
        others: { type: Boolean, default: 0 }
    },
    imageURL: { type: String },
    bookName: { type: String, required: true },
    author: { type: String, required: true },
    description: { type: String, min: 20, max: 250, required: true },
    bookCost: { type: Number, required: true },
    bookQuantity: { type: Number, default: 1 },
    bookRating: { type: Number },  // average Rating calculated by the help of review collection
    totalReview: { type: Number, default: 1 },
    releaseDate: { type: Date, default: Date.now() },
    seller_ID: { type: String, required: true },
    AddedBookDate: { type: Date, default: Date.now() }
})

module.exports = mongoose.model('bookdata', books);
