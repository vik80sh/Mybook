const mongoose = require('mongoose'); 

const Schema = mongoose.Schema; 

 

var userCart = new Schema({ 
    userName :      {type: String, max: 35, required: true}, 
    bookName :      {type: String , required: true }, 
    author :        {type: String , required: true} ,
    imageURL :      {type: String , required: true} ,
    bookCost :      {type: Number , required: true }, 
    bookQuantity:   {type: Number , default: 1},  

}) 

module.exports = mongoose.model('usercart', userCart); 