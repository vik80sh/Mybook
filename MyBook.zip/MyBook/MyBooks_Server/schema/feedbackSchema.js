const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define collection and schema for Post
var Feedback = new Schema({

    userName:             {type: String , required: true  },
    name:                 {type: String , default:"Anonymous"},
    bookName:             {type: String , required: true  },
    author:               {type: String , required: true} ,
    feedback:              {type: String }, 
    bookRating:           {type: Number },  // average Rating calculated by the help of review collection
    ratingDate:           {type: Date   , default: Date.now() + 4*24*60*60000}
})

module.exports = mongoose.model('feedback', Feedback);


