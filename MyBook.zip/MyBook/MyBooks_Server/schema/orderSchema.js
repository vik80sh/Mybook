const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Define collection and schema for Post
var orderDetail = new Schema({
    userName:         {type: String, max: 35, required: true },
    //order_ID:         "productid",
    //sequence_value:     0,    //getNextSequenceValue("productid"),
    shippingAddress: {
                    name:       {type: String , required: true},
                    area:       {type: String , required: true},
                    flatNo:     {type: String },
                    landmark:   {type: String },
                    state:      {type: String , required: true},
                    pin:        {type: String , required: true},
                    phoneNo:    {type: String}
    },
    orderDetail :   [
                      { 
                        bookName :  {type: String , required: true},
                        author :    {type: String , required: true},
                        bookQuantity:   {type: Number , default: 1},
                        bookCost:   {type: Number , required: true},
                        imageURL :  {type: String , required: true} 
                      }
    ],
    //bookQuantity:       {type: Number , default: 1},
    totalCost:          {type: Number , required: true },
    paymentMethod:      {type: String , default: "Net Banking"},  
    deliveryDate:       {type: Date , default: Date.now()},
    isDeliver:          {type: Boolean, default: 1 },  
})

module.exports = mongoose.model('order', orderDetail);
