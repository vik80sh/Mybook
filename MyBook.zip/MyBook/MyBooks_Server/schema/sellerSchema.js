const mongoose = require('mongoose'); 
const Schema = mongoose.Schema; 
var seller = new Schema({ 
    userName:           {type:  String , max: 35 , required:  true , unique:true  }, 
    email_ID :          {type:  String , unique: true , required: true} , 
    password:           {type:String, min:5 ,max: 25 , required: true }, 
    address:    { 
                name:           {type: String , required: true}, 
                area:           {type:String , required: true}, 
                flatNo:         {type:String },  
                state:          {type:String , required: true}, 
                pin:            {type:String , required: true}, 
                phoneNo:        {type: String , max: 10 } 

    }, 
    PAN:               {type: String , required: true}, 
    GST_NO:            {type: String , required: true},
    isVerified:        {type: Boolean, default: false }, 
})  
module.exports = mongoose.model('sellerdata', seller); 
