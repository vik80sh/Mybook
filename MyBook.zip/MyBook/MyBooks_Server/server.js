const express = require('express'),
  path = require('path'),
  bodyParser = require('body-parser'),
  cors = require('cors'),
  mongoose = require('mongoose'),
  config = require('./config/DB');

const app = express();

const UserSchema = require('./routes/userAPI');
const BookSchema = require('./routes/bookAPI');
const CartSchema = require('./routes/cartAPI');
const FeedbackSchema = require('./routes/feedbackAPI');
const OrderSchema = require('./routes/orderAPI');
const SellerSchema = require('./routes/sellerAPI');
const sendNotification = require('./routes/sendNotification');

mongoose.Promise = global.Promise;
mongoose.connect(`mongodb://${config.DBconfig.dbUrl}/${config.DBconfig.db}`, {
  user: config.DBconfig.user,
  pass: config.DBconfig.pass
}).then(
  () => { console.log('Database is connected') },
  err => { console.log('Can not connect to the database' + err) }
  );

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json());
app.use(cors());
const Port = process.env.PORT || 4000;

app.use('/user', UserSchema);
app.use('/bookdata', BookSchema);
app.use('/usercart', CartSchema);
app.use('/feedback', FeedbackSchema);
app.use('/order', OrderSchema);
app.use('/sellerdata', SellerSchema);
app.post('/subscribe', sendNotification)


const server = app.listen(Port, function () {
  console.log('Listening on port ' + Port);
});

module.exports = server