
let chai = require('chai');
let chaiHttp = require('chai-http');
let server = require('../server');

let should = chai.should();

let data = require('../Data/test')
const Book = require('../schema/bookSchema');

chai.use(chaiHttp);


// mocha --timeout 18000

 describe('Testing BookDataBase ', () => {
    it('it should GET all the books : status 200', (done) => {
        chai.request(server)
            .get('/bookdata')
            .end((err, res) => {
                res.should.have.status(200);
                done();
            });
    });

    it('it should GET 8 the books Random Books : status 200', (done) => {
          chai.request(server)
              .get('/bookdata/trendingBook')
              .end((err, res) => {
                  res.should.have.status(200);
                  done();
              });
      });

      it('it should not POST book - bad request : status 400 ', (done) => {
      chai.request(server)
          .post('/bookdata/add')
          .send(data.bookFalseData)
          .end((err, res) => {
                res.should.have.status(400);
            done();
          });
    });

    it('it should POST a Book inside Collection : status 200', (done) => {
      chai.request(server)
          .post('/bookdata/add')
          .send(data.bookTrueData)
          .end((err, res) => {
                res.should.have.status(200);
            done();
          });
    });


    it('it should UPDATE a book of given the id : status 200 ', (done) => {
              chai.request(server)
              .put(`/bookdata/UpdateBook/${data.updateBook_trueData.id}`)
              .send(data.updateBook_trueData.update)
              .end((err, res) => {
                    res.should.have.status(200);  
                done();
              });
        });

    it('it should Not UPDATE a book : status 204  ', (done) => {
        chai.request(server)
        .put(`/bookdata/UpdateBook/${data.updateBook_falseData.id}`)
        .send(data.updateBook_falseData.update)
        .end((err, res) => {
                res.should.have.status(204);  
            done();
        });
    }); 
    
    it('it should Not UPDATE a book :  status 400', (done) => {
        chai.request(server)
        .put(`/bookdata/UpdateBook/${data.updateBook_errorData.id}`)
        .send(data.updateBook_errorData.update)
        .end((err, res) => {
                res.should.have.status(400);  
            done();
        });
    }); 

    
    it('it should Not Delete book : status 400', (done) => {
        chai.request(server)
        .get(`/bookdata/deleteBookFromCollection/${data.delete_BookData.flaseValue.id}`)
        .end((err, res) => {
                res.should.have.status(400);  
            done();
        });
    }); 


    it('it should Delete book from Collection : status 200', (done) => {
        let id="x";
        let book=new Book(data.insertInDatabase)
        book.save(function(error,result){
             id=result._id;
        })
        setTimeout(()=>{
            chai.request(server)
            .get(`/bookdata/deleteBookFromCollection/${id}`)
            .end((err, res) => {
                    res.should.have.status(200);  
                done();
            });
        }, 4000)
    }); 

    it('it should Not Delete book : status 204', (done) => {
        // Book.deleteMany({bookName:"Unit Testing" , author :"My Book's Group"})
        chai.request(server)
        .get(`/bookdata/deleteBookFromCollection/${data.delete_BookData.flaseValue1.id}`)
        .end((err, res) => {
                res.should.have.status(204);  
            done();
        });
    }); 
});









const userCart = require('../schema/cartSchema');

describe('Testing CartDataBase ', () => {
    const insertInCart = new userCart(data.cartData.savaBook);
   insertInCart.save();
        it('it should GET all the books in cart of particular user : status 200', (done) => {
           chai.request(server)
                .get(`/usercart/${data.cartData.savaBook.userName}`)
                .end((err, res) => {
                    res.should.have.status(200);
                    done();
                });
        });

        it('it should not return any Data  : status 204', (done) => {
            userCart.deleteMany({userName:"Vikas1h"})
            chai.request(server)
                .get(`/usercart/x0`)
                .end((err, res) => {
                    res.should.have.status(204);
                    done();
                });
        });

// it('it should not return any Data  : status 400', (done) => {
//     chai.request(server)
//         .get(`/usercart/${data.cartData.id}`)
//         .end((err, res) => {
//             res.should.have.status(400);
//             done();
//         });
// });


});

//mocha --timeout 18000





